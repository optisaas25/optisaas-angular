import"./chunk-HZ6M6AS2.js";var e=[{path:":id",loadComponent:()=>import("./chunk-63LU442A.js").then(t=>t.CenterDetailComponent)}];export{e as centersRoutes};
