"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
async function checkDetailedDistribution() {
    const prisma = new client_1.PrismaClient();
    const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36';
    console.log(`--- Detailed Distribution for Center: ${centreId} ---`);
    const counts = await prisma.facture.groupBy({
        where: { centreId },
        by: ['type', 'statut'],
        _count: true
    });
    console.log(JSON.stringify(counts, null, 2));
    await prisma.$disconnect();
}
checkDetailedDistribution();
//# sourceMappingURL=check-detailed-distribution.js.map