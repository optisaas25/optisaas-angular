"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const facturesInstance = await prisma.facture.aggregate({ _sum: { totalTTC: true }, where: { centreId, OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }], statut: 'VENTE_EN_INSTANCE' } }); const bcValides = await prisma.facture.aggregate({ _sum: { totalTTC: true }, where: { centreId, OR: [{ type: 'BON_COMMANDE' }, { type: 'BON_COMM' }, { numero: { startsWith: 'BC' } }], statut: { in: ['VALIDE', 'VALIDEE', 'PAYEE', 'PAYE'] } } }); const devis = await prisma.facture.aggregate({ _sum: { totalTTC: true }, where: { centreId, OR: [{ type: 'DEVIS' }, { numero: { startsWith: 'DEV' } }, { numero: { startsWith: 'BRO' } }] } }); console.log('Factures (FACTURE/FAC) in VENTE_EN_INSTANCE:', facturesInstance._sum.totalTTC); console.log('BCs (BON_COMMANDE/BC) in VALIDEE/PAYEE:', bcValides._sum.totalTTC); console.log('Devis Total:', devis._sum.totalTTC); await prisma.$disconnect(); }
run();
//# sourceMappingURL=diagnose-discrepancy.js.map