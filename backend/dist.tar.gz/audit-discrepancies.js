"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() {
    const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36';
    const docs = await prisma.facture.findMany({
        where: { centreId, statut: { notIn: ['ANNULEE', 'ARCHIVE'] } }
    });
    let factureNullDate = 0;
    let bcNullDate = 0;
    for (const f of docs) {
        const isFacture = (f.numero || '').startsWith('FAC') || f.type === 'FACTURE';
        const isInteance = f.statut === 'VENTE_EN_INSTANCE';
        const isBC = f.type === 'BON_COMMANDE' || f.type === 'BON_COMM' || (f.numero || '').startsWith('BC');
        if (isFacture && !isInteance && !f.dateEmission) {
            factureNullDate += (f.totalTTC || 0);
        }
        if ((isInteance || isBC) && !f.dateEmission) {
            bcNullDate += (f.totalTTC || 0);
        }
    }
    console.log('--- Date Issues Audit ---');
    console.log('Factures (Valid) with NULL date Total:', factureNullDate);
    console.log('BCs with NULL date Total:', bcNullDate);
    const paiements = await prisma.paiement.findMany({
        where: { facture: { centreId } },
        orderBy: { date: 'asc' }
    });
    let duplicateTotal = 0;
    const seen = new Set();
    for (const p of paiements) {
        const dateStr = p.date ? new Date(p.date).toISOString().split('T')[0] : 'null';
        const key = `${p.factureId}_${p.montant}_${dateStr}_${p.mode}`;
        if (seen.has(key)) {
            duplicateTotal += p.montant;
        }
        else {
            seen.add(key);
        }
    }
    console.log('\n--- Duplicate Payments Audit ---');
    console.log('Estimated duplicate payments amount:', duplicateTotal);
    const bcs = docs.filter(f => (f.statut === 'VENTE_EN_INSTANCE' || f.type === 'BON_COMMANDE' || f.type === 'BON_COMM' || (f.numero || '').startsWith('BC')));
    console.log('\n--- BC Overview ---');
    console.log('Total BC Count:', bcs.length);
    console.log('Total BC TTC:', bcs.reduce((s, x) => s + (x.totalTTC || 0), 0));
    await prisma.$disconnect();
}
run();
//# sourceMappingURL=audit-discrepancies.js.map