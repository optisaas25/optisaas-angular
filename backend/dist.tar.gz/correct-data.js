"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('--- Correction Start ---');
    const paymentId = 'e2935561-f740-4645-b7b7-91e3f7df23ae';
    console.log(`Fixing Payment ${paymentId}...`);
    const payment = await prisma.paiement.findUnique({
        where: { id: paymentId },
        include: { operationCaisse: true, facture: true }
    });
    if (!payment) {
        console.error('Payment not found!');
        return;
    }
    if (payment.statut !== 'DECAISSEMENT') {
        await prisma.paiement.update({
            where: { id: paymentId },
            data: { statut: 'DECAISSEMENT' }
        });
        console.log('✅ Payment status updated to DECAISSEMENT');
    }
    if (payment.operationCaisse) {
        console.log(`Operation exists: ${payment.operationCaisse.id}`);
    }
    else {
        console.log('⚠️ No operation found! Creating one in DEPENSES...');
        const depenseSession = await prisma.journeeCaisse.findFirst({
            where: {
                centreId: payment.facture?.centreId || '456f5be0-9f01-4ea1-8d55-f17a82e85ef8',
                statut: 'OUVERTE',
                caisse: { type: 'DEPENSES' }
            }
        });
        if (depenseSession) {
            const newOp = await prisma.operationCaisse.create({
                data: {
                    type: 'DECAISSEMENT',
                    typeOperation: 'COMPTABLE',
                    montant: Math.abs(payment.montant),
                    moyenPaiement: payment.mode,
                    reference: payment.reference || payment.facture?.numero,
                    motif: 'Régularisation Avoir',
                    utilisateur: 'Système (Correction)',
                    journeeCaisseId: depenseSession.id,
                    factureId: payment.factureId
                }
            });
            console.log(`✅ Created Operation ${newOp.id} in Session ${depenseSession.id}`);
            await prisma.paiement.update({
                where: { id: paymentId },
                data: { operationCaisseId: newOp.id }
            });
            await prisma.journeeCaisse.update({
                where: { id: depenseSession.id },
                data: {
                    totalDepenses: { increment: Math.abs(payment.montant) }
                }
            });
            console.log('✅ Updated Session Totals');
        }
        else {
            console.error('❌ No open DEPENSES session found!');
        }
    }
    const openSessions = await prisma.journeeCaisse.findMany({
        where: { statut: 'OUVERTE' },
        include: {
            operations: true,
            caisse: true
        }
    });
    console.log(`\n--- Recalculating All Open Sessions (${openSessions.length}) ---`);
    for (const session of openSessions) {
        let calcEspeces = 0;
        let calcCarte = 0;
        let calcCheque = 0;
        let calcDepenses = 0;
        let calcComptable = 0;
        for (const op of session.operations) {
            if (op.type === 'ENCAISSEMENT') {
                calcComptable += op.montant;
                if (op.moyenPaiement === 'ESPECES')
                    calcEspeces += op.montant;
                if (op.moyenPaiement === 'CARTE')
                    calcCarte += op.montant;
                if (op.moyenPaiement === 'CHEQUE')
                    calcCheque += op.montant;
            }
            else if (op.type === 'DECAISSEMENT') {
                if (session.caisse.type === 'DEPENSES') {
                    calcDepenses += op.montant;
                }
                else {
                    if (op.moyenPaiement === 'ESPECES')
                        calcDepenses += op.montant;
                }
            }
        }
        console.log(`Session ${session.id} (${session.caisse.nom}): Recalculated Depenses=${calcDepenses}, Especes=${calcEspeces}`);
    }
}
main()
    .catch((e) => console.error(e))
    .finally(async () => await prisma.$disconnect());
//# sourceMappingURL=correct-data.js.map