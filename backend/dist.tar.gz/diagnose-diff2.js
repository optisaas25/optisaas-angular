"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const agg = await prisma.facture.aggregate({ _sum: { totalTTC: true }, where: { centreId, OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }], statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] }, type: { not: 'AVOIR' } } }); const raw = await prisma.facture.findMany({ select: { id: true, type: true, statut: true, numero: true, totalTTC: true } }); let manualSum = 0; let missed = []; for (const f of raw) {
    if (f.statut === 'ARCHIVE' || f.statut === 'ANNULEE')
        continue;
    if ((f.numero && f.numero.startsWith('FAC')) || f.type === 'FACTURE') {
        if (f.type !== 'AVOIR')
            manualSum += (f.totalTTC || 0);
    }
} console.log('Aggregate sum:', agg._sum.totalTTC); console.log('Manual sum:', manualSum); await prisma.$disconnect(); }
run();
//# sourceMappingURL=diagnose-diff2.js.map