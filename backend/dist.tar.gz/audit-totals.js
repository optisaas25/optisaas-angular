"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const factures = await prisma.facture.findMany({ select: { type: true, statut: true, totalTTC: true, numero: true } }); const paiements = await prisma.paiement.findMany({ select: { montant: true, factureId: true } }); let totalFacture = 0; let totalBC = 0; let totalDevis = 0; let totalPaid = 0; let totalPaidLinked = 0; for (const f of factures) {
    if (f.statut === 'ARCHIVE' || f.statut === 'ANNULEE')
        continue;
    if ((f.numero && f.numero.startsWith('FAC')) || f.type === 'FACTURE') {
        if (f.type !== 'AVOIR')
            totalFacture += (f.totalTTC || 0);
    }
    else if (f.type === 'BON_COMMANDE' || f.type === 'BON_COMM' || (f.numero && f.numero.startsWith('BC')) || f.statut === 'VENTE_EN_INSTANCE') {
        totalBC += (f.totalTTC || 0);
    }
    else if (f.type === 'DEVIS' || (f.numero && (f.numero.startsWith('BRO') || f.numero.startsWith('DEV') || f.numero.startsWith('DEVIS')))) {
        totalDevis += (f.totalTTC || 0);
    }
} for (const p of paiements) {
    totalPaid += (p.montant || 0);
    if (p.factureId)
        totalPaidLinked += (p.montant || 0);
} console.log('\n--- GROSS TOTALS IN DB (all time, all centers, excluding ARCHIVE/ANNULEE) ---'); console.log('Total Facture (FAC* or FACTURE):', totalFacture); console.log('Total BC (BC* or BON_COMMANDE or VENTE_EN_INSTANCE):', totalBC); console.log('Total Devis:', totalDevis); console.log('Total Paid (All Paiements):', totalPaid); console.log('Total Paid (Linked to Facture):', totalPaidLinked); console.log('Total Facture + BC:', totalFacture + totalBC); await prisma.$disconnect(); }
run();
//# sourceMappingURL=audit-totals.js.map