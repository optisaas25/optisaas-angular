"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const res = await prisma.facture.findMany({ where: { centreId, OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }], statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] }, type: { not: 'AVOIR' } }, take: undefined }); console.log('Items returned:', res.length); await prisma.$disconnect(); }
run();
//# sourceMappingURL=test-take.js.map