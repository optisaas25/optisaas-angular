"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const express_1 = require("express");
const common_1 = require("@nestjs/common");
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.setGlobalPrefix('api');
    app.use((0, express_1.json)({ limit: '50mb' }));
    app.use((0, express_1.urlencoded)({ limit: '50mb', extended: true }));
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: false,
        transform: true,
        exceptionFactory: (errors) => {
            console.error('❌ Validation Errors:', JSON.stringify(errors, null, 2));
            return new common_1.BadRequestException(errors);
        },
    }));
    app.enableCors({
        origin: true,
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
        credentials: true,
    });
    const port = process.env.PORT ?? 3000;
    console.log(`🚀 Server version 2.1 (Maximum Inclusive Import) starting on port ${port}`);
    const fs = require('fs');
    const logFile = 'import_execute.log';
    fs.appendFileSync(logFile, `\n--- SERVER STARTUP: ${new Date().toISOString()} --- VERSION 2.2 (DIAGNOSTICS ACTIVE) ---\n`);
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    console.log = (...args) => {
        fs.appendFileSync(logFile, `[LOG] ${new Date().toISOString()}: ${args.join(' ')}\n`);
        originalConsoleLog.apply(console, args);
    };
    console.error = (...args) => {
        fs.appendFileSync(logFile, `[ERROR] ${new Date().toISOString()}: ${args.join(' ')}\n`);
        originalConsoleError.apply(console, args);
    };
    console.log('--- DB CONFIG --- URL:', process.env.DATABASE_URL);
    console.log('🚀 Server version 2.2 (Diagnostics Active) started on port', port);
    await app.listen(port, '0.0.0.0');
}
bootstrap();
//# sourceMappingURL=main.js.map