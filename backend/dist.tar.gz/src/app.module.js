"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const fs_1 = require("fs");
const prisma_module_1 = require("./prisma/prisma.module");
const clients_module_1 = require("./features/clients/clients.module");
const fiches_module_1 = require("./features/fiches/fiches.module");
const factures_module_1 = require("./features/factures/factures.module");
const paiements_module_1 = require("./features/paiements/paiements.module");
const sales_control_module_1 = require("./features/sales-control/sales-control.module");
const groups_module_1 = require("./features/groups/groups.module");
const centers_module_1 = require("./features/centers/centers.module");
const warehouses_module_1 = require("./features/warehouses/warehouses.module");
const stock_movements_module_1 = require("./features/stock-movements/stock-movements.module");
const users_module_1 = require("./features/users/users.module");
const products_module_1 = require("./features/products/products.module");
const loyalty_module_1 = require("./features/loyalty/loyalty.module");
const stats_module_1 = require("./features/stats/stats.module");
const suppliers_module_1 = require("./features/suppliers/suppliers.module");
const expenses_module_1 = require("./features/expenses/expenses.module");
const supplier_invoices_module_1 = require("./features/supplier-invoices/supplier-invoices.module");
const bon_livraison_module_1 = require("./features/bon-livraison/bon-livraison.module");
const treasury_module_1 = require("./features/treasury/treasury.module");
const caisse_module_1 = require("./features/caisse/caisse.module");
const journee_caisse_module_1 = require("./features/journee-caisse/journee-caisse.module");
const operation_caisse_module_1 = require("./features/operation-caisse/operation-caisse.module");
const funding_requests_module_1 = require("./features/funding-requests/funding-requests.module");
const marketing_module_1 = require("./features/marketing/marketing.module");
const conventions_module_1 = require("./features/conventions/conventions.module");
const config_1 = require("@nestjs/config");
const personnel_module_1 = require("./features/personnel/personnel.module");
const auth_module_1 = require("./features/auth/auth.module");
const serve_static_1 = require("@nestjs/serve-static");
const path_1 = require("path");
const accounting_module_1 = require("./features/accounting/accounting.module");
const logger_middleware_1 = require("./common/middleware/logger.middleware");
const imports_module_1 = require("./features/imports/imports.module");
const company_settings_module_1 = require("./features/company-settings/company-settings.module");
const glass_parameters_module_1 = require("./features/glass-parameters/glass-parameters.module");
const glass_parameters_controller_1 = require("./features/glass-parameters/glass-parameters.controller");
const diag_controller_1 = require("./diag.controller");
let AppModule = class AppModule {
    configure(consumer) {
        consumer.apply(logger_middleware_1.LoggerMiddleware).forRoutes('*');
    }
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            prisma_module_1.PrismaModule,
            groups_module_1.GroupsModule,
            centers_module_1.CentersModule,
            warehouses_module_1.WarehousesModule,
            products_module_1.ProductsModule,
            stock_movements_module_1.StockMovementsModule,
            clients_module_1.ClientsModule,
            factures_module_1.FacturesModule,
            paiements_module_1.PaiementsModule,
            fiches_module_1.FichesModule,
            sales_control_module_1.SalesControlModule,
            users_module_1.UsersModule,
            loyalty_module_1.LoyaltyModule,
            stats_module_1.StatsModule,
            suppliers_module_1.SuppliersModule,
            expenses_module_1.ExpensesModule,
            supplier_invoices_module_1.SupplierInvoicesModule,
            bon_livraison_module_1.BonLivraisonModule,
            treasury_module_1.TreasuryModule,
            caisse_module_1.CaisseModule,
            journee_caisse_module_1.JourneeCaisseModule,
            operation_caisse_module_1.OperationCaisseModule,
            funding_requests_module_1.FundingRequestsModule,
            marketing_module_1.MarketingModule,
            personnel_module_1.PersonnelModule,
            auth_module_1.AuthModule,
            accounting_module_1.AccountingModule,
            imports_module_1.ImportsModule,
            company_settings_module_1.CompanySettingsModule,
            glass_parameters_module_1.GlassParametersModule,
            conventions_module_1.ConventionsModule,
            serve_static_1.ServeStaticModule.forRoot({
                rootPath: (0, fs_1.existsSync)('/app/uploads')
                    ? '/app/uploads'
                    : (0, path_1.join)(__dirname, '..', 'uploads'),
                serveRoot: '/uploads',
            }),
        ],
        controllers: [diag_controller_1.DiagController, glass_parameters_controller_1.GlassParametersController],
        providers: [],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map