"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiagController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("./prisma/prisma.service");
let DiagController = class DiagController {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async checkData() {
        const [paymentCount, paymentSum, invoiceCount, invoiceSum] = await Promise.all([
            this.prisma.paiement.count(),
            this.prisma.paiement.aggregate({ _sum: { montant: true } }),
            this.prisma.facture.count(),
            this.prisma.facture.aggregate({ _sum: { totalHT: true } }),
        ]);
        return {
            payments: { count: paymentCount, sum: paymentSum._sum.montant },
            invoices: { count: invoiceCount, sum: invoiceSum._sum.totalHT },
            timestamp: new Date().toISOString(),
        };
    }
    async testGlass() {
        return { status: 'OK', message: 'DiagController can see you' };
    }
};
exports.DiagController = DiagController;
__decorate([
    (0, common_1.Get)('data-check'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], DiagController.prototype, "checkData", null);
__decorate([
    (0, common_1.Get)('glass-test'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], DiagController.prototype, "testGlass", null);
exports.DiagController = DiagController = __decorate([
    (0, common_1.Controller)('diag'),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DiagController);
//# sourceMappingURL=diag.controller.js.map