import { PrismaService } from './prisma/prisma.service';
export declare class DiagController {
    private prisma;
    constructor(prisma: PrismaService);
    checkData(): Promise<{
        payments: {
            count: number;
            sum: number | null;
        };
        invoices: {
            count: number;
            sum: number | null;
        };
        timestamp: string;
    }>;
    testGlass(): Promise<{
        status: string;
        message: string;
    }>;
}
