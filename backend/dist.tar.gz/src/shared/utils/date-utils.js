"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeToUTCNoon = normalizeToUTCNoon;
function normalizeToUTCNoon(date) {
    if (!date)
        return null;
    const d = new Date(date);
    if (isNaN(d.getTime()))
        return null;
    return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 12, 0, 0, 0));
}
//# sourceMappingURL=date-utils.js.map