export declare function normalizeToUTCNoon(date: Date | string | undefined | null): Date | null;
