"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlassParametersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let GlassParametersService = class GlassParametersService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async seedInitialData() {
        const brands = [
            'Essilor', 'Zeiss', 'Hoya', 'Nikon', 'Rodenstock', 'Seiko',
            'BBGR', 'Optiswiss', 'Shamir', 'Kodak', 'Generic', 'Autre'
        ];
        const materials = {
            'Organique (CR-39)': {
                '1.50 (Standard)': 200,
                '1.56': 250,
                '1.60': 350,
                '1.67': 500
            },
            'Polycarbonate': {
                '1.59': 400
            },
            'Trivex': {
                '1.53': 450
            },
            'Minéral': {
                '1.523': 150,
                '1.60': 300,
                '1.70': 500,
                '1.80': 800,
                '1.90': 1200
            },
            'Organique MR-8': {
                '1.60': 500
            },
            'Organique MR-7': {
                '1.67': 700
            },
            'Blue Cut Mass': {
                '1.56': 400,
                '1.60': 600,
                '1.67': 800
            }
        };
        const treatments = {
            'Anti-reflet (HMC)': 100,
            'Durci (HC)': 50,
            'Super Anti-reflet (SHMC)': 150,
            'Anti-lumière bleue (Blue Cut)': 200,
            'Photochromique (Transitions)': 600,
            'Teinté (Solaire - Gris)': 150,
            'Teinté (Solaire - Brun)': 150,
            'Teinté (Solaire - Vert)': 150,
            'Polarisé': 400,
            'Miroité': 250,
            'Hydrophobe': 100,
        };
        for (const name of brands) {
            await this.prisma.glassBrand.upsert({
                where: { name },
                update: {},
                create: { name }
            });
        }
        for (const [matName, indices] of Object.entries(materials)) {
            const material = await this.prisma.glassMaterial.upsert({
                where: { name: matName },
                update: {},
                create: { name: matName }
            });
            for (const [idxValue, price] of Object.entries(indices)) {
                await this.prisma.glassIndex.upsert({
                    where: {
                        materialId_value: {
                            materialId: material.id,
                            value: idxValue
                        }
                    },
                    update: { price },
                    create: {
                        materialId: material.id,
                        value: idxValue,
                        label: idxValue,
                        price
                    }
                });
            }
        }
        for (const [name, price] of Object.entries(treatments)) {
            await this.prisma.glassTreatment.upsert({
                where: { name },
                update: { price },
                create: { name, price }
            });
        }
        return { message: 'Seeding completed successfully' };
    }
    async getAllParameters() {
        const [brands, materials, treatments] = await Promise.all([
            this.prisma.glassBrand.findMany({ orderBy: { name: 'asc' } }),
            this.prisma.glassMaterial.findMany({
                include: { indices: { orderBy: { value: 'asc' } } },
                orderBy: { name: 'asc' },
            }),
            this.prisma.glassTreatment.findMany({ orderBy: { name: 'asc' } }),
        ]);
        return { brands, materials, treatments };
    }
    async createBrand(name) {
        return this.prisma.glassBrand.create({ data: { name } });
    }
    async deleteBrand(id) {
        return this.prisma.glassBrand.delete({ where: { id } });
    }
    async createMaterial(name) {
        return this.prisma.glassMaterial.create({ data: { name } });
    }
    async deleteMaterial(id) {
        return this.prisma.glassMaterial.delete({ where: { id } });
    }
    async createIndex(materialId, value, label, price) {
        return this.prisma.glassIndex.create({
            data: { materialId, value, label, price: price || 0 },
        });
    }
    async updateIndex(id, data) {
        return this.prisma.glassIndex.update({
            where: { id },
            data,
        });
    }
    async deleteIndex(id) {
        return this.prisma.glassIndex.delete({ where: { id } });
    }
    async createTreatment(name, price) {
        return this.prisma.glassTreatment.create({
            data: { name, price: price || 0 },
        });
    }
    async updateTreatment(id, data) {
        return this.prisma.glassTreatment.update({
            where: { id },
            data,
        });
    }
    async deleteTreatment(id) {
        return this.prisma.glassTreatment.delete({ where: { id } });
    }
};
exports.GlassParametersService = GlassParametersService;
exports.GlassParametersService = GlassParametersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], GlassParametersService);
//# sourceMappingURL=glass-parameters.service.js.map