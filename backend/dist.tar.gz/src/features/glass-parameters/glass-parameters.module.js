"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlassParametersModule = void 0;
const common_1 = require("@nestjs/common");
const glass_parameters_service_1 = require("./glass-parameters.service");
const glass_parameters_controller_1 = require("./glass-parameters.controller");
let GlassParametersModule = class GlassParametersModule {
    onModuleInit() {
        console.log('🚀 GlassParametersModule initialized!');
    }
};
exports.GlassParametersModule = GlassParametersModule;
exports.GlassParametersModule = GlassParametersModule = __decorate([
    (0, common_1.Module)({
        providers: [glass_parameters_service_1.GlassParametersService],
        controllers: [glass_parameters_controller_1.GlassParametersController],
        exports: [glass_parameters_service_1.GlassParametersService],
    })
], GlassParametersModule);
//# sourceMappingURL=glass-parameters.module.js.map