import { OnModuleInit } from '@nestjs/common';
export declare class GlassParametersModule implements OnModuleInit {
    onModuleInit(): void;
}
