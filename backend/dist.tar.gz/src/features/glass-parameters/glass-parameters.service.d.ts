import { PrismaService } from '../../prisma/prisma.service';
export declare class GlassParametersService {
    private prisma;
    constructor(prisma: PrismaService);
    seedInitialData(): Promise<{
        message: string;
    }>;
    getAllParameters(): Promise<{
        brands: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
        }[];
        materials: ({
            indices: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                value: string;
                label: string | null;
                price: number;
                materialId: string;
            }[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
        })[];
        treatments: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            price: number;
        }[];
    }>;
    createBrand(name: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
    }>;
    deleteBrand(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
    }>;
    createMaterial(name: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
    }>;
    deleteMaterial(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
    }>;
    createIndex(materialId: string, value: string, label?: string, price?: number): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        label: string | null;
        price: number;
        materialId: string;
    }>;
    updateIndex(id: string, data: {
        value?: string;
        label?: string;
        price?: number;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        label: string | null;
        price: number;
        materialId: string;
    }>;
    deleteIndex(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        label: string | null;
        price: number;
        materialId: string;
    }>;
    createTreatment(name: string, price?: number): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        price: number;
    }>;
    updateTreatment(id: string, data: {
        name?: string;
        price?: number;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        price: number;
    }>;
    deleteTreatment(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        price: number;
    }>;
}
