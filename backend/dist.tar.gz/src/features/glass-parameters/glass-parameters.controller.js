"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlassParametersController = void 0;
const common_1 = require("@nestjs/common");
const glass_parameters_service_1 = require("./glass-parameters.service");
let GlassParametersController = class GlassParametersController {
    service;
    constructor(service) {
        this.service = service;
        console.log('🚀 GlassParametersController instantiated!');
    }
    test() {
        return { status: 'OK', message: 'GlassParametersController is active' };
    }
    getAll() {
        return this.service.getAllParameters();
    }
    seed() {
        return this.service.seedInitialData();
    }
    createBrand(name) {
        return this.service.createBrand(name);
    }
    deleteBrand(id) {
        return this.service.deleteBrand(id);
    }
    createMaterial(name) {
        return this.service.createMaterial(name);
    }
    deleteMaterial(id) {
        return this.service.deleteMaterial(id);
    }
    createIndex(materialId, value, label, price) {
        return this.service.createIndex(materialId, value, label, price);
    }
    updateIndex(id, data) {
        return this.service.updateIndex(id, data);
    }
    deleteIndex(id) {
        return this.service.deleteIndex(id);
    }
    createTreatment(name, price) {
        return this.service.createTreatment(name, price);
    }
    updateTreatment(id, data) {
        return this.service.updateTreatment(id, data);
    }
    deleteTreatment(id) {
        return this.service.deleteTreatment(id);
    }
};
exports.GlassParametersController = GlassParametersController;
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "test", null);
__decorate([
    (0, common_1.Get)('all'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "getAll", null);
__decorate([
    (0, common_1.Get)('seed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "seed", null);
__decorate([
    (0, common_1.Post)('brands'),
    __param(0, (0, common_1.Body)('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "createBrand", null);
__decorate([
    (0, common_1.Delete)('brands/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "deleteBrand", null);
__decorate([
    (0, common_1.Post)('materials'),
    __param(0, (0, common_1.Body)('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "createMaterial", null);
__decorate([
    (0, common_1.Delete)('materials/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "deleteMaterial", null);
__decorate([
    (0, common_1.Post)('indices'),
    __param(0, (0, common_1.Body)('materialId')),
    __param(1, (0, common_1.Body)('value')),
    __param(2, (0, common_1.Body)('label')),
    __param(3, (0, common_1.Body)('price')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Number]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "createIndex", null);
__decorate([
    (0, common_1.Patch)('indices/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "updateIndex", null);
__decorate([
    (0, common_1.Delete)('indices/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "deleteIndex", null);
__decorate([
    (0, common_1.Post)('treatments'),
    __param(0, (0, common_1.Body)('name')),
    __param(1, (0, common_1.Body)('price')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "createTreatment", null);
__decorate([
    (0, common_1.Patch)('treatments/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "updateTreatment", null);
__decorate([
    (0, common_1.Delete)('treatments/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], GlassParametersController.prototype, "deleteTreatment", null);
exports.GlassParametersController = GlassParametersController = __decorate([
    (0, common_1.Controller)('glass-parameters'),
    __metadata("design:paramtypes", [glass_parameters_service_1.GlassParametersService])
], GlassParametersController);
//# sourceMappingURL=glass-parameters.controller.js.map