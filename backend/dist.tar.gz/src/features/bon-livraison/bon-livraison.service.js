"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BonLivraisonService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const products_service_1 = require("../products/products.service");
const date_utils_1 = require("../../shared/utils/date-utils");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let BonLivraisonService = class BonLivraisonService {
    prisma;
    productsService;
    constructor(prisma, productsService) {
        this.prisma = prisma;
        this.productsService = productsService;
    }
    async create(createDto) {
        const { echeances, base64File, fileName, ...inputData } = createDto;
        const blData = {
            numeroBL: inputData.numeroBL,
            dateEmission: (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEmission),
            dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEcheance),
            montantHT: Number(inputData.montantHT),
            montantTVA: Number(inputData.montantTVA),
            montantTTC: Number(inputData.montantTTC),
            statut: inputData.statut || 'VALIDEE',
            type: inputData.type || 'ACHAT_STOCK',
            fournisseurId: inputData.fournisseurId,
            centreId: inputData.centreId,
            clientId: inputData.clientId,
            ficheId: inputData.ficheId,
            categorieBL: inputData.categorieBL,
            factureFournisseurId: inputData.factureFournisseurId,
            pieceJointeUrl: inputData.pieceJointeUrl || '',
        };
        const existingBL = await this.prisma.bonLivraison.findFirst({
            where: {
                fournisseurId: blData.fournisseurId,
                numeroBL: blData.numeroBL,
            },
        });
        if (existingBL) {
            return this.update(existingBL.id, createDto);
        }
        let pieceJointeUrl = blData.pieceJointeUrl;
        if (base64File && fileName) {
            const uploadDir = path.join(process.cwd(), 'uploads', 'bl');
            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }
            const fileExt = path.extname(fileName) || '.jpg';
            const safeName = `bl_${Date.now()}${fileExt}`;
            const filePath = path.join(uploadDir, safeName);
            const buffer = Buffer.from(base64File.replace(/^data:.*?;base64,/, ''), 'base64');
            fs.writeFileSync(filePath, buffer);
            pieceJointeUrl = `/uploads/bl/${safeName}`;
        }
        const finalEcheances = echeances || [];
        return this.prisma.bonLivraison.create({
            data: {
                ...blData,
                pieceJointeUrl,
                echeances: {
                    create: finalEcheances.map((e) => ({
                        type: e.type,
                        dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(e.dateEcheance),
                        montant: e.montant,
                        statut: e.statut,
                        reference: e.reference || null,
                        banque: e.banque || null,
                    })),
                },
            },
            include: {
                echeances: true,
                fournisseur: true,
            },
        });
    }
    async findAll(filters) {
        const { fournisseurId, statut, clientId, centreId, ficheId, startDate, endDate, page, limit, categorieBL } = filters;
        const whereClause = {};
        if (fournisseurId)
            whereClause.fournisseurId = fournisseurId;
        if (statut)
            whereClause.statut = statut;
        if (clientId)
            whereClause.clientId = clientId;
        if (centreId)
            whereClause.centreId = centreId;
        if (ficheId)
            whereClause.ficheId = ficheId;
        if (categorieBL)
            whereClause.categorieBL = categorieBL;
        if (startDate || endDate) {
            whereClause.dateEmission = {};
            if (startDate)
                whereClause.dateEmission.gte = new Date(startDate);
            if (endDate)
                whereClause.dateEmission.lte = new Date(endDate);
        }
        const skip = page && limit ? (Number(page) - 1) * Number(limit) : undefined;
        const take = limit ? Number(limit) : 10;
        try {
            const unlinkedBLs = await this.prisma.bonLivraison.findMany({
                where: {
                    ...whereClause,
                    depense: null,
                    montantTTC: { gt: 0 }
                },
                take: 50
            });
            for (const bl of unlinkedBLs) {
                const orphanMatch = await this.prisma.depense.findFirst({
                    where: {
                        bonLivraisonId: null,
                        montant: bl.montantTTC,
                        statut: 'VALIDE',
                        createdAt: {
                            gte: new Date(bl.dateEmission.getTime() - 2 * 24 * 60 * 60 * 1000),
                            lte: new Date(bl.dateEmission.getTime() + 2 * 24 * 60 * 60 * 1000)
                        }
                    }
                });
                if (orphanMatch) {
                    await this.prisma.depense.update({
                        where: { id: orphanMatch.id },
                        data: { bonLivraisonId: bl.id }
                    });
                }
            }
        }
        catch (e) {
            console.error('[BonLivraisonService] Auto-repair failed:', e);
        }
        const [data, total] = await Promise.all([
            this.prisma.bonLivraison.findMany({
                where: whereClause,
                include: {
                    fournisseur: { select: { id: true, nom: true } },
                    echeances: true,
                    depense: true,
                    client: {
                        select: {
                            id: true,
                            nom: true,
                            prenom: true,
                            numeroPieceIdentite: true,
                            fiches: { select: { id: true, numero: true, dateCreation: true } },
                        },
                    },
                    fiche: { select: { id: true, numero: true, type: true } },
                    factureFournisseur: { select: { id: true, numeroFacture: true } },
                },
                orderBy: { dateEmission: 'desc' },
                skip,
                take,
            }),
            this.prisma.bonLivraison.count({ where: whereClause }),
        ]);
        const enrichedData = await Promise.all(data.map(async (bl) => {
            const result = { ...bl };
            if (!result.depense && result.montantTTC > 0) {
                const blDate = result.dateEmission.getTime();
                const orphanMatch = await this.prisma.depense.findFirst({
                    where: {
                        bonLivraisonId: null,
                        fournisseurId: result.fournisseurId,
                        montant: {
                            gte: result.montantTTC - 0.05,
                            lte: result.montantTTC + 0.05,
                        },
                        statut: { in: ['VALIDE', 'VALIDEE'] },
                        date: {
                            gte: new Date(blDate - 4 * 24 * 60 * 60 * 1000),
                            lte: new Date(blDate + 4 * 24 * 60 * 60 * 1000),
                        },
                    },
                });
                if (orphanMatch) {
                    await this.prisma.depense.update({
                        where: { id: orphanMatch.id },
                        data: { bonLivraisonId: result.id },
                    });
                    result.depense = orphanMatch;
                }
            }
            const activeEcheances = (result.echeances || []).filter((e) => e.statut !== 'ANNULE');
            const totalPaidEcheances = activeEcheances
                .filter((e) => e.statut === 'ENCAISSE')
                .reduce((sum, e) => sum + e.montant, 0);
            const directPaid = (result.depense && (result.depense.statut === 'VALIDE' || result.depense.statut === 'VALIDEE')) ? result.depense.montant : 0;
            const totalPaidRaw = totalPaidEcheances + directPaid;
            const roundedTotalPaid = Math.round(totalPaidRaw * 100) / 100;
            const roundedTotalTTC = Math.round(result.montantTTC * 100) / 100;
            let expectedStatus = 'EN_ATTENTE';
            if (roundedTotalPaid >= roundedTotalTTC && roundedTotalTTC > 0) {
                expectedStatus = 'PAYEE';
            }
            else if (roundedTotalPaid > 0) {
                expectedStatus = 'PARTIELLE';
            }
            else {
                const hasCommitted = activeEcheances.some((e) => (e.type === 'CHEQUE' || e.type === 'LCN' || e.type === 'VIREMENT') && e.statut !== 'ANNULE');
                expectedStatus = hasCommitted ? 'PARTIELLE' : 'EN_ATTENTE';
            }
            if (result.statut !== expectedStatus) {
                await this.prisma.bonLivraison.update({
                    where: { id: result.id },
                    data: { statut: expectedStatus },
                });
                result.statut = expectedStatus;
            }
            if (!result.fiche &&
                result.client &&
                result.client.fiches &&
                result.client.fiches.length > 0) {
                const closestFiche = result.client.fiches.reduce((prev, curr) => {
                    const prevDiff = Math.abs(prev.dateCreation.getTime() - result.dateEmission.getTime());
                    const currDiff = Math.abs(curr.dateCreation.getTime() - result.dateEmission.getTime());
                    return currDiff < prevDiff ? curr : prev;
                });
                result.fiche = closestFiche;
            }
            if (result.client) {
                delete result.client.fiches;
            }
            return result;
        }));
        const finalStats = enrichedData.reduce((acc, curr) => {
            acc.totalTTC += curr.montantTTC || 0;
            const paidEcheances = (curr.echeances || [])
                .filter((e) => e.statut === 'ENCAISSE')
                .reduce((sum, e) => sum + e.montant, 0);
            const directPaid = (curr.depense && (curr.depense.statut === 'VALIDE' || curr.depense.statut === 'VALIDEE')) ? curr.depense.montant : 0;
            acc.totalPaid += paidEcheances + directPaid;
            return acc;
        }, { totalTTC: 0, totalPaid: 0 });
        return {
            data: enrichedData,
            total,
            stats: {
                totalTTC: Math.round(finalStats.totalTTC * 100) / 100,
                totalPaid: Math.round(finalStats.totalPaid * 100) / 100,
                totalRemaining: Math.round((finalStats.totalTTC - finalStats.totalPaid) * 100) / 100,
            },
        };
    }
    async findOne(id) {
        const bl = await this.prisma.bonLivraison.findUnique({
            where: { id },
            include: {
                fournisseur: true,
                echeances: true,
                depense: true,
                client: true,
                fiche: true,
                factureFournisseur: true,
            },
        });
        if (!bl)
            throw new common_1.NotFoundException(`BL with ID ${id} not found`);
        return bl;
    }
    async update(id, updateDto) {
        const { echeances, base64File, fileName, ...inputData } = updateDto;
        let pieceJointeUrl = inputData.pieceJointeUrl;
        if (base64File && fileName) {
            const uploadDir = path.join(process.cwd(), 'uploads', 'bl');
            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }
            const fileExt = path.extname(fileName) || '.jpg';
            const safeName = `bl_update_${Date.now()}${fileExt}`;
            const filePath = path.join(uploadDir, safeName);
            const buffer = Buffer.from(base64File.replace(/^data:.*?;base64,/, ''), 'base64');
            fs.writeFileSync(filePath, buffer);
            pieceJointeUrl = `/uploads/bl/${safeName}`;
        }
        return this.prisma.$transaction(async (tx) => {
            if (echeances) {
                await tx.echeancePaiement.deleteMany({
                    where: { bonLivraisonId: id },
                });
            }
            return tx.bonLivraison.update({
                where: { id },
                data: {
                    numeroBL: inputData.numeroBL,
                    dateEmission: inputData.dateEmission ? (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEmission) : undefined,
                    dateEcheance: inputData.dateEcheance ? (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEcheance) : undefined,
                    montantHT: inputData.montantHT !== undefined ? Number(inputData.montantHT) : undefined,
                    montantTVA: inputData.montantTVA !== undefined ? Number(inputData.montantTVA) : undefined,
                    montantTTC: inputData.montantTTC !== undefined ? Number(inputData.montantTTC) : undefined,
                    statut: inputData.statut,
                    type: inputData.type,
                    fournisseurId: inputData.fournisseurId,
                    centreId: inputData.centreId,
                    clientId: inputData.clientId,
                    ficheId: inputData.ficheId,
                    categorieBL: inputData.categorieBL,
                    factureFournisseurId: inputData.factureFournisseurId,
                    pieceJointeUrl,
                    echeances: echeances
                        ? {
                            create: echeances.map((e) => ({
                                type: e.type,
                                dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(e.dateEcheance),
                                montant: e.montant,
                                statut: e.statut,
                                reference: e.reference || null,
                                banque: e.banque || null,
                            })),
                        }
                        : undefined,
                },
                include: {
                    echeances: true,
                    fournisseur: true,
                },
            });
        });
    }
    async remove(id) {
        return this.prisma.bonLivraison.delete({ where: { id } });
    }
};
exports.BonLivraisonService = BonLivraisonService;
exports.BonLivraisonService = BonLivraisonService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        products_service_1.ProductsService])
], BonLivraisonService);
//# sourceMappingURL=bon-livraison.service.js.map