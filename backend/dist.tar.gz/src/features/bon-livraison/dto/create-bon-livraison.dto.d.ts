declare class CreateEcheanceDto {
    type: string;
    dateEcheance: string;
    montant: number;
    reference?: string;
    banque?: string;
    statut: string;
}
export declare class CreateBonLivraisonDto {
    numeroBL: string;
    dateEmission: string;
    dateEcheance?: string;
    montantHT: number;
    montantTVA: number;
    montantTTC: number;
    statut: string;
    type: string;
    pieceJointeUrl?: string;
    fournisseurId: string;
    centreId?: string;
    clientId?: string;
    ficheId?: string;
    categorieBL?: string;
    factureFournisseurId?: string;
    echeances?: CreateEcheanceDto[];
    base64File?: string;
    fileName?: string;
}
export {};
