"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BonLivraisonController = void 0;
const common_1 = require("@nestjs/common");
const bon_livraison_service_1 = require("./bon-livraison.service");
const create_bon_livraison_dto_1 = require("./dto/create-bon-livraison.dto");
let BonLivraisonController = class BonLivraisonController {
    bonLivraisonService;
    constructor(bonLivraisonService) {
        this.bonLivraisonService = bonLivraisonService;
    }
    create(createDto) {
        return this.bonLivraisonService.create(createDto);
    }
    findAll(fournisseurId, statut, clientId, centreId, ficheId, startDate, endDate, page, limit, categorieBL) {
        return this.bonLivraisonService.findAll({
            fournisseurId,
            statut,
            clientId,
            centreId,
            ficheId,
            startDate,
            endDate,
            page,
            limit,
            categorieBL,
        });
    }
    findOne(id) {
        return this.bonLivraisonService.findOne(id);
    }
    update(id, updateDto) {
        return this.bonLivraisonService.update(id, updateDto);
    }
    remove(id) {
        return this.bonLivraisonService.remove(id);
    }
};
exports.BonLivraisonController = BonLivraisonController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_bon_livraison_dto_1.CreateBonLivraisonDto]),
    __metadata("design:returntype", void 0)
], BonLivraisonController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('fournisseurId')),
    __param(1, (0, common_1.Query)('statut')),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('centreId')),
    __param(4, (0, common_1.Query)('ficheId')),
    __param(5, (0, common_1.Query)('startDate')),
    __param(6, (0, common_1.Query)('endDate')),
    __param(7, (0, common_1.Query)('page')),
    __param(8, (0, common_1.Query)('limit')),
    __param(9, (0, common_1.Query)('categorieBL')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, Number, Number, String]),
    __metadata("design:returntype", void 0)
], BonLivraisonController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], BonLivraisonController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BonLivraisonController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], BonLivraisonController.prototype, "remove", null);
exports.BonLivraisonController = BonLivraisonController = __decorate([
    (0, common_1.Controller)('bon-livraison'),
    __metadata("design:paramtypes", [bon_livraison_service_1.BonLivraisonService])
], BonLivraisonController);
//# sourceMappingURL=bon-livraison.controller.js.map