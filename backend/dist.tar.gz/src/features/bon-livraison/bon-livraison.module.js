"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BonLivraisonModule = void 0;
const common_1 = require("@nestjs/common");
const bon_livraison_service_1 = require("./bon-livraison.service");
const bon_livraison_controller_1 = require("./bon-livraison.controller");
const products_module_1 = require("../products/products.module");
let BonLivraisonModule = class BonLivraisonModule {
};
exports.BonLivraisonModule = BonLivraisonModule;
exports.BonLivraisonModule = BonLivraisonModule = __decorate([
    (0, common_1.Module)({
        imports: [products_module_1.ProductsModule],
        controllers: [bon_livraison_controller_1.BonLivraisonController],
        providers: [bon_livraison_service_1.BonLivraisonService],
        exports: [bon_livraison_service_1.BonLivraisonService],
    })
], BonLivraisonModule);
//# sourceMappingURL=bon-livraison.module.js.map