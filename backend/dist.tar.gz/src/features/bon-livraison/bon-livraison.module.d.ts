export declare class BonLivraisonModule {
}
