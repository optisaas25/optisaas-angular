import { PrismaService } from '../../prisma/prisma.service';
export declare class TreasuryService {
    private prisma;
    private readonly INVENTORY_PURCHASE_TYPES;
    private readonly OPERATIONAL_PURCHASE_TYPES;
    private readonly ACTIVE_STATUSES;
    constructor(prisma: PrismaService);
    getMonthlySummary(year: number, month: number, centreId?: string, startDateStr?: string, endDateStr?: string): Promise<{
        month: number;
        year: number;
        totalExpenses: any;
        totalIncoming: number;
        totalExpensesCashed: any;
        totalIncomingCashed: number;
        balance: number;
        balanceReal: number;
        totalScheduled: any;
        totalIncomingPending: number;
        totalOutgoingPending: number;
        monthlyThreshold: any;
        categories: {
            name: string;
            value: number;
        }[];
        incomingCash: number;
        incomingCard: number;
        countCard: number;
        countChequeCoffre: number;
        alerts: {
            client: {
                id: string;
                client: string;
                montant: number;
                date: Date | null;
                reference: string | null;
                numeroFacture: string;
            }[];
            supplier: {
                id: any;
                fournisseur: any;
                montant: any;
                date: any;
                reference: any;
                source: string;
            }[];
        };
    }>;
    getConfig(): Promise<{
        id: string;
        updatedAt: Date;
        monthlyThreshold: number;
    }>;
    updateConfig(threshold: number): Promise<{
        id: string;
        updatedAt: Date;
        monthlyThreshold: number;
    }>;
    getConsolidatedOutgoings(filters: {
        fournisseurId?: string;
        type?: string;
        startDate?: string;
        endDate?: string;
        source?: string;
        centreId?: string;
        mode?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        data: {
            id: string;
            date: Date;
            libelle: string;
            type: string;
            fournisseur: string;
            montant: number;
            statut: string;
            source: string;
            modePaiement: string;
            reference: string | null;
            banque: string | null;
            dateEcheance: Date;
            dateEncaissement: Date | null;
            createdAt: Date;
        }[];
        total: number;
        subtotals: {
            totalTTC: number;
            totalAccrual?: undefined;
            totalHT?: undefined;
        };
    } | {
        data: any[];
        total: any;
        subtotals: {
            totalTTC: any;
            totalAccrual: number;
            totalHT: number;
        };
    }>;
    getConsolidatedIncomings(filters: {
        centreId?: string;
        clientId?: string;
        type?: string;
        statut?: string;
        startDate?: string;
        endDate?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        data: any[];
        total: any;
        subtotals: {
            totalTTC: any;
        };
    }>;
    getConsolidatedUnpaid(filters: {
        centreId?: string;
        clientId?: string;
        startDate?: string;
        endDate?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        data: {
            id: string;
            date: Date;
            libelle: string;
            numero: string;
            type: string;
            client: {
                nom: string | null;
                prenom: string | null;
                raisonSociale: string | null;
            };
            totalTTC: number;
            resteAPayer: number;
            statut: string;
            source: string;
        }[];
        total: number;
        subtotals: {
            totalTTC: number;
            totalReste: number;
        };
    }>;
    getYearlyProjection(year: number, centreId?: string): Promise<{
        month: number;
        totalExpenses: number;
    }[]>;
    updateEcheanceStatus(id: string, statut: string): Promise<{
        id: string;
        type: string;
        dateEcheance: Date;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        montant: number;
        reference: string | null;
        banque: string | null;
        remarque: string | null;
        dateEncaissement: Date | null;
        factureFournisseurId: string | null;
        bonLivraisonId: string | null;
    }>;
    getPendingAlerts(centreId?: string): Promise<{
        client: {
            id: string;
            client: string;
            montant: number;
            date: Date | null;
            reference: string | null;
            numeroFacture: string;
        }[];
        supplier: {
            id: any;
            fournisseur: any;
            montant: any;
            date: any;
            reference: any;
            source: string;
        }[];
    }>;
}
