"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreasuryController = void 0;
const common_1 = require("@nestjs/common");
const treasury_service_1 = require("./treasury.service");
let TreasuryController = class TreasuryController {
    treasuryService;
    constructor(treasuryService) {
        this.treasuryService = treasuryService;
    }
    getConsolidatedUnpaid(clientId, startDate, endDate, centreId, page, limit) {
        console.log(`[TREASURY-CONT] getConsolidatedUnpaid called. Params:`, { clientId, startDate, endDate, centreId, page, limit });
        return this.treasuryService.getConsolidatedUnpaid({
            clientId,
            startDate,
            endDate,
            centreId,
            page,
            limit,
        });
    }
    getMonthlySummary(year, month, startDate, endDate, centreId) {
        const parsedYear = year !== undefined ? parseInt(year) : new Date().getFullYear();
        const parsedMonth = month !== undefined ? parseInt(month) : new Date().getMonth() + 1;
        return this.treasuryService.getMonthlySummary(isNaN(parsedYear) ? new Date().getFullYear() : parsedYear, isNaN(parsedMonth) ? new Date().getMonth() + 1 : parsedMonth, centreId, startDate, endDate);
    }
    getConsolidatedIncomings(clientId, startDate, endDate, centreId, mode, statut, page, limit) {
        return this.treasuryService.getConsolidatedIncomings({
            clientId,
            startDate,
            endDate,
            centreId,
            type: mode,
            statut,
            page,
            limit,
        });
    }
    getConsolidatedOutgoings(fournisseurId, type, startDate, endDate, source, centreId, mode, page, limit) {
        return this.treasuryService.getConsolidatedOutgoings({
            fournisseurId,
            type,
            startDate,
            endDate,
            source,
            centreId,
            mode,
            page,
            limit,
        });
    }
    getYearlyProjection(year, centreId) {
        return this.treasuryService.getYearlyProjection(parseInt(year) || new Date().getFullYear(), centreId);
    }
    getConfig() {
        return this.treasuryService.getConfig();
    }
    updateConfig(threshold) {
        return this.treasuryService.updateConfig(threshold);
    }
    validateEcheance(id, statut) {
        return this.treasuryService.updateEcheanceStatus(id, statut || 'ENCAISSE');
    }
    getPendingAlerts(centreId) {
        return this.treasuryService.getPendingAlerts(centreId);
    }
};
exports.TreasuryController = TreasuryController;
__decorate([
    (0, common_1.Get)('consolidated-unpaid-final'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('centreId')),
    __param(4, (0, common_1.Query)('page')),
    __param(5, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Number, Number]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getConsolidatedUnpaid", null);
__decorate([
    (0, common_1.Get)('summary'),
    __param(0, (0, common_1.Query)('year')),
    __param(1, (0, common_1.Query)('month')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __param(4, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getMonthlySummary", null);
__decorate([
    (0, common_1.Get)('consolidated-incomings'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('centreId')),
    __param(4, (0, common_1.Query)('mode')),
    __param(5, (0, common_1.Query)('statut')),
    __param(6, (0, common_1.Query)('page')),
    __param(7, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, Number, Number]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getConsolidatedIncomings", null);
__decorate([
    (0, common_1.Get)('consolidated-outgoings'),
    __param(0, (0, common_1.Query)('fournisseurId')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __param(4, (0, common_1.Query)('source')),
    __param(5, (0, common_1.Query)('centreId')),
    __param(6, (0, common_1.Query)('mode')),
    __param(7, (0, common_1.Query)('page')),
    __param(8, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, Number, Number]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getConsolidatedOutgoings", null);
__decorate([
    (0, common_1.Get)('projection'),
    __param(0, (0, common_1.Query)('year')),
    __param(1, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getYearlyProjection", null);
__decorate([
    (0, common_1.Get)('config'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Post)('config'),
    __param(0, (0, common_1.Body)('monthlyThreshold')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "updateConfig", null);
__decorate([
    (0, common_1.Post)('echeances/:id/validate'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('statut')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "validateEcheance", null);
__decorate([
    (0, common_1.Get)('pending-alerts'),
    __param(0, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], TreasuryController.prototype, "getPendingAlerts", null);
exports.TreasuryController = TreasuryController = __decorate([
    (0, common_1.Controller)('treasury'),
    __metadata("design:paramtypes", [treasury_service_1.TreasuryService])
], TreasuryController);
//# sourceMappingURL=treasury.controller.js.map