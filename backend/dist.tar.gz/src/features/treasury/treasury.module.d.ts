export declare class TreasuryModule {
}
