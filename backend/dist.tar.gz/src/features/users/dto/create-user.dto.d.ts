export declare class CreateUserCentreRoleDto {
    centreId: string;
    centreName: string;
    role: string;
    entrepotIds?: string[];
    entrepotNames?: string[];
}
export declare class CreateUserDto {
    nom: string;
    prenom: string;
    civilite: string;
    telephone?: string;
    email: string;
    photoUrl?: string;
    employeeId?: string;
    matricule?: string;
    statut?: string;
    password?: string;
    centreRoles?: CreateUserCentreRoleDto[];
}
