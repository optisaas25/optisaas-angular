"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const bcrypt = __importStar(require("bcryptjs"));
let UsersService = class UsersService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createUserDto) {
        const { centreRoles, employeeId, ...userData } = createUserDto;
        return this.prisma.$transaction(async (tx) => {
            const existingUser = await tx.user.findUnique({
                where: { email: userData.email },
            });
            if (existingUser) {
                throw new common_1.ConflictException(`Un utilisateur avec l'adresse email ${userData.email} existe déjà.`);
            }
            if (employeeId) {
                const employee = await tx.employee.findUnique({
                    where: { id: employeeId },
                });
                if (!employee) {
                    throw new common_1.NotFoundException(`Employee with ID ${employeeId} not found`);
                }
                if (employee.userId) {
                    throw new common_1.ConflictException(`Cet employé est déjà lié à un compte utilisateur.`);
                }
            }
            const password = userData.password || 'password123';
            const hashedPassword = await bcrypt.hash(password, 10);
            const user = await tx.user.create({
                data: {
                    ...userData,
                    password: hashedPassword,
                    centreRoles: {
                        create: centreRoles || [],
                    },
                },
                include: {
                    centreRoles: true,
                },
            });
            if (createUserDto.employeeId) {
                await tx.employee.update({
                    where: { id: employeeId },
                    data: { userId: user.id },
                });
            }
            return user;
        });
    }
    async findAll() {
        return this.prisma.user.findMany({
            include: {
                centreRoles: true,
                employee: true,
            },
        });
    }
    async findOne(id) {
        const user = await this.prisma.user.findUnique({
            where: { id },
            include: {
                centreRoles: true,
                employee: true,
            },
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${id} not found`);
        }
        return user;
    }
    async update(id, updateUserDto) {
        const { centreRoles, employeeId, ...userData } = updateUserDto;
        return this.prisma.$transaction(async (tx) => {
            if (userData.password) {
                userData.password = await bcrypt.hash(userData.password, 10);
            }
            const updatedUser = await tx.user.update({
                where: { id },
                data: userData,
            });
            if (centreRoles) {
                await tx.userCentreRole.deleteMany({
                    where: { userId: id },
                });
                await tx.userCentreRole.createMany({
                    data: centreRoles.map((role) => ({
                        ...role,
                        userId: id,
                    })),
                });
            }
            if (employeeId) {
                await tx.employee.update({
                    where: { id: employeeId },
                    data: { userId: id },
                });
            }
            return tx.user.findUnique({
                where: { id },
                include: {
                    centreRoles: true,
                },
            });
        });
    }
    async remove(id) {
        try {
            await this.prisma.user.delete({
                where: { id },
            });
            return { message: `User with ID ${id} deleted successfully` };
        }
        catch (error) {
            throw new common_1.NotFoundException(`User with ID ${id} not found`);
        }
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], UsersService);
//# sourceMappingURL=users.service.js.map