import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    create(createUserDto: CreateUserDto): Promise<{
        centreRoles: {
            id: string;
            centreId: string;
            userId: string;
            centreName: string;
            role: string;
            entrepotIds: string[];
            entrepotNames: string[];
        }[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        telephone: string | null;
        email: string;
        prenom: string;
        civilite: string;
        photoUrl: string | null;
        matricule: string | null;
        password: string;
    }>;
    findAll(): Promise<({
        employee: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string | null;
            nom: string;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
            prenom: string;
            photoUrl: string | null;
            matricule: string | null;
            cin: string | null;
            poste: string;
            contrat: string;
            dateEmbauche: Date;
            salaireBase: number;
            childrenCount: number;
            paymentMode: string;
            socialSecurityAffiliation: boolean;
            familyStatus: string;
        } | null;
        centreRoles: {
            id: string;
            centreId: string;
            userId: string;
            centreName: string;
            role: string;
            entrepotIds: string[];
            entrepotNames: string[];
        }[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        telephone: string | null;
        email: string;
        prenom: string;
        civilite: string;
        photoUrl: string | null;
        matricule: string | null;
        password: string;
    })[]>;
    findOne(id: string): Promise<{
        employee: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string | null;
            nom: string;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
            prenom: string;
            photoUrl: string | null;
            matricule: string | null;
            cin: string | null;
            poste: string;
            contrat: string;
            dateEmbauche: Date;
            salaireBase: number;
            childrenCount: number;
            paymentMode: string;
            socialSecurityAffiliation: boolean;
            familyStatus: string;
        } | null;
        centreRoles: {
            id: string;
            centreId: string;
            userId: string;
            centreName: string;
            role: string;
            entrepotIds: string[];
            entrepotNames: string[];
        }[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        telephone: string | null;
        email: string;
        prenom: string;
        civilite: string;
        photoUrl: string | null;
        matricule: string | null;
        password: string;
    }>;
    update(id: string, updateUserDto: UpdateUserDto): Promise<({
        centreRoles: {
            id: string;
            centreId: string;
            userId: string;
            centreName: string;
            role: string;
            entrepotIds: string[];
            entrepotNames: string[];
        }[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        telephone: string | null;
        email: string;
        prenom: string;
        civilite: string;
        photoUrl: string | null;
        matricule: string | null;
        password: string;
    }) | null>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
