export declare class MarketingModule {
}
