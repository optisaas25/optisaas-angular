import { PrismaService } from '../../prisma/prisma.service';
export declare class MarketingConfigService {
    private prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getConfig(): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
    updateConfig(data: any): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
}
