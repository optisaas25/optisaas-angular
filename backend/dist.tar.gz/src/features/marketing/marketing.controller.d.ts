import { MarketingService } from './marketing.service';
export declare class MarketingController {
    private readonly marketingService;
    constructor(marketingService: MarketingService);
    launchCampaign(campaignData: {
        clientIds: string[];
        productIds: string[];
        template: string;
        promoName?: string;
        promoDescription?: string;
        channel?: 'WHATSAPP' | 'SMS' | 'EMAIL';
    }): Promise<{
        success: boolean;
        processedCount: number;
        channel: "WHATSAPP" | "SMS" | "EMAIL";
        results: any[];
    }>;
    getMarketingStats(): Promise<{
        oldStockCount: number;
        totalClients: number;
    }>;
    getConfig(): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
    updateConfig(data: any): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
}
