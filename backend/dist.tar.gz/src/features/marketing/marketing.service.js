"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var MarketingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketingService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const config_1 = require("@nestjs/config");
const axios_1 = __importDefault(require("axios"));
const nodemailer = __importStar(require("nodemailer"));
const marketing_config_service_1 = require("./marketing-config.service");
let MarketingService = MarketingService_1 = class MarketingService {
    prisma;
    configService;
    marketingConfigService;
    logger = new common_1.Logger(MarketingService_1.name);
    constructor(prisma, configService, marketingConfigService) {
        this.prisma = prisma;
        this.configService = configService;
        this.marketingConfigService = marketingConfigService;
    }
    async getMarketingConfig() {
        return this.marketingConfigService.getConfig();
    }
    async updateMarketingConfig(data) {
        return this.marketingConfigService.updateConfig(data);
    }
    async processCampaign(data) {
        const { clientIds, productIds, template, promoName, promoDescription, channel = 'WHATSAPP', } = data;
        const config = await this.marketingConfigService.getConfig();
        const clients = await this.prisma.client.findMany({
            where: { id: { in: clientIds } },
        });
        const products = await this.prisma.product.findMany({
            where: { id: { in: productIds } },
        });
        const campaignResults = [];
        const productMarques = products
            .map((p) => p.marque || '')
            .filter((v, i, a) => v && a.indexOf(v) === i)
            .join(', ');
        const productNames = products.map((p) => p.designation).join(', ');
        for (const client of clients) {
            const message = template
                .replace(/{{NAME}}/g, client.raisonSociale ||
                `${client.nom || ''} ${client.prenom || ''}`.trim())
                .replace(/{{MARQUE}}/g, productMarques)
                .replace(/{{PRODUCT}}/g, productNames)
                .replace(/{{PROMO_NAME}}/g, promoName || '')
                .replace(/{{DESCRIPTION}}/g, promoDescription || '');
            const formattedPhone = client.telephone
                ? this.formatPhone(client.telephone)
                : '';
            try {
                if (channel === 'WHATSAPP' && formattedPhone) {
                    await this.sendWhatsApp(formattedPhone, message, config);
                }
                else if (channel === 'SMS' && client.telephone) {
                    await this.sendSMS(client.telephone, message, config);
                }
                else if (channel === 'EMAIL' && client.email) {
                    await this.sendEmail(client.email, `Offre Spéciale: ${promoName || 'Votre promotion'}`, message, config);
                }
                else {
                    this.logger.warn(`[CAMPAIGN] Skipping client ${client.id} - No valid ${channel} contact info`);
                    continue;
                }
                campaignResults.push({ clientId: client.id, channel, status: 'SENT' });
            }
            catch (error) {
                this.logger.error(`[CAMPAIGN] Failed to send to ${client.id} via ${channel}: ${error.message}`);
                campaignResults.push({
                    clientId: client.id,
                    channel,
                    status: 'FAILED',
                    error: error.message,
                });
            }
        }
        return {
            success: true,
            processedCount: campaignResults.length,
            channel,
            results: campaignResults,
        };
    }
    async sendWhatsApp(phone, message, dbConfig) {
        const apiUrl = dbConfig?.whatsappApiUrl ||
            this.configService.get('WHATSAPP_API_URL');
        const token = dbConfig?.whatsappToken ||
            this.configService.get('WHATSAPP_TOKEN');
        const instanceId = dbConfig?.whatsappInstanceId ||
            this.configService.get('WHATSAPP_INSTANCE_ID');
        this.logger.log(`[WhatsApp] Attempting send to ${phone} via ${apiUrl}`);
        if (!apiUrl || !token || !instanceId) {
            this.logger.warn('[WhatsApp] API credentials missing, skipping send.');
            return;
        }
        const url = `${apiUrl}/${instanceId}/messages/chat`;
        try {
            const response = await axios_1.default.post(url, {
                token: token,
                to: phone,
                body: message,
            });
            this.logger.log(`[WhatsApp] Send successful for ${phone}: ${JSON.stringify(response.data)}`);
        }
        catch (error) {
            this.logger.error(`[WhatsApp] Failed to send to ${phone}: ${error.response?.data ? JSON.stringify(error.response.data) : error.message}`);
            throw error;
        }
    }
    async sendSMS(phone, message, dbConfig) {
        const apiUrl = dbConfig?.smsGatewayUrl ||
            this.configService.get('SMS_GATEWAY_URL');
        const apiKey = dbConfig?.smsApiKey || this.configService.get('SMS_API_KEY');
        this.logger.log(`[SMS] Attempting send to ${phone} via ${apiUrl}`);
        if (!apiUrl || !apiKey) {
            this.logger.warn('[SMS] API credentials missing, skipping send.');
            return;
        }
        try {
            const response = await axios_1.default.post(apiUrl, {
                apiKey: apiKey,
                to: phone,
                message: message,
            });
            this.logger.log(`[SMS] Send successful for ${phone}: ${JSON.stringify(response.data)}`);
        }
        catch (error) {
            this.logger.error(`[SMS] Failed to send to ${phone}: ${error.response?.data ? JSON.stringify(error.response.data) : error.message}`);
            throw error;
        }
    }
    async sendEmail(to, subject, body, dbConfig) {
        const host = dbConfig?.smtpHost || this.configService.get('SMTP_HOST');
        const user = dbConfig?.smtpUser || this.configService.get('SMTP_USER');
        const pass = dbConfig?.smtpPass || this.configService.get('SMTP_PASS');
        const port = Number(dbConfig?.smtpPort) ||
            this.configService.get('SMTP_PORT', 587);
        this.logger.log(`[Email] Attempting send to ${to} via ${host}:${port} (user: ${user})`);
        if (!host || !user || !pass) {
            this.logger.warn('[Email] SMTP credentials missing, skipping send.');
            return;
        }
        try {
            const transporter = nodemailer.createTransport({
                host: host,
                port: port,
                secure: port === 465,
                auth: { user, pass },
                tls: {
                    rejectUnauthorized: false,
                },
            });
            const info = await transporter.sendMail({
                from: dbConfig?.smtpFrom ||
                    this.configService.get('SMTP_FROM', user),
                to,
                subject,
                text: body,
                html: `<div style="font-family: sans-serif; padding: 20px;">
                        ${body.replace(/\n/g, '<br>')}
                       </div>`,
            });
            this.logger.log(`[Email] Send successful to ${to}: ${info.messageId}`);
        }
        catch (error) {
            this.logger.error(`[Email] Failed to send to ${to}: ${error.message}`);
            throw error;
        }
    }
    async getStats() {
        const oldStockCount = await this.prisma.product.count({
            where: {
                quantiteActuelle: { gt: 0 },
                createdAt: { lt: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000) },
            },
        });
        return {
            oldStockCount,
            totalClients: await this.prisma.client.count(),
        };
    }
    formatPhone(phone) {
        const clean = phone.replace(/[^0-9]/g, '');
        if (clean.startsWith('0') && clean.length === 10) {
            return '212' + clean.substring(1);
        }
        return clean;
    }
};
exports.MarketingService = MarketingService;
exports.MarketingService = MarketingService = MarketingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        marketing_config_service_1.MarketingConfigService])
], MarketingService);
//# sourceMappingURL=marketing.service.js.map