import { PrismaService } from '../../prisma/prisma.service';
import { ConfigService } from '@nestjs/config';
import { MarketingConfigService } from './marketing-config.service';
export declare class MarketingService {
    private prisma;
    private configService;
    private marketingConfigService;
    private readonly logger;
    constructor(prisma: PrismaService, configService: ConfigService, marketingConfigService: MarketingConfigService);
    getMarketingConfig(): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
    updateMarketingConfig(data: any): Promise<{
        id: string;
        updatedAt: Date;
        whatsappApiUrl: string | null;
        whatsappInstanceId: string | null;
        whatsappToken: string | null;
        smsGatewayUrl: string | null;
        smsApiKey: string | null;
        smtpHost: string | null;
        smtpPort: number;
        smtpUser: string | null;
        smtpPass: string | null;
        smtpFrom: string | null;
    }>;
    processCampaign(data: {
        clientIds: string[];
        productIds: string[];
        template: string;
        promoName?: string;
        promoDescription?: string;
        channel?: 'WHATSAPP' | 'SMS' | 'EMAIL';
    }): Promise<{
        success: boolean;
        processedCount: number;
        channel: "WHATSAPP" | "SMS" | "EMAIL";
        results: any[];
    }>;
    private sendWhatsApp;
    private sendSMS;
    private sendEmail;
    getStats(): Promise<{
        oldStockCount: number;
        totalClients: number;
    }>;
    private formatPhone;
}
