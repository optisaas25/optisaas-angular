"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateCentreDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_centre_dto_1 = require("./create-centre.dto");
class UpdateCentreDto extends (0, mapped_types_1.PartialType)(create_centre_dto_1.CreateCentreDto) {
}
exports.UpdateCentreDto = UpdateCentreDto;
//# sourceMappingURL=update-centre.dto.js.map