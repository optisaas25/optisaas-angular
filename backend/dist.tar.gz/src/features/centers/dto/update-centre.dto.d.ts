import { CreateCentreDto } from './create-centre.dto';
declare const UpdateCentreDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateCentreDto>>;
export declare class UpdateCentreDto extends UpdateCentreDto_base {
}
export {};
