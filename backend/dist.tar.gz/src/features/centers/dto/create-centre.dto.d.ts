export declare class CreateCentreDto {
    nom: string;
    description?: string;
    adresse?: string;
    ville?: string;
    codePostal?: string;
    telephone?: string;
    email?: string;
    groupeId: string;
}
