import { CentersService } from './centers.service';
import { CreateCentreDto } from './dto/create-centre.dto';
import { UpdateCentreDto } from './dto/update-centre.dto';
export declare class CentersController {
    private readonly centersService;
    constructor(centersService: CentersService);
    create(createCentreDto: CreateCentreDto): Promise<{
        groupe: {
            id: string;
            type: string | null;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
        };
        entrepots: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            nom: string;
            description: string | null;
            capaciteMax: number | null;
            surface: number | null;
            responsable: string | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        ville: string | null;
        codePostal: string | null;
        telephone: string | null;
        email: string | null;
        groupeId: string;
    }>;
    findAll(groupeId?: string): Promise<({
        groupe: {
            id: string;
            type: string | null;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
        };
        entrepots: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            nom: string;
            description: string | null;
            capaciteMax: number | null;
            surface: number | null;
            responsable: string | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        ville: string | null;
        codePostal: string | null;
        telephone: string | null;
        email: string | null;
        groupeId: string;
    })[]>;
    findOne(id: string): Promise<{
        groupe: {
            id: string;
            type: string | null;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
        };
        entrepots: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            nom: string;
            description: string | null;
            capaciteMax: number | null;
            surface: number | null;
            responsable: string | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        ville: string | null;
        codePostal: string | null;
        telephone: string | null;
        email: string | null;
        groupeId: string;
    }>;
    update(id: string, updateCentreDto: UpdateCentreDto): Promise<{
        groupe: {
            id: string;
            type: string | null;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
        };
        entrepots: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            nom: string;
            description: string | null;
            capaciteMax: number | null;
            surface: number | null;
            responsable: string | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        ville: string | null;
        codePostal: string | null;
        telephone: string | null;
        email: string | null;
        groupeId: string;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
