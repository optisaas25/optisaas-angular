export declare class CentersModule {
}
