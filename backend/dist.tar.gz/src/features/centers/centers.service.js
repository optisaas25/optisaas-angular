"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CentersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let CentersService = class CentersService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createCentreDto) {
        return this.prisma.centre.create({
            data: createCentreDto,
            include: {
                groupe: true,
                entrepots: true,
            },
        });
    }
    async findAll(groupeId) {
        return this.prisma.centre.findMany({
            where: groupeId ? { groupeId } : undefined,
            include: {
                groupe: true,
                entrepots: true,
            },
        });
    }
    async findOne(id) {
        const centre = await this.prisma.centre.findUnique({
            where: { id },
            include: {
                groupe: true,
                entrepots: true,
            },
        });
        if (!centre) {
            throw new common_1.NotFoundException(`Centre with ID ${id} not found`);
        }
        return centre;
    }
    async update(id, updateCentreDto) {
        try {
            return await this.prisma.centre.update({
                where: { id },
                data: updateCentreDto,
                include: {
                    groupe: true,
                    entrepots: true,
                },
            });
        }
        catch (error) {
            throw new common_1.NotFoundException(`Centre with ID ${id} not found`);
        }
    }
    async remove(id) {
        try {
            await this.prisma.centre.delete({
                where: { id },
            });
            return { message: `Centre with ID ${id} deleted successfully` };
        }
        catch (error) {
            throw new common_1.NotFoundException(`Centre with ID ${id} not found`);
        }
    }
};
exports.CentersService = CentersService;
exports.CentersService = CentersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CentersService);
//# sourceMappingURL=centers.service.js.map