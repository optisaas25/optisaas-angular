export declare class CreateSupplierDto {
    nom: string;
    contact?: string;
    email?: string;
    telephone?: string;
    adresse?: string;
    ville?: string;
    siteWeb?: string;
    ice?: string;
    rc?: string;
    identifiantFiscal?: string;
    patente?: string;
    cnss?: string;
    siret?: string;
    rib?: string;
    banque?: string;
    conditionsPaiement?: string;
    contacts?: any;
    convention?: any;
}
