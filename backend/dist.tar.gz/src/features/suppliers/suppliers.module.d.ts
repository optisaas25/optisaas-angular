export declare class SuppliersModule {
}
