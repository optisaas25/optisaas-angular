"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierInvoicesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const products_service_1 = require("../products/products.service");
const date_utils_1 = require("../../shared/utils/date-utils");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let SupplierInvoicesService = class SupplierInvoicesService {
    prisma;
    productsService;
    constructor(prisma, productsService) {
        this.prisma = prisma;
        this.productsService = productsService;
    }
    async create(createDto) {
        const { echeances, base64File, fileName, ...inputData } = createDto;
        const invoiceData = {
            numeroFacture: inputData.numeroFacture,
            dateEmission: (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEmission),
            dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(inputData.dateEcheance),
            montantHT: Number(inputData.montantHT),
            montantTVA: Number(inputData.montantTVA),
            montantTTC: Number(inputData.montantTTC),
            statut: inputData.statut,
            type: inputData.type,
            fournisseurId: inputData.fournisseurId,
            centreId: inputData.centreId,
            clientId: inputData.clientId,
            ficheId: inputData.ficheId,
            pieceJointeUrl: inputData.pieceJointeUrl || '',
        };
        const existingInvoice = await this.checkExistence(invoiceData.fournisseurId, invoiceData.numeroFacture);
        if (existingInvoice) {
            console.log(`[INVOICE] Update existing invoice ${existingInvoice.numeroFacture} for supplier ${invoiceData.fournisseurId}`);
            return this.update(existingInvoice.id, createDto);
        }
        let pieceJointeUrl = invoiceData.pieceJointeUrl;
        if (base64File && fileName) {
            const uploadDir = path.join(process.cwd(), 'uploads', 'invoices');
            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }
            const fileExt = path.extname(fileName) || '.jpg';
            const safeName = `inv_${Date.now()}${fileExt}`;
            const filePath = path.join(uploadDir, safeName);
            const buffer = Buffer.from(base64File.replace(/^data:.*?;base64,/, ''), 'base64');
            fs.writeFileSync(filePath, buffer);
            pieceJointeUrl = `/uploads/invoices/${safeName}`;
        }
        const status = this.calculateInvoiceStatus(invoiceData.montantTTC, echeances || []);
        const finalEcheances = echeances && echeances.length > 0
            ? echeances
            : [
                {
                    type: 'ESPECES',
                    dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEcheance || new Date()),
                    montant: invoiceData.montantTTC,
                    statut: 'EN_ATTENTE',
                },
            ];
        try {
            return await this.prisma.factureFournisseur.create({
                data: {
                    ...invoiceData,
                    pieceJointeUrl,
                    statut: status,
                    echeances: {
                        create: finalEcheances.map((e) => ({
                            type: e.type,
                            dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(e.dateEcheance),
                            montant: e.montant,
                            statut: e.statut,
                            reference: e.reference || null,
                            banque: e.banque || null,
                            remarque: e.remarque || null,
                        })),
                    },
                },
                include: {
                    echeances: true,
                    fournisseur: true,
                },
            });
        }
        catch (error) {
            console.error('[INVOICE] CREATE ERROR:', error);
            throw error;
        }
    }
    async findAll(filters) {
        const { fournisseurId, statut, clientId, centreId, startDate, endDate, ficheId, page, limit, } = filters;
        const whereClause = {};
        if (fournisseurId)
            whereClause.fournisseurId = fournisseurId;
        if (statut)
            whereClause.statut = statut;
        if (clientId)
            whereClause.clientId = clientId;
        if (centreId)
            whereClause.centreId = centreId;
        if (ficheId)
            whereClause.ficheId = ficheId;
        if (startDate || endDate) {
            whereClause.dateEmission = {};
            if (startDate)
                whereClause.dateEmission.gte = new Date(startDate);
            if (endDate)
                whereClause.dateEmission.lte = new Date(endDate);
        }
        const skip = page && limit ? (Number(page) - 1) * Number(limit) : undefined;
        const take = limit ? Number(limit) : 10;
        const [data, total] = await Promise.all([
            this.prisma.factureFournisseur.findMany({
                where: whereClause,
                include: {
                    fournisseur: { select: { id: true, nom: true } },
                    echeances: true,
                    client: { select: { id: true, nom: true, prenom: true } },
                    fiche: { select: { id: true, numero: true, type: true } },
                },
                orderBy: { dateEmission: 'desc' },
                skip,
                take,
            }),
            this.prisma.factureFournisseur.count({ where: whereClause }),
        ]);
        return { data, total };
    }
    async findOne(id) {
        return this.prisma.factureFournisseur.findUnique({
            where: { id },
            include: {
                fournisseur: true,
                echeances: true,
                depenses: true,
                client: true,
                fiche: true,
            },
        });
    }
    async checkExistence(fournisseurId, numeroFacture) {
        if (!fournisseurId || !numeroFacture)
            return null;
        const trimmedNumero = numeroFacture.trim();
        return this.prisma.factureFournisseur.findFirst({
            where: {
                fournisseurId: fournisseurId,
                numeroFacture: {
                    equals: trimmedNumero,
                    mode: 'insensitive',
                },
            },
            include: {
                echeances: true,
                fournisseur: true,
            },
        });
    }
    async update(id, updateDto) {
        const { echeances, base64File, fileName, ...invoiceData } = updateDto;
        const cleanedInvoiceData = {
            numeroFacture: invoiceData.numeroFacture,
            dateEmission: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEmission),
            dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEcheance),
            montantHT: invoiceData.montantHT,
            montantTVA: invoiceData.montantTVA,
            montantTTC: invoiceData.montantTTC,
            statut: invoiceData.statut,
            type: invoiceData.type,
            pieceJointeUrl: invoiceData.pieceJointeUrl,
            fournisseurId: invoiceData.fournisseurId,
            centreId: invoiceData.centreId,
            clientId: invoiceData.clientId,
            ficheId: invoiceData.ficheId,
        };
        const newAttachments = updateDto.newAttachments || [];
        const existingAttachments = updateDto.existingAttachments || [];
        const finalUrls = [];
        if (Array.isArray(existingAttachments)) {
            existingAttachments.forEach((url) => {
                let cleanUrl = url;
                if (url.includes('/uploads/')) {
                    const parts = url.split('/uploads/');
                    cleanUrl = '/uploads/' + parts[parts.length - 1];
                }
                finalUrls.push(cleanUrl);
            });
        }
        else if (invoiceData.pieceJointeUrl) {
            finalUrls.push(invoiceData.pieceJointeUrl);
        }
        const uploadDir = path.join(process.cwd(), 'uploads', 'invoices');
        if (newAttachments.length > 0 && !fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        for (const attachment of newAttachments) {
            if (attachment.base64 && attachment.name) {
                const fileExt = path.extname(attachment.name) || '.jpg';
                const safeName = `inv_${Date.now()}_${Math.round(Math.random() * 1000)}${fileExt}`;
                const filePath = path.join(uploadDir, safeName);
                const matches = attachment.base64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
                let fileData = attachment.base64;
                if (matches && matches.length === 3)
                    fileData = matches[2];
                else
                    fileData = attachment.base64.replace(/^data:.*?;base64,/, '');
                fs.writeFileSync(filePath, Buffer.from(fileData, 'base64'));
                finalUrls.push(`/uploads/invoices/${safeName}`);
            }
        }
        if (newAttachments.length === 0 && base64File && fileName) {
            if (!fs.existsSync(uploadDir))
                fs.mkdirSync(uploadDir, { recursive: true });
            const fileExt = path.extname(fileName) || '.jpg';
            const safeName = `inv_update_${Date.now()}${fileExt}`;
            const filePath = path.join(uploadDir, safeName);
            const matches = base64File.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
            let fileData = base64File;
            if (matches && matches.length === 3)
                fileData = matches[2];
            else
                fileData = base64File.replace(/^data:.*?;base64,/, '');
            fs.writeFileSync(filePath, Buffer.from(fileData, 'base64'));
            finalUrls.push(`/uploads/invoices/${safeName}`);
        }
        if (finalUrls.length > 0) {
            cleanedInvoiceData.pieceJointeUrl = finalUrls.join(';');
        }
        else if (updateDto.pieceJointeUrl === null &&
            existingAttachments.length === 0) {
            cleanedInvoiceData.pieceJointeUrl = null;
        }
        return this.prisma.$transaction(async (tx) => {
            if (echeances) {
                await tx.echeancePaiement.deleteMany({
                    where: { factureFournisseurId: id },
                });
            }
            const status = this.calculateInvoiceStatus(cleanedInvoiceData.montantTTC || 0, echeances || []);
            cleanedInvoiceData.statut = status;
            return tx.factureFournisseur.update({
                where: { id },
                data: {
                    ...cleanedInvoiceData,
                    echeances: echeances
                        ? {
                            create: echeances.map((e) => ({
                                type: e.type,
                                dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(e.dateEcheance),
                                dateEncaissement: (0, date_utils_1.normalizeToUTCNoon)(e.dateEncaissement),
                                montant: e.montant,
                                statut: e.statut,
                                reference: e.reference || null,
                                banque: e.banque || null,
                                remarque: e.remarque || null,
                            })),
                        }
                        : undefined,
                },
                include: {
                    echeances: true,
                },
            });
        });
    }
    calculateInvoiceStatus(totalTTC, echeances) {
        if (!echeances || echeances.length === 0)
            return 'EN_ATTENTE';
        const activeEcheances = echeances.filter((e) => e.statut !== 'ANNULE');
        if (activeEcheances.length === 0)
            return 'EN_ATTENTE';
        const totalPaid = Math.round(activeEcheances
            .filter((e) => e.statut === 'ENCAISSE')
            .reduce((sum, e) => sum + (e.montant || 0), 0) * 100) / 100;
        const roundedTotalTTC = Math.round(totalTTC * 100) / 100;
        if (totalPaid >= roundedTotalTTC && roundedTotalTTC > 0) {
            return 'PAYEE';
        }
        if (totalPaid > 0)
            return 'PARTIELLE';
        const hasScheduled = activeEcheances.some((e) => e.type !== 'ESPECES' && e.statut === 'EN_ATTENTE');
        return hasScheduled ? 'PARTIELLE' : 'EN_ATTENTE';
    }
    async remove(id) {
        return this.prisma.$transaction(async (tx) => {
            const invoice = await tx.factureFournisseur.findUnique({
                where: { id },
                include: { mouvementsStock: true },
            });
            if (!invoice)
                return null;
            const productIds = Array.from(new Set(invoice.mouvementsStock.map((m) => m.produitId)));
            await tx.mouvementStock.deleteMany({
                where: { factureFournisseurId: id },
            });
            await Promise.all(productIds.map((productId) => this.productsService.syncProductState(productId, tx)));
            await tx.depense.deleteMany({
                where: { factureFournisseurId: id },
            });
            await tx.echeancePaiement.deleteMany({
                where: { factureFournisseurId: id },
            });
            return tx.factureFournisseur.delete({
                where: { id },
            });
        });
    }
    async getSupplierSituation(fournisseurId, startDate, endDate) {
        const whereClause = {
            fournisseurId: fournisseurId,
            statut: { not: 'ANNULEE' },
            parentInvoiceId: null,
        };
        if (startDate || endDate) {
            whereClause.dateEmission = {};
            if (startDate)
                whereClause.dateEmission.gte = new Date(startDate);
            if (endDate)
                whereClause.dateEmission.lte = new Date(endDate);
        }
        const invoices = await this.prisma.factureFournisseur.findMany({
            where: whereClause,
            include: {
                echeances: true,
            },
        });
        let totalTTC = 0;
        let totalPaye = 0;
        for (const invoice of invoices) {
            totalTTC += invoice.montantTTC;
            if (invoice.echeances) {
                const paidEcheances = invoice.echeances.filter((e) => e.statut === 'ENCAISSE');
                const paidAmount = paidEcheances.reduce((sum, e) => sum + e.montant, 0);
                totalPaye += paidAmount;
            }
        }
        return {
            fournisseurId,
            totalTTC,
            totalPaye,
            resteAPayer: totalTTC - totalPaye,
            invoiceCount: invoices.length,
        };
    }
    async groupBLsToInvoice(blIds, targetInvoiceData) {
        const { echeances, newAttachments, ...invoiceData } = targetInvoiceData;
        let finalPieceJointeUrl = invoiceData.pieceJointeUrl || '';
        const uploadDir = path.join(process.cwd(), 'uploads', 'invoices');
        if (newAttachments && newAttachments.length > 0) {
            if (!fs.existsSync(uploadDir))
                fs.mkdirSync(uploadDir, { recursive: true });
            const urls = [];
            for (const attachment of newAttachments) {
                if (attachment.base64 && attachment.name) {
                    const fileExt = path.extname(attachment.name) || '.jpg';
                    const safeName = `grouped_${Date.now()}_${Math.round(Math.random() * 1000)}${fileExt}`;
                    const filePath = path.join(uploadDir, safeName);
                    const fileData = attachment.base64.replace(/^data:.*?;base64,/, '');
                    fs.writeFileSync(filePath, Buffer.from(fileData, 'base64'));
                    urls.push(`/uploads/invoices/${safeName}`);
                }
            }
            finalPieceJointeUrl = urls.join(';');
        }
        const status = this.calculateInvoiceStatus(invoiceData.montantTTC, echeances || []);
        return this.prisma.$transaction(async (tx) => {
            const invoice = await tx.factureFournisseur.create({
                data: {
                    ...invoiceData,
                    pieceJointeUrl: finalPieceJointeUrl,
                    isBL: false,
                    statut: status,
                    dateEmission: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEmission),
                    dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEcheance),
                    childBLs: {
                        connect: blIds.map((id) => ({ id })),
                    },
                    echeances: echeances
                        ? {
                            create: echeances.map((e) => ({
                                type: e.type,
                                dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(e.dateEcheance),
                                montant: e.montant,
                                statut: e.statut,
                                reference: e.reference || null,
                                banque: e.banque || null,
                            })),
                        }
                        : undefined,
                },
                include: {
                    childBLs: true,
                    echeances: true,
                    fournisseur: true,
                },
            });
            await tx.factureFournisseur.updateMany({
                where: { id: { in: blIds } },
                data: { statut: 'VALIDEE' },
            });
            return invoice;
        });
    }
};
exports.SupplierInvoicesService = SupplierInvoicesService;
exports.SupplierInvoicesService = SupplierInvoicesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        products_service_1.ProductsService])
], SupplierInvoicesService);
//# sourceMappingURL=supplier-invoices.service.js.map