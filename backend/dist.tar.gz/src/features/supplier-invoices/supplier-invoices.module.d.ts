export declare class SupplierInvoicesModule {
}
