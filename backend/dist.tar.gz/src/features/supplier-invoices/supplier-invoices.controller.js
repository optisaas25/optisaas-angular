"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierInvoicesController = void 0;
const common_1 = require("@nestjs/common");
const supplier_invoices_service_1 = require("./supplier-invoices.service");
const create_supplier_invoice_dto_1 = require("./dto/create-supplier-invoice.dto");
let SupplierInvoicesController = class SupplierInvoicesController {
    service;
    constructor(service) {
        this.service = service;
    }
    async checkExistence(fournisseurId, numeroFacture) {
        const invoice = await this.service.checkExistence(fournisseurId, numeroFacture);
        return {
            exists: !!invoice,
            invoice,
        };
    }
    create(createDto) {
        return this.service.create(createDto);
    }
    findAll(fournisseurId, statut, clientId, centreId, startDate, endDate, ficheId, page, limit) {
        return this.service.findAll({
            fournisseurId,
            statut,
            clientId,
            centreId,
            startDate,
            endDate,
            ficheId,
            page,
            limit,
        });
    }
    groupToInvoice(body) {
        return this.service.groupBLsToInvoice(body.blIds, body.targetInvoiceData);
    }
    findOne(id) {
        return this.service.findOne(id);
    }
    update(id, updateDto) {
        return this.service.update(id, updateDto);
    }
    remove(id) {
        return this.service.remove(id);
    }
    getSituation(fournisseurId, startDate, endDate) {
        return this.service.getSupplierSituation(fournisseurId, startDate, endDate);
    }
};
exports.SupplierInvoicesController = SupplierInvoicesController;
__decorate([
    (0, common_1.Get)('check-existence'),
    __param(0, (0, common_1.Query)('fournisseurId')),
    __param(1, (0, common_1.Query)('numeroFacture')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SupplierInvoicesController.prototype, "checkExistence", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_supplier_invoice_dto_1.CreateSupplierInvoiceDto]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('fournisseurId')),
    __param(1, (0, common_1.Query)('statut')),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('centreId')),
    __param(4, (0, common_1.Query)('startDate')),
    __param(5, (0, common_1.Query)('endDate')),
    __param(6, (0, common_1.Query)('ficheId')),
    __param(7, (0, common_1.Query)('page')),
    __param(8, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, Number, Number]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)('group'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "groupToInvoice", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('situation/:fournisseurId'),
    __param(0, (0, common_1.Param)('fournisseurId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], SupplierInvoicesController.prototype, "getSituation", null);
exports.SupplierInvoicesController = SupplierInvoicesController = __decorate([
    (0, common_1.Controller)('supplier-invoices'),
    __metadata("design:paramtypes", [supplier_invoices_service_1.SupplierInvoicesService])
], SupplierInvoicesController);
//# sourceMappingURL=supplier-invoices.controller.js.map