"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsController = void 0;
const common_1 = require("@nestjs/common");
const products_service_1 = require("./products.service");
const create_product_dto_1 = require("./dto/create-product.dto");
const update_product_dto_1 = require("./dto/update-product.dto");
let ProductsController = class ProductsController {
    productsService;
    constructor(productsService) {
        this.productsService = productsService;
    }
    create(createProductDto) {
        return this.productsService.create(createProductDto);
    }
    getStockStats(centreId) {
        return this.productsService.getStockStats(centreId);
    }
    getTransferHistory(startDate, endDate, centreId, productId, type) {
        return this.productsService.getTransferHistory({
            startDate,
            endDate,
            centreId,
            productId,
            type,
        });
    }
    cleanupOutOfStock(centreId) {
        return this.productsService.cleanupOutOfStock(centreId);
    }
    findAll(entrepotId, global, marque, typeArticle, reference, codeBarres, centreId) {
        const isGlobal = global === 'true';
        return this.productsService.findAll(entrepotId, centreId, isGlobal, {
            marque,
            typeArticle,
            reference,
            codeBarres,
        });
    }
    findOne(id) {
        return this.productsService.findOne(id);
    }
    update(id, updateProductDto) {
        if (updateProductDto.specificData) {
            console.warn(`🚨 [PRODUCT-UPDATE-TRAP] PATCH /products/${id} detected!`);
            console.warn(`   Source: Unknown (Check Network Tab)`);
            console.warn(`   Payload specificData keys: ${Object.keys(updateProductDto.specificData)}`);
            console.warn(`   PendingOutgoing in payload: ${updateProductDto.specificData.pendingOutgoing ? 'PRESENT' : 'MISSING'}`);
        }
        return this.productsService.update(id, updateProductDto);
    }
    remove(id) {
        return this.productsService.remove(id);
    }
    initiateTransfer(id, body) {
        return this.productsService.initiateTransfer(id, body.targetProductId, body.quantite !== undefined ? Number(body.quantite) : undefined);
    }
    bulkShip(body) {
        return this.productsService.bulkShip(body.targetProductIds);
    }
    bulkReceive(body) {
        return this.productsService.bulkReceive(body.targetProductIds);
    }
    shipTransfer(id) {
        return this.productsService.shipTransfer(id);
    }
    cancelTransfer(id) {
        return this.productsService.cancelTransfer(id);
    }
    completeTransfer(id) {
        return this.productsService.completeTransfer(id);
    }
    restock(id, body) {
        return this.productsService.restock(id, Number(body.quantite), body.motif, body.utilisateur, body.prixAchatHT !== undefined ? Number(body.prixAchatHT) : undefined, body.remiseFournisseur !== undefined
            ? Number(body.remiseFournisseur)
            : undefined);
    }
    destock(id, body) {
        return this.productsService.destock(id, Number(body.quantite), body.motif, body.destinationEntrepotId, body.utilisateur);
    }
};
exports.ProductsController = ProductsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_product_dto_1.CreateProductDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('stats'),
    __param(0, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "getStockStats", null);
__decorate([
    (0, common_1.Get)('transfers/history'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Headers)('Tenant')),
    __param(3, (0, common_1.Query)('productId')),
    __param(4, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "getTransferHistory", null);
__decorate([
    (0, common_1.Delete)('cleanup-rupture'),
    __param(0, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "cleanupOutOfStock", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('entrepotId')),
    __param(1, (0, common_1.Query)('global')),
    __param(2, (0, common_1.Query)('marque')),
    __param(3, (0, common_1.Query)('typeArticle')),
    __param(4, (0, common_1.Query)('reference')),
    __param(5, (0, common_1.Query)('codeBarres')),
    __param(6, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_product_dto_1.UpdateProductDto]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/transfer'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "initiateTransfer", null);
__decorate([
    (0, common_1.Post)('bulk-ship'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "bulkShip", null);
__decorate([
    (0, common_1.Post)('bulk-receive'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "bulkReceive", null);
__decorate([
    (0, common_1.Post)(':id/ship'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "shipTransfer", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "cancelTransfer", null);
__decorate([
    (0, common_1.Post)(':id/complete-transfer'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "completeTransfer", null);
__decorate([
    (0, common_1.Post)(':id/restock'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "restock", null);
__decorate([
    (0, common_1.Post)(':id/destock'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ProductsController.prototype, "destock", null);
exports.ProductsController = ProductsController = __decorate([
    (0, common_1.Controller)('products'),
    __metadata("design:paramtypes", [products_service_1.ProductsService])
], ProductsController);
//# sourceMappingURL=products.controller.js.map