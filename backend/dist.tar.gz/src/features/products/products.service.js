"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let ProductsService = class ProductsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateNextTransferNumber(tx) {
        const year = new Date().getFullYear();
        const prisma = tx || this.prisma;
        const lastMovement = await prisma.mouvementStock.findFirst({
            where: {
                motif: { contains: `TRS-${year}-` },
            },
            orderBy: { createdAt: 'desc' },
        });
        let sequence = 1;
        if (lastMovement && lastMovement.motif) {
            const match = lastMovement.motif.match(/TRS-\d+-(\d+)/);
            if (match) {
                sequence = parseInt(match[1]) + 1;
            }
        }
        return `TRS-${year}-${sequence.toString().padStart(4, '0')}`;
    }
    async create(createProductDto) {
        try {
            const { categorie, genre, forme, matiere, couleurMonture, couleurBranches, calibre, pont, branche, typeCharniere, typeMonture, photoFace, photoProfil, typeVerre, materiau, indiceRefraction, teinte, filtres, traitements, puissanceSph, puissanceCyl, axe, addition, diametre, base, courbure, fabricant, familleOptique, typeLentille, usage, modeleCommercial, laboratoire, rayonCourbure, nombreParBoite, prixParBoite, prixParUnite, numeroLot, datePeremption, quantiteBoites, quantiteUnites, categorieAccessoire, sousCategorie, specificData, ...mainAndRelationalFields } = createProductDto;
            const newSpecificData = {
                ...specificData,
                ...(categorie && { categorie }),
                ...(genre && { genre }),
                ...(forme && { forme }),
                ...(matiere && { matiere }),
                ...(couleurMonture && { couleurMonture }),
                ...(couleurBranches && { couleurBranches }),
                ...(calibre && { calibre }),
                ...(pont && { pont }),
                ...(branche && { branche }),
                ...(typeCharniere && { typeCharniere }),
                ...(typeMonture && { typeMonture }),
                ...(photoFace && { photoFace }),
                ...(photoProfil && { photoProfil }),
                ...(typeVerre && { typeVerre }),
                ...(materiau && { materiau }),
                ...(indiceRefraction && { indiceRefraction }),
                ...(teinte && { teinte }),
                ...(filtres && { filtres }),
                ...(traitements && { traitements }),
                ...(puissanceSph && { puissanceSph }),
                ...(puissanceCyl && { puissanceCyl }),
                ...(axe && { axe }),
                ...(addition && { addition }),
                ...(diametre && { diametre }),
                ...(base && { base }),
                ...(courbure && { courbure }),
                ...(fabricant && { fabricant }),
                ...(familleOptique && { familleOptique }),
                ...(typeLentille && { typeLentille }),
                ...(usage && { usage }),
                ...(modeleCommercial && { modeleCommercial }),
                ...(laboratoire && { laboratoire }),
                ...(rayonCourbure && { rayonCourbure }),
                ...(nombreParBoite && { nombreParBoite }),
                ...(prixParBoite && { prixParBoite }),
                ...(prixParUnite && { prixParUnite }),
                ...(numeroLot && { numeroLot }),
                ...(datePeremption && { datePeremption }),
                ...(quantiteBoites && { quantiteBoites }),
                ...(quantiteUnites && { quantiteUnites }),
                ...(categorieAccessoire && { categorieAccessoire }),
                ...(sousCategorie && { sousCategorie }),
            };
            const rawCodeBarres = mainAndRelationalFields.codeBarres;
            const codeBarres = rawCodeBarres && rawCodeBarres.trim().length > 0
                ? rawCodeBarres
                : mainAndRelationalFields.codeInterne;
            const resolvedCodeBarres = codeBarres ||
                (mainAndRelationalFields.codeInterne
                    ? mainAndRelationalFields.codeInterne
                    : null);
            return await this.prisma.$transaction(async (tx) => {
                const product = await tx.product.create({
                    data: {
                        ...mainAndRelationalFields,
                        codeBarres: resolvedCodeBarres,
                        statut: mainAndRelationalFields.statut ?? 'DISPONIBLE',
                        specificData: newSpecificData,
                        utilisateurCreation: mainAndRelationalFields.utilisateurCreation || 'system',
                    },
                });
                if (product.quantiteActuelle > 0) {
                    await tx.mouvementStock.create({
                        data: {
                            type: 'INVENTAIRE',
                            quantite: product.quantiteActuelle,
                            produitId: product.id,
                            entrepotDestinationId: product.entrepotId,
                            motif: 'Stock Initial (Création Fiche)',
                            utilisateur: product.utilisateurCreation || 'System',
                        },
                    });
                }
                return product;
            });
        }
        catch (error) {
            console.error('Error creating product:', error);
            if (error instanceof Error) {
                console.error(error.stack);
            }
            throw error;
        }
    }
    async findAll(entrepotId, centreId, globalSearch = false, filters) {
        const where = {};
        if (!centreId && !entrepotId && !globalSearch)
            return [];
        if (entrepotId) {
            where.entrepotId = entrepotId;
        }
        else if (!globalSearch && centreId) {
            where.entrepot = { centreId };
        }
        if (filters) {
            if (filters.marque) {
                where.marque = { contains: filters.marque, mode: 'insensitive' };
            }
            if (filters.typeArticle) {
                where.typeArticle = filters.typeArticle;
            }
            if (filters.reference) {
                where.codeInterne = {
                    contains: filters.reference,
                    mode: 'insensitive',
                };
            }
            if (filters.codeBarres) {
                where.codeBarres = {
                    contains: filters.codeBarres,
                    mode: 'insensitive',
                };
            }
        }
        const products = await this.prisma.product.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            include: {
                entrepot: {
                    include: {
                        centre: true,
                    },
                },
                mouvements: {
                    take: 1,
                    orderBy: { dateMovement: 'desc' },
                },
            },
        });
        return products.map((p) => {
            if (p.quantiteActuelle > 0 &&
                (p.statut === 'RESERVE' || p.statut === 'EN_TRANSIT')) {
                p.statut = 'DISPONIBLE';
            }
            return p;
        });
    }
    async findOne(id) {
        const product = await this.prisma.product.findUnique({
            where: { id },
            include: {
                entrepot: {
                    include: { centre: true },
                },
                mouvements: {
                    take: 1,
                    orderBy: { dateMovement: 'desc' },
                },
            },
        });
        if (!product) {
            throw new common_1.NotFoundException(`Product with ID ${id} not found`);
        }
        return product;
    }
    async update(id, updateProductDto) {
        const { categorie, genre, forme, matiere, couleurMonture, couleurBranches, calibre, pont, branche, typeCharniere, typeMonture, photoFace, photoProfil, typeVerre, materiau, indiceRefraction, teinte, filtres, traitements, puissanceSph, puissanceCyl, axe, addition, diametre, base, courbure, fabricant, familleOptique, typeLentille, usage, modeleCommercial, laboratoire, rayonCourbure, nombreParBoite, prixParBoite, prixParUnite, numeroLot, datePeremption, quantiteBoites, quantiteUnites, categorieAccessoire, sousCategorie, specificData, ...mainFields } = updateProductDto;
        const specificFieldsUpdate = {
            ...(categorie && { categorie }),
            ...(genre && { genre }),
            ...(forme && { forme }),
            ...(matiere && { matiere }),
            ...(couleurMonture && { couleurMonture }),
            ...(couleurBranches && { couleurBranches }),
            ...(calibre && { calibre }),
            ...(pont && { pont }),
            ...(branche && { branche }),
            ...(typeCharniere && { typeCharniere }),
            ...(typeMonture && { typeMonture }),
            ...(photoFace && { photoFace }),
            ...(photoProfil && { photoProfil }),
            ...(typeVerre && { typeVerre }),
            ...(materiau && { materiau }),
            ...(indiceRefraction && { indiceRefraction }),
            ...(teinte && { teinte }),
            ...(filtres && { filtres }),
            ...(traitements && { traitements }),
            ...(puissanceSph && { puissanceSph }),
            ...(puissanceCyl && { puissanceCyl }),
            ...(axe && { axe }),
            ...(addition && { addition }),
            ...(diametre && { diametre }),
            ...(base && { base }),
            ...(courbure && { courbure }),
            ...(fabricant && { fabricant }),
            ...(familleOptique && { familleOptique }),
            ...(typeLentille && { typeLentille }),
            ...(usage && { usage }),
            ...(modeleCommercial && { modeleCommercial }),
            ...(laboratoire && { laboratoire }),
            ...(rayonCourbure && { rayonCourbure }),
            ...(nombreParBoite && { nombreParBoite }),
            ...(prixParBoite && { prixParBoite }),
            ...(prixParUnite && { prixParUnite }),
            ...(numeroLot && { numeroLot }),
            ...(datePeremption && { datePeremption }),
            ...(quantiteBoites && { quantiteBoites }),
            ...(quantiteUnites && { quantiteUnites }),
            ...(categorieAccessoire && { categorieAccessoire }),
            ...(sousCategorie && { sousCategorie }),
            ...specificData,
        };
        const dataToUpdate = { ...mainFields };
        if (Object.keys(specificFieldsUpdate).length > 0) {
            const current = await this.prisma.product.findUnique({ where: { id } });
            if (current) {
                const currentSpecific = current.specificData || {};
                dataToUpdate.specificData = {
                    ...currentSpecific,
                    ...specificFieldsUpdate,
                };
            }
        }
        return this.prisma.product.update({
            where: { id },
            data: dataToUpdate,
        });
    }
    async remove(id) {
        const product = await this.prisma.product.findUnique({
            where: { id },
            include: {
                mouvements: { take: 1 },
                _count: {
                    select: { mouvements: true },
                },
            },
        });
        if (!product) {
            throw new common_1.NotFoundException(`Produit non trouvé`);
        }
        if (product.quantiteActuelle > 0) {
            throw new Error(`Suppression impossible : ce produit possède encore du stock (${product.quantiteActuelle}). Veuillez d'abord sortir le stock manuellement.`);
        }
        if (product._count.mouvements > 0) {
            throw new Error(`Suppression impossible : ce produit possède un historique de mouvements de stock (${product._count.mouvements}). Pour la traçabilité, vous ne pouvez pas le supprimer.`);
        }
        const allInvoices = await this.prisma.facture.findMany({
            select: { id: true, numero: true, lignes: true },
        });
        const linkedInvoice = allInvoices.find((inv) => {
            const lines = (typeof inv.lignes === 'string' ? JSON.parse(inv.lignes) : inv.lignes);
            return lines.some((line) => line.productId === id);
        });
        if (linkedInvoice) {
            throw new Error(`Suppression impossible : ce produit est référencé dans la facture ${linkedInvoice.numero}.`);
        }
        return this.prisma.product.delete({
            where: { id },
        });
    }
    async findLocalCounterpart(params, tx) {
        const { designation, codeInterne, codeBarres, centreId, entrepotId, couleur, } = params;
        const client = tx || this.prisma;
        if (codeInterne || codeBarres) {
            const byRef = await client.product.findFirst({
                where: {
                    entrepot: { centreId },
                    entrepotId: entrepotId || undefined,
                    OR: [
                        codeInterne ? { codeInterne } : {},
                        codeBarres ? { codeBarres } : {},
                    ].filter((q) => Object.keys(q).length > 0),
                    ...(couleur
                        ? { couleur: { equals: couleur, mode: 'insensitive' } }
                        : {}),
                },
                orderBy: [
                    { quantiteActuelle: 'desc' },
                    { createdAt: 'asc' },
                ],
                include: { entrepot: true },
            });
            if (byRef)
                return byRef;
        }
        return client.product.findFirst({
            where: {
                entrepot: { centreId },
                entrepotId: entrepotId || undefined,
                designation: { equals: designation, mode: 'insensitive' },
                ...(couleur
                    ? { couleur: { equals: couleur, mode: 'insensitive' } }
                    : {}),
            },
            orderBy: [{ quantiteActuelle: 'desc' }, { createdAt: 'asc' }],
            include: { entrepot: true },
        });
    }
    async initiateTransfer(sourceProductId, targetProductId, quantite = 1) {
        const sourceProduct = await this.prisma.product.findUnique({
            where: { id: sourceProductId },
            include: { entrepot: { include: { centre: true } } },
        });
        const targetProduct = await this.prisma.product.findUnique({
            where: { id: targetProductId },
            include: { entrepot: { include: { centre: true } } },
        });
        if (!sourceProduct || !targetProduct)
            throw new common_1.NotFoundException('Source or Target product not found');
        if (sourceProductId === targetProductId)
            throw new Error('Impossible de transférer un produit vers lui-même (Source = Destination).');
        if (sourceProduct.quantiteActuelle < quantite)
            throw new Error('Stock insuffisant à la source');
        console.log(`[TRANSFER] Init from ${sourceProduct.entrepot?.centre?.nom} (${sourceProductId}) to ${targetProduct.entrepot?.centre?.nom} (${targetProductId}) Qty: ${quantite}`);
        return this.prisma.$transaction(async (tx) => {
            const transferNumber = await this.generateNextTransferNumber(tx);
            const targetSpecificData = targetProduct.specificData || {};
            const updatedTargetData = {
                ...targetSpecificData,
                pendingIncoming: {
                    numeroTransfert: transferNumber,
                    sourceProductId: sourceProduct.id,
                    sourceCentreId: sourceProduct.entrepot?.centreId,
                    sourceCentreName: sourceProduct.entrepot?.centre?.nom,
                    status: 'RESERVED',
                    quantite: quantite,
                    date: new Date().toISOString(),
                },
            };
            const sourceSpecificData = sourceProduct.specificData || {};
            const updatedSourceData = {
                ...sourceSpecificData,
                pendingOutgoing: [
                    ...(sourceSpecificData.pendingOutgoing || []),
                    {
                        numeroTransfert: transferNumber,
                        targetProductId: targetProduct.id,
                        status: 'RESERVED',
                        quantite: quantite,
                        date: new Date().toISOString(),
                    },
                ],
            };
            await tx.product.update({
                where: { id: sourceProductId },
                data: {
                    quantiteActuelle: { decrement: quantite },
                    specificData: updatedSourceData,
                },
            });
            await tx.product.update({
                where: { id: targetProductId },
                data: {
                    statut: 'RESERVE',
                    specificData: updatedTargetData,
                },
            });
            return tx.mouvementStock.create({
                data: {
                    type: 'TRANSFERT_INIT',
                    quantite: -quantite,
                    produitId: sourceProductId,
                    entrepotSourceId: sourceProduct.entrepotId,
                    entrepotDestinationId: targetProduct.entrepotId,
                    motif: `${transferNumber} - Réservation pour ${targetProduct.entrepot?.centre?.nom}`,
                    utilisateur: 'System',
                },
            });
        });
    }
    async shipTransfer(targetProductId) {
        const targetProduct = await this.prisma.product.findUnique({
            where: { id: targetProductId },
        });
        if (!targetProduct)
            throw new common_1.NotFoundException('Target product not found');
        const tsd = targetProduct.specificData || {};
        if (!tsd.pendingIncoming)
            throw new Error('Aucun transfert entrant trouvé');
        tsd.pendingIncoming.status = 'SHIPPED';
        const sourceProductId = tsd.pendingIncoming.sourceProductId;
        return this.prisma.$transaction(async (tx) => {
            await tx.product.update({
                where: { id: targetProductId },
                data: {
                    statut: 'EN_TRANSIT',
                    specificData: tsd,
                },
            });
            if (sourceProductId) {
                const sourceProduct = await tx.product.findUnique({
                    where: { id: sourceProductId },
                });
                if (sourceProduct) {
                    const ssd = sourceProduct.specificData || {};
                    if (ssd.pendingOutgoing) {
                        const outgoing = ssd.pendingOutgoing.find((t) => t.targetProductId === targetProductId);
                        if (outgoing)
                            outgoing.status = 'SHIPPED';
                        await tx.product.update({
                            where: { id: sourceProductId },
                            data: { specificData: ssd },
                        });
                    }
                }
            }
            return { success: true };
        });
    }
    async bulkShip(targetProductIds) {
        console.log('[BULK-SHIP] Received request with IDs:', targetProductIds);
        if (!targetProductIds || targetProductIds.length === 0) {
            throw new common_1.BadRequestException("Aucun produit sélectionné pour l'expédition");
        }
        const results = [];
        const errors = [];
        for (const id of targetProductIds) {
            try {
                console.log(`[BULK-SHIP] Processing ID: ${id}`);
                await this.shipTransfer(id);
                results.push(id);
                console.log(`[BULK-SHIP] ✅ Success for ID: ${id}`);
            }
            catch (error) {
                console.error(`[BULK-SHIP] ❌ Error shipping ${id}:`, error.message);
                errors.push({ id, error: error.message });
            }
        }
        console.log(`[BULK-SHIP] Complete. Success: ${results.length}, Failures: ${errors.length}`);
        return {
            successCount: results.length,
            failureCount: errors.length,
            errors,
        };
    }
    async bulkReceive(targetProductIds) {
        console.log('[BULK-RECEIVE] Received request with IDs:', targetProductIds);
        if (!targetProductIds || targetProductIds.length === 0) {
            throw new common_1.BadRequestException('Aucun produit sélectionné pour la réception');
        }
        const results = [];
        const errors = [];
        for (const id of targetProductIds) {
            try {
                console.log(`[BULK-RECEIVE] Processing ID: ${id}`);
                await this.completeTransfer(id);
                results.push(id);
                console.log(`[BULK-RECEIVE] ✅ Success for ID: ${id}`);
            }
            catch (error) {
                console.error(`[BULK-RECEIVE] ❌ Error receiving ${id}:`, error.message);
                errors.push({ id, error: error.message });
            }
        }
        console.log(`[BULK-RECEIVE] Complete. Success: ${results.length}, Failures: ${errors.length}`);
        return {
            successCount: results.length,
            failureCount: errors.length,
            errors,
        };
    }
    async cancelTransfer(targetProductId) {
        const targetProduct = await this.prisma.product.findUnique({
            where: { id: targetProductId },
        });
        if (!targetProduct)
            throw new common_1.NotFoundException('Product not found');
        const targetSd = targetProduct.specificData || {};
        const sourceProductId = targetSd.pendingIncoming?.sourceProductId;
        if (!sourceProductId)
            throw new Error('Informations de source manquantes');
        const quantiteARendre = targetSd.pendingIncoming?.quantite || 1;
        const { pendingIncoming: _, ...cleanedTargetSd } = targetSd;
        return this.prisma.$transaction(async (tx) => {
            await tx.product.update({
                where: { id: sourceProductId },
                data: {
                    quantiteActuelle: { increment: quantiteARendre },
                    statut: 'DISPONIBLE',
                },
            });
            const sourceProduct = await tx.product.findUnique({
                where: { id: sourceProductId },
            });
            if (sourceProduct) {
                const sourceSd = sourceProduct.specificData || {};
                if (sourceSd.pendingOutgoing) {
                    sourceSd.pendingOutgoing = sourceSd.pendingOutgoing.filter((t) => t.targetProductId !== targetProductId);
                    await tx.product.update({
                        where: { id: sourceProductId },
                        data: { specificData: sourceSd },
                    });
                }
            }
            const newStatus = targetProduct.quantiteActuelle > 0 ? 'DISPONIBLE' : 'RUPTURE';
            return tx.product.update({
                where: { id: targetProductId },
                data: {
                    specificData: cleanedTargetSd,
                    statut: newStatus,
                },
            });
        });
    }
    async completeTransfer(targetProductId) {
        const targetProduct = await this.prisma.product.findUnique({
            where: { id: targetProductId },
            include: { entrepot: true },
        });
        if (!targetProduct)
            throw new common_1.NotFoundException('Product not found');
        const sd = targetProduct.specificData || {};
        if (!sd.pendingIncoming)
            throw new Error('Aucun transfert entrant trouvé');
        if (sd.pendingIncoming.status !== 'SHIPPED') {
            throw new Error("Le transfert doit être expédié par la source avant d'être reçu.");
        }
        const sourceProductId = sd.pendingIncoming.sourceProductId;
        const quantiteRecue = sd.pendingIncoming.quantite || 1;
        const { pendingIncoming, ...restSd } = sd;
        const lastTransferReception = {
            date: new Date().toISOString(),
            sourceCentreId: pendingIncoming.sourceCentreId,
            sourceCentreName: pendingIncoming.sourceCentreName,
            numeroTransfert: pendingIncoming.numeroTransfert,
            sourceProductId: pendingIncoming.sourceProductId,
        };
        const updatedSd = { ...restSd, lastTransferReception };
        return this.prisma.$transaction(async (tx) => {
            await tx.product.update({
                where: { id: targetProductId },
                data: {
                    quantiteActuelle: { increment: quantiteRecue },
                    statut: 'DISPONIBLE',
                    specificData: updatedSd,
                },
            });
            if (sourceProductId) {
                const sourceProduct = await tx.product.findUnique({
                    where: { id: sourceProductId },
                });
                if (sourceProduct) {
                    const sourceSd = sourceProduct.specificData || {};
                    if (sourceSd.pendingOutgoing) {
                        sourceSd.pendingOutgoing = sourceSd.pendingOutgoing.filter((t) => t.targetProductId !== targetProductId);
                        await tx.product.update({
                            where: { id: sourceProductId },
                            data: { specificData: sourceSd },
                        });
                    }
                }
            }
            return tx.mouvementStock.create({
                data: {
                    type: 'RECEPTION',
                    quantite: quantiteRecue,
                    produitId: targetProductId,
                    entrepotDestinationId: targetProduct.entrepotId,
                    prixAchatUnitaire: targetProduct.prixAchatHT,
                    prixVenteUnitaire: targetProduct.prixVenteTTC,
                    motif: `${sd.pendingIncoming.numeroTransfert || 'TRS-NEW'} - Réception`,
                    utilisateur: 'System',
                },
            });
        });
    }
    async getStockStats(centreId) {
        if (!centreId) {
            return {
                totalArticles: 0,
                totalProduits: 0,
                totalUnites: 0,
                valeurStockTotal: 0,
                caNonConsolide: 0,
                produitsStockBas: 0,
                produitsRupture: 0,
                produitsReserves: 0,
                produitsEnTransit: 0,
            };
        }
        const allProducts = await this.prisma.product.findMany({
            where: { entrepot: { centreId } },
            include: { entrepot: true },
        });
        const stats = {
            totalArticles: 0,
            totalProduits: 0,
            totalUnites: 0,
            valeurStockTotal: 0,
            caNonConsolide: 0,
            produitsStockBas: 0,
            produitsRupture: 0,
            produitsReserves: 0,
            produitsEnTransit: 0,
            byType: {
                montures: 0,
                verres: 0,
                lentilles: 0,
                accessoires: 0,
            },
        };
        allProducts.forEach((p) => {
            const isDefective = p.entrepot?.nom?.toLowerCase().includes('défectueux') ||
                p.entrepot?.nom?.toLowerCase().includes('defectueux') ||
                p.entrepot?.nom?.toUpperCase() === 'DÉFECTUEUX';
            if (isDefective) {
                stats.caNonConsolide += p.quantiteActuelle * (p.prixAchatHT || 0);
            }
            else {
                stats.totalArticles++;
                stats.totalUnites += p.quantiteActuelle;
                stats.valeurStockTotal += p.quantiteActuelle * (p.prixAchatHT || 0);
                if (p.quantiteActuelle > 0) {
                    stats.totalProduits++;
                }
                if (p.quantiteActuelle > 0 && p.quantiteActuelle <= p.seuilAlerte) {
                    stats.produitsStockBas++;
                }
                if (p.quantiteActuelle <= 0) {
                    stats.produitsRupture++;
                }
                const sd = p.specificData || {};
                if (sd.pendingIncoming?.status === 'RESERVED') {
                    stats.produitsReserves++;
                }
                if (sd.pendingIncoming?.status === 'SHIPPED') {
                    stats.produitsEnTransit++;
                }
                const type = p.typeArticle;
                if (type === 'MONTURE_OPTIQUE' ||
                    type === 'MONTURE_SOLAIRE' ||
                    type === 'monture') {
                    stats.byType.montures += p.quantiteActuelle;
                }
                else if (type === 'VERRE' || type === 'verre') {
                    stats.byType.verres += p.quantiteActuelle;
                }
                else if (type === 'LENTILLE' || type === 'lentille') {
                    stats.byType.lentilles += p.quantiteActuelle;
                }
                else if (type === 'ACCESSOIRE' || type === 'accessoire') {
                    stats.byType.accessoires += p.quantiteActuelle;
                }
            }
        });
        return stats;
    }
    async restock(id, quantite, motif, utilisateur = 'System', prixAchatHT, remiseFournisseur) {
        try {
            const product = await this.prisma.product.findUnique({ where: { id } });
            if (!product)
                throw new common_1.NotFoundException('Produit non trouvé');
            const cleanQuantite = isNaN(Number(quantite)) ? 0 : Number(quantite);
            const cleanNewPrice = prixAchatHT !== undefined && !isNaN(Number(prixAchatHT))
                ? Number(prixAchatHT)
                : undefined;
            const cleanRemise = remiseFournisseur !== undefined && !isNaN(Number(remiseFournisseur))
                ? Number(remiseFournisseur)
                : 0;
            if (cleanQuantite <= 0)
                throw new common_1.BadRequestException('La quantité doit être supérieure à 0');
            if (!product.entrepotId)
                throw new common_1.BadRequestException("Le produit n'est rattaché à aucun entrepôt");
            const finalNewPriceHT = cleanNewPrice !== undefined
                ? cleanNewPrice * (1 - cleanRemise / 100)
                : undefined;
            return await this.prisma.$transaction(async (tx) => {
                let updatedPrixAchatHT = product.prixAchatHT;
                if (finalNewPriceHT !== undefined) {
                    const currentStock = product.quantiteActuelle > 0 ? product.quantiteActuelle : 0;
                    const currentValue = currentStock * product.prixAchatHT;
                    const newValue = cleanQuantite * finalNewPriceHT;
                    updatedPrixAchatHT =
                        (currentValue + newValue) / (currentStock + cleanQuantite);
                    updatedPrixAchatHT = Math.round(updatedPrixAchatHT * 100) / 100;
                }
                await tx.product.update({
                    where: { id },
                    data: {
                        quantiteActuelle: { increment: cleanQuantite },
                        prixAchatHT: updatedPrixAchatHT,
                    },
                });
                return tx.mouvementStock.create({
                    data: {
                        type: 'ENTREE_ACHAT',
                        quantite: cleanQuantite,
                        produitId: id,
                        entrepotDestinationId: product.entrepotId,
                        motif: motif || 'Réapprovisionnement manuel',
                        utilisateur: utilisateur || 'System',
                        prixAchatUnitaire: finalNewPriceHT !== undefined
                            ? finalNewPriceHT
                            : product.prixAchatHT,
                    },
                });
            });
        }
        catch (error) {
            console.error(`[RESTOCK-ERROR] Failed for product ${id}:`, error);
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException)
                throw error;
            throw new common_1.BadRequestException(error.message ||
                'Une erreur est survenue lors de la mise à jour du stock');
        }
    }
    async destock(id, quantite, motif, destinationEntrepotId, utilisateur = 'System') {
        try {
            const product = await this.prisma.product.findUnique({
                where: { id },
                include: { entrepot: { include: { centre: true } } },
            });
            if (!product)
                throw new common_1.NotFoundException('Produit non trouvé');
            const cleanQuantite = isNaN(Number(quantite)) ? 0 : Number(quantite);
            if (cleanQuantite <= 0)
                throw new Error('La quantité doit être supérieure à 0');
            if (product.quantiteActuelle < cleanQuantite) {
                throw new Error(`Quantité insuffisante en stock (Actuel: ${product.quantiteActuelle})`);
            }
            return await this.prisma.$transaction(async (tx) => {
                let effectiveMotif = motif || 'Sortie manuelle';
                const isDefective = motif?.toLowerCase().includes('casse') ||
                    motif?.toLowerCase().includes('défectueux');
                let effectiveDestinationId = destinationEntrepotId;
                if (isDefective && !effectiveDestinationId) {
                    let defectiveWarehouse = await tx.entrepot.findFirst({
                        where: {
                            centreId: product.entrepot.centreId,
                            OR: [
                                { nom: { equals: 'Entrepot Défectueux', mode: 'insensitive' } },
                                { nom: { equals: 'DÉFECTUEUX', mode: 'insensitive' } },
                                { nom: { contains: 'défectueux', mode: 'insensitive' } },
                            ],
                        },
                    });
                    if (!defectiveWarehouse) {
                        defectiveWarehouse = await tx.entrepot.create({
                            data: {
                                nom: 'Entrepot Défectueux',
                                type: 'TRANSIT',
                                description: 'Entrepôt pour les retours défectueux et sorties de stock non consolidées',
                                centreId: product.entrepot.centreId,
                            },
                        });
                    }
                    effectiveDestinationId = defectiveWarehouse.id;
                }
                const updatedProduct = await tx.product.update({
                    where: { id },
                    data: {
                        quantiteActuelle: { decrement: cleanQuantite },
                        statut: product.quantiteActuelle - cleanQuantite <= 0
                            ? 'RUPTURE'
                            : product.statut,
                    },
                });
                let movementType = 'SORTIE_MANUELLE';
                if (effectiveDestinationId) {
                    movementType = 'TRANSFERT_SORTIE';
                }
                const currentMotif = motif || 'Sortie manuelle';
                await tx.mouvementStock.create({
                    data: {
                        type: movementType,
                        quantite: -cleanQuantite,
                        produitId: id,
                        entrepotSourceId: product.entrepotId,
                        entrepotDestinationId: effectiveDestinationId || null,
                        motif: currentMotif,
                        utilisateur: utilisateur || 'System',
                        prixAchatUnitaire: product.prixAchatHT,
                        prixVenteUnitaire: product.prixVenteTTC,
                    },
                });
                let targetProduct = null;
                let savedProduct = null;
                if (effectiveDestinationId) {
                    const destinationWh = await tx.entrepot.findUnique({
                        where: { id: effectiveDestinationId },
                    });
                    const isCrossCenter = destinationWh &&
                        destinationWh.centreId !== product.entrepot.centreId;
                    console.log(`🚚 [DESTOCK-DEBUG] Transfer requested. Dest: ${effectiveDestinationId} (${destinationWh?.nom})`);
                    console.log(`   📍 Source Center: ${product.entrepot.centreId} | Dest Center: ${destinationWh?.centreId}`);
                    console.log(`   🌍 Is Cross-Center? ${isCrossCenter}`);
                    targetProduct = await tx.product.findFirst({
                        where: {
                            entrepotId: effectiveDestinationId,
                            OR: [
                                product.codeInterne ? { codeInterne: product.codeInterne } : {},
                                product.codeBarres ? { codeBarres: product.codeBarres } : {},
                                {
                                    designation: {
                                        equals: product.designation,
                                        mode: 'insensitive',
                                    },
                                },
                            ].filter((q) => Object.keys(q).length > 0),
                        },
                    });
                    if (!targetProduct) {
                        console.log(`   ⭐️ Creating new product in target warehouse...`);
                        const { id: _, entrepotId: __, entrepot: ___, mouvements: ____, createdAt: _____, updatedAt: ______, ...prodData } = product;
                        targetProduct = await tx.product.create({
                            data: {
                                ...prodData,
                                entrepotId: effectiveDestinationId,
                                quantiteActuelle: 0,
                                statut: 'DISPONIBLE',
                            },
                        });
                    }
                    if (isCrossCenter) {
                        const numeroTransfert = await this.generateNextTransferNumber(tx);
                        console.log(`   📝 Generating Transfer #${numeroTransfert}`);
                        const tsd = targetProduct.specificData || {};
                        const updatedTsd = {
                            ...tsd,
                            pendingIncoming: {
                                numeroTransfert,
                                sourceProductId: product.id,
                                sourceWarehouseId: product.entrepotId,
                                sourceCentreId: product.entrepot.centreId,
                                sourceCentreName: product.entrepot.centre?.nom,
                                status: 'RESERVED',
                                quantite: cleanQuantite,
                                date: new Date().toISOString(),
                            },
                        };
                        const ssd = updatedProduct.specificData || {};
                        const existingOutgoing = Array.isArray(ssd.pendingOutgoing)
                            ? ssd.pendingOutgoing
                            : [];
                        const updatedSsd = {
                            ...ssd,
                            pendingOutgoing: [
                                ...existingOutgoing,
                                {
                                    targetProductId: targetProduct.id,
                                    status: 'RESERVED',
                                    quantite: cleanQuantite,
                                    date: new Date().toISOString(),
                                    numeroTransfert,
                                },
                            ],
                        };
                        console.log(`   💾 Updating Source Product ${updatedProduct.id} with pendingOutgoing`, updatedSsd.pendingOutgoing);
                        targetProduct = await tx.product.update({
                            where: { id: targetProduct.id },
                            data: {
                                statut: 'RESERVE',
                                specificData: updatedTsd,
                            },
                        });
                        console.log(`   🎯 [DESTOCK-DEBUG] Target Product AFTER update:`, {
                            id: targetProduct.id,
                            entrepotId: targetProduct.entrepotId,
                            specificDataType: typeof targetProduct.specificData,
                            hasPendingIncoming: !!targetProduct.specificData?.pendingIncoming,
                            pendingIncomingStatus: targetProduct.specificData?.pendingIncoming?.status,
                        });
                        savedProduct = await tx.product.update({
                            where: { id: updatedProduct.id },
                            data: { specificData: updatedSsd },
                        });
                        console.log(`   ✅ [DESTOCK-VERIFY] Saved Source Product ${savedProduct.id}. pendingOutgoing length: ${savedProduct.specificData?.pendingOutgoing?.length}`);
                        const trsMotif = `${numeroTransfert} - Transfert AUTO`;
                        await tx.mouvementStock.updateMany({
                            where: {
                                produitId: id,
                                type: 'TRANSFERT_SORTIE',
                                motif: currentMotif,
                                createdAt: { gte: new Date(Date.now() - 5000) },
                            },
                            data: { motif: `${numeroTransfert} - ${currentMotif}` },
                        });
                        effectiveMotif = trsMotif;
                    }
                    else {
                        targetProduct = await tx.product.update({
                            where: { id: targetProduct.id },
                            data: { quantiteActuelle: { increment: cleanQuantite } },
                        });
                    }
                    await tx.mouvementStock.create({
                        data: {
                            type: 'TRANSFERT_ENTREE',
                            quantite: cleanQuantite,
                            produitId: targetProduct.id,
                            entrepotSourceId: product.entrepotId,
                            entrepotDestinationId: effectiveDestinationId,
                            motif: effectiveMotif,
                            utilisateur: utilisateur,
                            prixAchatUnitaire: product.prixAchatHT,
                            prixVenteUnitaire: product.prixVenteTTC,
                        },
                    });
                }
                console.log(`   🔍 [DESTOCK-FINAL] Returning:`, {
                    sourceId: (savedProduct || updatedProduct).id,
                    targetId: targetProduct?.id,
                    targetHasSpecificData: !!targetProduct?.specificData,
                    targetPendingIncoming: targetProduct?.specificData?.pendingIncoming,
                });
                return {
                    source: savedProduct || updatedProduct,
                    target: targetProduct,
                };
            });
        }
        catch (error) {
            console.error(`[DESTOCK-ERROR] Failed for product ${id}:`, error);
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException)
                throw error;
            throw new common_1.BadRequestException(error.message || 'Une erreur est survenue lors de la sortie de stock');
        }
    }
    async getTransferHistory(params) {
        const { startDate, endDate, centreId, productId, type } = params;
        const where = {
            type: type
                ? type
                : {
                    in: [
                        'TRANSFERT_INIT',
                        'TRANSFERT_SORTIE',
                        'TRANSFERT_ENTREE',
                        'RECEPTION',
                        'TRANSFERT_ANNULE',
                        'EXPEDITION',
                    ],
                },
        };
        if (startDate || endDate) {
            where.dateMovement = {};
            if (startDate)
                where.dateMovement.gte = new Date(startDate);
            if (endDate)
                where.dateMovement.lte = new Date(endDate);
        }
        if (productId) {
            where.produitId = productId;
        }
        if (centreId) {
            where.OR = [
                { produit: { entrepot: { centreId } } },
                { entrepotSource: { centreId } },
                { entrepotDestination: { centreId } },
            ];
        }
        return this.prisma.mouvementStock.findMany({
            where,
            include: {
                produit: {
                    include: {
                        entrepot: {
                            include: { centre: true },
                        },
                    },
                },
                entrepotSource: { include: { centre: true } },
                entrepotDestination: { include: { centre: true } },
            },
            orderBy: { dateMovement: 'desc' },
        });
    }
    async syncProductState(productId, tx) {
        const prisma = tx || this.prisma;
        const product = await prisma.product.findUnique({
            where: { id: productId },
            include: {
                mouvements: {
                    orderBy: { dateMovement: 'asc' },
                },
            },
        });
        if (!product)
            return;
        if (product.mouvements.length === 0) {
            if (product.utilisateurCreation === 'system' ||
                product.utilisateurCreation === 'System') {
                return await prisma.product.delete({ where: { id: productId } });
            }
            return await prisma.product.update({
                where: { id: productId },
                data: { quantiteActuelle: 0, prixAchatHT: product.prixAchatHT || 0 },
            });
        }
        const newQty = product.mouvements.reduce((sum, mov) => sum + mov.quantite, 0);
        let calculatedPMP = 0;
        let currentQtyForPMP = 0;
        for (const mov of product.mouvements) {
            if (mov.quantite > 0) {
                const entryQty = mov.quantite;
                const entryPrice = mov.prixAchatUnitaire || 0;
                if (currentQtyForPMP <= 0) {
                    calculatedPMP = entryPrice;
                }
                else {
                    const currentValue = currentQtyForPMP * calculatedPMP;
                    const entryValue = entryQty * entryPrice;
                    calculatedPMP =
                        (currentValue + entryValue) / (currentQtyForPMP + entryQty);
                }
                currentQtyForPMP += entryQty;
            }
            else if (mov.quantite < 0) {
                currentQtyForPMP += mov.quantite;
                if (currentQtyForPMP < 0)
                    currentQtyForPMP = 0;
            }
        }
        return await prisma.product.update({
            where: { id: productId },
            data: {
                quantiteActuelle: newQty,
                prixAchatHT: Math.round(calculatedPMP * 100) / 100,
                statut: newQty > 0 ? 'DISPONIBLE' : 'RUPTURE',
            },
        });
    }
    async cleanupOutOfStock(centreId) {
        const productsInRupture = await this.prisma.product.findMany({
            where: {
                quantiteActuelle: { lte: 0 },
                entrepot: { centreId },
                statut: { not: 'OBSOLETE' },
            },
        });
        let deletedCount = 0;
        let archivedCount = 0;
        for (const product of productsInRupture) {
            try {
                await this.prisma.product.delete({
                    where: { id: product.id },
                });
                deletedCount++;
            }
            catch (e) {
                try {
                    await this.prisma.product.update({
                        where: { id: product.id },
                        data: { statut: 'OBSOLETE' },
                    });
                    archivedCount++;
                }
                catch (archiveError) {
                    console.error(`Failed to archive product ${product.id}:`, archiveError);
                }
            }
        }
        return { deletedCount, archivedCount };
    }
};
exports.ProductsService = ProductsService;
exports.ProductsService = ProductsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ProductsService);
//# sourceMappingURL=products.service.js.map