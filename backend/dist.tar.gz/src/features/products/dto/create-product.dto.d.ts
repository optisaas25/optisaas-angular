export declare enum ProductType {
    MONTURE = "monture",
    VERRE = "verre",
    LENTILLE = "lentille",
    ACCESSOIRE = "accessoire"
}
export declare class CreateProductDto {
    typeArticle: ProductType;
    codeInterne: string;
    codeBarres?: string;
    referenceFournisseur?: string;
    designation: string;
    marque?: string;
    modele?: string;
    couleur?: string;
    famille?: string;
    sousFamille?: string;
    fournisseurPrincipal?: string;
    quantiteActuelle: number;
    seuilAlerte: number;
    prixAchatHT: number;
    coefficient: number;
    prixVenteHT: number;
    prixVenteTTC: number;
    tauxTVA: number;
    statut?: string;
    utilisateurCreation?: string;
    photo?: string;
    entrepotId: string;
    specificData?: any;
    categorie?: string;
    genre?: string;
    forme?: string;
    matiere?: string;
    couleurMonture?: string;
    couleurBranches?: string;
    calibre?: number;
    pont?: number;
    branche?: number;
    typeCharniere?: string;
    typeMonture?: string;
    typeVerre?: string;
    materiau?: string;
    indiceRefraction?: number;
    teinte?: string;
    puissanceSph?: number;
    puissanceCyl?: number;
    axe?: number;
    addition?: number;
    diametre?: number;
    typeLentille?: string;
    usage?: string;
    rayonCourbure?: number;
    categorieAccessoire?: string;
    photoFace?: string;
    photoProfil?: string;
    filtres?: string[];
    traitements?: string[];
    base?: number;
    courbure?: number;
    fabricant?: string;
    familleOptique?: string;
    modeleCommercial?: string;
    laboratoire?: string;
    nombreParBoite?: number;
    prixParBoite?: number;
    prixParUnite?: number;
    numeroLot?: string;
    datePeremption?: string;
    quantiteBoites?: number;
    quantiteUnites?: number;
    sousCategorie?: string;
}
