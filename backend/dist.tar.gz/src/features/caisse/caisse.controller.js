"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaisseController = void 0;
const common_1 = require("@nestjs/common");
const caisse_service_1 = require("./caisse.service");
const create_caisse_dto_1 = require("./dto/create-caisse.dto");
const update_caisse_dto_1 = require("./dto/update-caisse.dto");
let CaisseController = class CaisseController {
    caisseService;
    constructor(caisseService) {
        this.caisseService = caisseService;
    }
    create(createCaisseDto) {
        return this.caisseService.create(createCaisseDto);
    }
    findAll() {
        return this.caisseService.findAll();
    }
    findOne(id) {
        return this.caisseService.findOne(id);
    }
    findByCentre(centreId) {
        return this.caisseService.findByCentre(centreId);
    }
    update(id, updateCaisseDto) {
        return this.caisseService.update(id, updateCaisseDto);
    }
    remove(id) {
        return this.caisseService.remove(id);
    }
};
exports.CaisseController = CaisseController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_caisse_dto_1.CreateCaisseDto]),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('centre/:centreId'),
    __param(0, (0, common_1.Param)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "findByCentre", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_caisse_dto_1.UpdateCaisseDto]),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CaisseController.prototype, "remove", null);
exports.CaisseController = CaisseController = __decorate([
    (0, common_1.Controller)('caisse'),
    __metadata("design:paramtypes", [caisse_service_1.CaisseService])
], CaisseController);
//# sourceMappingURL=caisse.controller.js.map