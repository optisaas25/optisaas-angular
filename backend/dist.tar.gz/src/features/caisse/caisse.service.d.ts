import { PrismaService } from '../../prisma/prisma.service';
import { CreateCaisseDto } from './dto/create-caisse.dto';
import { UpdateCaisseDto } from './dto/update-caisse.dto';
export declare class CaisseService {
    private prisma;
    constructor(prisma: PrismaService);
    create(createCaisseDto: CreateCaisseDto): Promise<{
        centre: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
    } & {
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    }>;
    findAll(): Promise<({
        centre: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
        journees: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            dateOuverture: Date;
            dateCloture: Date | null;
            fondInitial: number;
            soldeTheorique: number | null;
            soldeReel: number | null;
            ecart: number | null;
            justificationEcart: string | null;
            caissier: string;
            responsableCloture: string | null;
            totalComptable: number;
            totalInterne: number;
            totalDepenses: number;
            caisseId: string;
            totalTransfertsDepenses: number;
            totalVentesCarte: number;
            totalVentesEspeces: number;
            totalVentesCheque: number;
        }[];
    } & {
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    })[]>;
    findOne(id: string): Promise<{
        centre: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
        journees: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            dateOuverture: Date;
            dateCloture: Date | null;
            fondInitial: number;
            soldeTheorique: number | null;
            soldeReel: number | null;
            ecart: number | null;
            justificationEcart: string | null;
            caissier: string;
            responsableCloture: string | null;
            totalComptable: number;
            totalInterne: number;
            totalDepenses: number;
            caisseId: string;
            totalTransfertsDepenses: number;
            totalVentesCarte: number;
            totalVentesEspeces: number;
            totalVentesCheque: number;
        }[];
    } & {
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    }>;
    findByCentre(centreId: string): Promise<({
        centre: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
        journees: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            dateOuverture: Date;
            dateCloture: Date | null;
            fondInitial: number;
            soldeTheorique: number | null;
            soldeReel: number | null;
            ecart: number | null;
            justificationEcart: string | null;
            caissier: string;
            responsableCloture: string | null;
            totalComptable: number;
            totalInterne: number;
            totalDepenses: number;
            caisseId: string;
            totalTransfertsDepenses: number;
            totalVentesCarte: number;
            totalVentesEspeces: number;
            totalVentesCheque: number;
        }[];
    } & {
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    })[]>;
    update(id: string, updateCaisseDto: UpdateCaisseDto): Promise<{
        centre: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
    } & {
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    }>;
    remove(id: string): Promise<{
        id: string;
        type: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
    }>;
}
