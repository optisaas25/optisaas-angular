"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateCaisseDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_caisse_dto_1 = require("./create-caisse.dto");
class UpdateCaisseDto extends (0, mapped_types_1.PartialType)(create_caisse_dto_1.CreateCaisseDto) {
}
exports.UpdateCaisseDto = UpdateCaisseDto;
//# sourceMappingURL=update-caisse.dto.js.map