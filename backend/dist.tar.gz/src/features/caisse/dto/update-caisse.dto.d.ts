import { CreateCaisseDto } from './create-caisse.dto';
declare const UpdateCaisseDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateCaisseDto>>;
export declare class UpdateCaisseDto extends UpdateCaisseDto_base {
}
export {};
