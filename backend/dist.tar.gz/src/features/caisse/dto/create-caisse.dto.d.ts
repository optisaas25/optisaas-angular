export declare enum CaisseStatut {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE"
}
export declare enum CaisseType {
    PRINCIPALE = "PRINCIPALE",
    DEPENSES = "DEPENSES",
    MIXTE = "MIXTE"
}
export declare class CreateCaisseDto {
    nom: string;
    description?: string;
    type?: CaisseType;
    statut?: CaisseStatut;
    centreId: string;
}
