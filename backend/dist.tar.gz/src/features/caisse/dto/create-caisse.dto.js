"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCaisseDto = exports.CaisseType = exports.CaisseStatut = void 0;
const class_validator_1 = require("class-validator");
var CaisseStatut;
(function (CaisseStatut) {
    CaisseStatut["ACTIVE"] = "ACTIVE";
    CaisseStatut["INACTIVE"] = "INACTIVE";
})(CaisseStatut || (exports.CaisseStatut = CaisseStatut = {}));
var CaisseType;
(function (CaisseType) {
    CaisseType["PRINCIPALE"] = "PRINCIPALE";
    CaisseType["DEPENSES"] = "DEPENSES";
    CaisseType["MIXTE"] = "MIXTE";
})(CaisseType || (exports.CaisseType = CaisseType = {}));
class CreateCaisseDto {
    nom;
    description;
    type;
    statut;
    centreId;
}
exports.CreateCaisseDto = CreateCaisseDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCaisseDto.prototype, "nom", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCaisseDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(CaisseType),
    __metadata("design:type", String)
], CreateCaisseDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(CaisseStatut),
    __metadata("design:type", String)
], CreateCaisseDto.prototype, "statut", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCaisseDto.prototype, "centreId", void 0);
//# sourceMappingURL=create-caisse.dto.js.map