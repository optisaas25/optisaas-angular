export declare class CaisseModule {
}
