"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaisseService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let CaisseService = class CaisseService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createCaisseDto) {
        console.log('[DEBUG Caisse] Creating with:', JSON.stringify(createCaisseDto, null, 2));
        try {
            const existing = await this.prisma.caisse.findFirst({
                where: {
                    nom: createCaisseDto.nom,
                    centreId: createCaisseDto.centreId,
                },
            });
            if (existing) {
                console.log('[DEBUG Caisse] Conflict found:', existing.id);
                throw new common_1.ConflictException(`Une caisse avec le nom "${createCaisseDto.nom}" existe déjà dans ce centre`);
            }
            const result = await this.prisma.caisse.create({
                data: createCaisseDto,
                include: {
                    centre: true,
                },
            });
            console.log('[DEBUG Caisse] Success:', result.id);
            return result;
        }
        catch (err) {
            console.error('[DEBUG Caisse] Fatal Error:', err);
            throw err;
        }
    }
    async findAll() {
        return this.prisma.caisse.findMany({
            include: {
                centre: true,
                journees: {
                    where: {
                        statut: 'OUVERTE',
                    },
                    take: 1,
                    orderBy: {
                        dateOuverture: 'desc',
                    },
                },
            },
            orderBy: {
                createdAt: 'desc',
            },
        });
    }
    async findOne(id) {
        const caisse = await this.prisma.caisse.findUnique({
            where: { id },
            include: {
                centre: true,
                journees: {
                    orderBy: {
                        dateOuverture: 'desc',
                    },
                    take: 10,
                },
            },
        });
        if (!caisse) {
            throw new common_1.NotFoundException(`Caisse avec l'ID ${id} introuvable`);
        }
        return caisse;
    }
    async findByCentre(centreId) {
        return this.prisma.caisse.findMany({
            where: { centreId },
            include: {
                centre: true,
                journees: {
                    where: {
                        statut: 'OUVERTE',
                    },
                    take: 1,
                    orderBy: {
                        dateOuverture: 'desc',
                    },
                },
            },
            orderBy: {
                nom: 'asc',
            },
        });
    }
    async update(id, updateCaisseDto) {
        const caisse = await this.findOne(id);
        if (updateCaisseDto.nom) {
            const existing = await this.prisma.caisse.findFirst({
                where: {
                    nom: updateCaisseDto.nom,
                    centreId: caisse.centreId,
                    id: { not: id },
                },
            });
            if (existing) {
                throw new common_1.ConflictException(`Une caisse avec le nom "${updateCaisseDto.nom}" existe déjà dans ce centre`);
            }
        }
        return this.prisma.caisse.update({
            where: { id },
            data: updateCaisseDto,
            include: {
                centre: true,
            },
        });
    }
    async remove(id) {
        await this.findOne(id);
        const journeesCount = await this.prisma.journeeCaisse.count({
            where: { caisseId: id },
        });
        if (journeesCount > 0) {
            throw new common_1.ConflictException('Impossible de supprimer une caisse avec des journées enregistrées');
        }
        return this.prisma.caisse.delete({
            where: { id },
        });
    }
};
exports.CaisseService = CaisseService;
exports.CaisseService = CaisseService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CaisseService);
//# sourceMappingURL=caisse.service.js.map