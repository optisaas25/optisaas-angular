export declare class CompanySettingsModule {
}
