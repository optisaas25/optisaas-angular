import { CompanySettingsService } from './company-settings.service';
export declare class CompanySettingsController {
    private readonly service;
    constructor(service: CompanySettingsService);
    getSettings(): Promise<{
        id: string;
        updatedAt: Date;
        name: string;
        email: string | null;
        identifiantFiscal: string | null;
        ice: string | null;
        patente: string | null;
        rc: string | null;
        cnss: string | null;
        rib: string | null;
        logoUrl: string | null;
        cachetUrl: string | null;
        address: string | null;
        phone: string | null;
        website: string | null;
        inpeCode: string | null;
        bank: string | null;
    }>;
    updateSettings(data: any): Promise<{
        id: string;
        updatedAt: Date;
        name: string;
        email: string | null;
        identifiantFiscal: string | null;
        ice: string | null;
        patente: string | null;
        rc: string | null;
        cnss: string | null;
        rib: string | null;
        logoUrl: string | null;
        cachetUrl: string | null;
        address: string | null;
        phone: string | null;
        website: string | null;
        inpeCode: string | null;
        bank: string | null;
    }>;
}
