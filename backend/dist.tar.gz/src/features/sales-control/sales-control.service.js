"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesControlService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const factures_service_1 = require("../factures/factures.service");
let SalesControlService = class SalesControlService {
    prisma;
    facturesService;
    constructor(prisma, facturesService) {
        this.prisma = prisma;
        this.facturesService = facturesService;
    }
    async getBrouillonWithPayments(userId, centreId, startDate, endDate, take) {
        if (!centreId)
            return [];
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        return this.prisma.facture.findMany({
            where: {
                centreId,
                statut: { notIn: ['ARCHIVE', 'ANNULEE'] },
                type: { in: ['BON_COMMANDE', 'BON_COMM'] },
                ...(start || end ? { dateEmission: { gte: start, lte: end } } : {}),
            },
            include: {
                client: { select: { nom: true, prenom: true, raisonSociale: true } },
                paiements: true,
                fiche: true,
            },
            orderBy: [{ fiche: { numero: 'desc' } }, { dateEmission: 'desc' }],
        });
    }
    async getBrouillonWithoutPayments(userId, centreId, startDate, endDate, take) {
        if (!centreId)
            return [];
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        const results = await this.prisma.facture.findMany({
            where: {
                centreId,
                statut: { notIn: ['ARCHIVE', 'ANNULEE', 'VENTE_EN_INSTANCE'] },
                paiements: { none: {} },
                ...(start || end ? { dateEmission: { gte: start, lte: end } } : {}),
            },
            include: {
                client: { select: { nom: true, prenom: true, raisonSociale: true } },
                fiche: true,
            },
            orderBy: [{ fiche: { numero: 'desc' } }, { dateEmission: 'desc' }],
        });
        return results.filter((f) => {
            const isBC = f.type === 'BON_COMMANDE' ||
                f.type === 'BON_COMM' ||
                (f.numero || '').startsWith('BC');
            if (isBC)
                return false;
            const num = (f.numero || '').toUpperCase();
            return (f.type === 'DEVIS' ||
                num.startsWith('BRO') ||
                num.startsWith('DEV') ||
                num.startsWith('DEVIS'));
        });
    }
    async getValidInvoices(userId, centreId, startDate, endDate, take) {
        if (!centreId)
            return [];
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        return this.prisma.facture.findMany({
            where: {
                centreId,
                type: 'FACTURE',
                ...(start || end ? { dateEmission: { gte: start, lte: end } } : {}),
            },
            include: {
                client: { select: { nom: true, prenom: true, raisonSociale: true } },
                paiements: true,
                fiche: true,
                children: {
                    select: { id: true, numero: true, type: true, statut: true },
                },
            },
            orderBy: [{ dateEmission: 'desc' }],
        });
    }
    async getAvoirs(userId, centreId, startDate, endDate, take) {
        if (!centreId)
            return [];
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        return this.prisma.facture.findMany({
            where: {
                centreId,
                type: 'AVOIR',
                ...(start || end ? { dateEmission: { gte: start, lte: end } } : {}),
            },
            include: {
                client: { select: { nom: true, prenom: true, raisonSociale: true } },
                paiements: true,
                fiche: true,
                parentFacture: { select: { id: true, numero: true } },
            },
            orderBy: [{ dateEmission: 'desc' }],
        });
    }
    async getStatisticsByVendor(centreId, startDate, endDate) {
        if (!centreId)
            return [];
        const dashboard = await this.getDashboardData(undefined, centreId, startDate, endDate);
        return dashboard.stats;
    }
    async validateInvoice(id) {
        const currentDoc = await this.prisma.facture.findUnique({ where: { id } });
        if (!currentDoc)
            throw new Error(`Document ${id} not found`);
        if (currentDoc.type === 'BON_COMMANDE' || currentDoc.type === 'BON_COMM') {
            return this.facturesService.update({
                where: { id },
                data: {
                    type: 'FACTURE',
                    statut: 'VALIDE',
                    proprietes: { forceFiscal: true },
                },
            });
        }
        return this.facturesService.update({
            where: { id },
            data: {
                type: 'BON_COMM',
                statut: 'VENTE_EN_INSTANCE',
                proprietes: { forceStockDecrement: true },
            },
        });
    }
    async getDashboardData(userId, centreId, startDate, endDate) {
        if (!centreId) {
            return {
                withPayments: [],
                withoutPayments: [],
                valid: [],
                avoirs: [],
                stats: [],
                payments: [],
            };
        }
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        const dateFilter = start || end ? { dateEmission: { gte: start, lte: end } } : {};
        const paymentDateFilter = start || end ? { date: { gte: start, lte: end } } : {};
        const facturesWithFiche = await this.prisma.facture.findMany({
            where: {
                centreId,
                type: 'FACTURE',
                ficheId: { not: null },
                ...dateFilter,
            },
            select: { ficheId: true },
        });
        const factureFicheIds = facturesWithFiche
            .map((f) => f.ficheId)
            .filter((id) => !!id);
        const [factureAgg, bcAgg, avoirAgg, devisCount, withPayments, withoutPayments, valid, avoirs, paymentAgg,] = await Promise.all([
            this.prisma.facture.aggregate({
                _sum: { totalTTC: true, resteAPayer: true },
                _count: { _all: true },
                where: {
                    centreId,
                    type: 'FACTURE',
                    ...dateFilter,
                },
            }),
            this.prisma.facture.aggregate({
                _sum: { totalTTC: true, resteAPayer: true },
                _count: { _all: true },
                where: {
                    centreId,
                    type: { in: ['BON_COMMANDE', 'BON_COMM'] },
                    statut: { notIn: ['ARCHIVE', 'ANNULEE'] },
                    ficheId: { notIn: factureFicheIds },
                    ...dateFilter,
                },
            }),
            this.prisma.facture.aggregate({
                _sum: { totalTTC: true, resteAPayer: true },
                _count: { _all: true },
                where: {
                    centreId,
                    type: 'AVOIR',
                    statut: { notIn: ['ARCHIVE', 'ANNULEE'] },
                    ...dateFilter,
                },
            }),
            this.prisma.facture.count({
                where: {
                    centreId,
                    statut: { notIn: ['ARCHIVE', 'ANNULEE', 'VENTE_EN_INSTANCE'] },
                    paiements: { none: {} },
                    type: { notIn: ['BON_COMMANDE', 'BON_COMM', 'FACTURE', 'AVOIR'] },
                    numero: { not: { startsWith: 'BC' } },
                    ...dateFilter,
                },
            }),
            this.getBrouillonWithPayments(userId, centreId, startDate, endDate),
            this.getBrouillonWithoutPayments(userId, centreId, startDate, endDate),
            this.getValidInvoices(userId, centreId, startDate, endDate),
            this.getAvoirs(userId, centreId, startDate, endDate),
            this.prisma.paiement.groupBy({
                by: ['mode'],
                _sum: { montant: true },
                where: {
                    date: paymentDateFilter.date,
                    facture: { centreId },
                    statut: { not: 'ANNULE' },
                },
            }),
        ]);
        const totalFactures = factureAgg._sum.totalTTC || 0;
        const totalAvoirs = avoirAgg._sum.totalTTC || 0;
        const totalBC = bcAgg._sum.totalTTC || 0;
        const totalAmount = totalFactures + totalBC - totalAvoirs;
        const totalFacturesReste = factureAgg._sum.resteAPayer || 0;
        const totalBMReste = bcAgg._sum.resteAPayer || 0;
        const totalAvoirsReste = avoirAgg._sum.resteAPayer || 0;
        const totalReste = totalFacturesReste + totalBMReste - totalAvoirsReste;
        const payments = paymentAgg.map((p) => ({
            methode: p.mode || 'AUTRE',
            total: p._sum.montant || 0,
        }));
        const totalEncaissePeriod = payments.reduce((sum, p) => sum + p.total, 0);
        const stats = [
            {
                vendorId: 'all',
                vendorName: 'Tous les vendeurs',
                countValid: factureAgg._count._all,
                countWithPayment: bcAgg._count._all,
                countWithoutPayment: devisCount,
                countAvoir: avoirAgg._count._all,
                totalAmount,
                totalFactures,
                totalAvoirs,
                totalBC,
                totalEncaissePeriod,
                totalReste,
                payments,
            },
        ];
        return { withPayments, withoutPayments, valid, avoirs, stats, payments };
    }
    async declareAsGift(id) {
        const facture = await this.prisma.facture.findUnique({ where: { id } });
        if (!facture)
            throw new Error('Facture not found');
        return this.prisma.facture.update({
            where: { id },
            data: {
                totalHT: 0,
                totalTVA: 0,
                totalTTC: 0,
                resteAPayer: 0,
                statut: 'VALIDE',
                proprietes: {
                    ...facture.proprietes,
                    typeVente: 'DON',
                    raison: 'Déclaré comme don/offert',
                },
            },
        });
    }
    async archiveInvoice(id) {
        return this.prisma.facture.update({
            where: { id },
            data: { statut: 'ARCHIVE' },
        });
    }
};
exports.SalesControlService = SalesControlService;
exports.SalesControlService = SalesControlService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        factures_service_1.FacturesService])
], SalesControlService);
//# sourceMappingURL=sales-control.service.js.map