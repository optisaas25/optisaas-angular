"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesControlController = void 0;
const common_1 = require("@nestjs/common");
const sales_control_service_1 = require("./sales-control.service");
let SalesControlController = class SalesControlController {
    salesControlService;
    constructor(salesControlService) {
        this.salesControlService = salesControlService;
    }
    async getBrouillonWithPayments(userId, centreId, startDate, endDate) {
        return this.salesControlService.getBrouillonWithPayments(userId, centreId, startDate, endDate);
    }
    async getBrouillonWithoutPayments(userId, centreId, startDate, endDate) {
        return this.salesControlService.getBrouillonWithoutPayments(userId, centreId, startDate, endDate);
    }
    async getValidInvoices(userId, centreId, startDate, endDate) {
        return this.salesControlService.getValidInvoices(userId, centreId, startDate, endDate);
    }
    async getAvoirs(userId, centreId, startDate, endDate) {
        return this.salesControlService.getAvoirs(userId, centreId, startDate, endDate);
    }
    async getStatistics(centreId, startDate, endDate) {
        return this.salesControlService.getStatisticsByVendor(centreId, startDate, endDate);
    }
    async getDashboardData(userId, centreId, startDate, endDate) {
        return this.salesControlService.getDashboardData(userId, centreId, startDate, endDate);
    }
    async validateInvoice(id) {
        return this.salesControlService.validateInvoice(id);
    }
    async declareAsGift(id) {
        return this.salesControlService.declareAsGift(id);
    }
};
exports.SalesControlController = SalesControlController;
__decorate([
    (0, common_1.Get)('brouillon-with-payments'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getBrouillonWithPayments", null);
__decorate([
    (0, common_1.Get)('brouillon-without-payments'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getBrouillonWithoutPayments", null);
__decorate([
    (0, common_1.Get)('valid-invoices'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getValidInvoices", null);
__decorate([
    (0, common_1.Get)('avoirs'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getAvoirs", null);
__decorate([
    (0, common_1.Get)('statistics'),
    __param(0, (0, common_1.Headers)('Tenant')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Get)('dashboard-data'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "getDashboardData", null);
__decorate([
    (0, common_1.Post)('validate/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "validateInvoice", null);
__decorate([
    (0, common_1.Post)('declare-gift/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SalesControlController.prototype, "declareAsGift", null);
exports.SalesControlController = SalesControlController = __decorate([
    (0, common_1.Controller)('sales-control'),
    __metadata("design:paramtypes", [sales_control_service_1.SalesControlService])
], SalesControlController);
//# sourceMappingURL=sales-control.controller.js.map