export declare class SalesControlModule {
}
