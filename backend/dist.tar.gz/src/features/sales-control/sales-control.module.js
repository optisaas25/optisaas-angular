"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesControlModule = void 0;
const common_1 = require("@nestjs/common");
const sales_control_service_1 = require("./sales-control.service");
const sales_control_controller_1 = require("./sales-control.controller");
const prisma_module_1 = require("../../prisma/prisma.module");
const factures_module_1 = require("../factures/factures.module");
let SalesControlModule = class SalesControlModule {
};
exports.SalesControlModule = SalesControlModule;
exports.SalesControlModule = SalesControlModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, factures_module_1.FacturesModule],
        controllers: [sales_control_controller_1.SalesControlController],
        providers: [sales_control_service_1.SalesControlService],
        exports: [sales_control_service_1.SalesControlService],
    })
], SalesControlModule);
//# sourceMappingURL=sales-control.module.js.map