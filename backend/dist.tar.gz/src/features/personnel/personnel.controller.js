"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonnelController = void 0;
const common_1 = require("@nestjs/common");
const jwt = __importStar(require("jsonwebtoken"));
const config_1 = require("@nestjs/config");
const personnel_service_1 = require("./personnel.service");
const create_employee_dto_1 = require("./dto/create-employee.dto");
const update_employee_dto_1 = require("./dto/update-employee.dto");
const attendance_service_1 = require("./attendance.service");
const create_attendance_dto_1 = require("./dto/create-attendance.dto");
const commission_service_1 = require("./commission.service");
const create_commission_rule_dto_1 = require("./dto/create-commission-rule.dto");
const update_commission_rule_dto_1 = require("./dto/update-commission-rule.dto");
const payroll_service_1 = require("./payroll.service");
const generate_payroll_dto_1 = require("./dto/generate-payroll.dto");
const update_payroll_dto_1 = require("./dto/update-payroll.dto");
let PersonnelController = class PersonnelController {
    personnelService;
    attendanceService;
    commissionService;
    payrollService;
    configService;
    constructor(personnelService, attendanceService, commissionService, payrollService, configService) {
        this.personnelService = personnelService;
        this.attendanceService = attendanceService;
        this.commissionService = commissionService;
        this.payrollService = payrollService;
        this.configService = configService;
    }
    createEmployee(createEmployeeDto) {
        return this.personnelService.create(createEmployeeDto);
    }
    findAllEmployees(centreId) {
        return this.personnelService.findAll(centreId);
    }
    findOneEmployee(id) {
        return this.personnelService.findOne(id);
    }
    updateEmployee(id, updateEmployeeDto) {
        console.log('PATCH /personnel/employees/' + id, updateEmployeeDto);
        return this.personnelService.update(id, updateEmployeeDto);
    }
    removeEmployee(id) {
        return this.personnelService.remove(id);
    }
    logAttendance(createAttendanceDto) {
        return this.attendanceService.log(createAttendanceDto);
    }
    getMonthlyAttendance(employeeId, month, year) {
        return this.attendanceService.getEmployeeMonthly(employeeId, month, parseInt(year));
    }
    createCommissionRule(dto) {
        return this.commissionService.createRule(dto);
    }
    getCommissionRules(centreId) {
        return this.commissionService.getRules(centreId);
    }
    updateCommissionRule(id, dto) {
        return this.commissionService.updateRule(id, dto);
    }
    deleteCommissionRule(id) {
        return this.commissionService.deleteRule(id);
    }
    getEmployeeCommissions(employeeId, mois, annee) {
        return this.commissionService.getEmployeeCommissions(employeeId, mois, annee ? parseInt(annee) : undefined);
    }
    generatePayroll(dto) {
        return this.payrollService.generate(dto);
    }
    validatePayroll(id) {
        return this.payrollService.validate(id);
    }
    payPayroll(id, body, authHeader) {
        const userId = this.getUserId(authHeader) || body.userId;
        return this.payrollService.markAsPaid(id, body.centreId, userId, body.modePaiement, body.banque, body.reference, body.dateEcheance);
    }
    getUserId(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer '))
            return undefined;
        try {
            const token = authHeader.split(' ')[1];
            const secret = this.configService.get('JWT_SECRET') || 'your-very-secret-key';
            const payload = jwt.verify(token, secret);
            return payload.sub;
        }
        catch (e) {
            return undefined;
        }
    }
    findAllPayroll(mois, annee, centreId) {
        return this.payrollService.findAll(mois, annee ? parseInt(annee) : undefined, centreId);
    }
    updatePayroll(id, dto) {
        return this.payrollService.update(id, dto);
    }
    deletePayroll(id) {
        return this.payrollService.remove(id);
    }
    async getPayrollPdf(id) {
        const relativeUrl = await this.payrollService.getGeneratedPdf(id);
        return { url: relativeUrl };
    }
    recordAdvance(id, body) {
        return this.payrollService.recordAdvance(id, body.amount, body.mode, body.centreId, body.userId);
    }
    getEmployeeAdvances(id) {
        return this.payrollService.getEmployeeAdvances(id);
    }
    getDashboardStats(mois, annee, centreId) {
        return this.payrollService.getDashboardStats(mois, annee ? parseInt(annee) : undefined, centreId);
    }
};
exports.PersonnelController = PersonnelController;
__decorate([
    (0, common_1.Post)('employees'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_employee_dto_1.CreateEmployeeDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "createEmployee", null);
__decorate([
    (0, common_1.Get)('employees'),
    __param(0, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "findAllEmployees", null);
__decorate([
    (0, common_1.Get)('employees/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "findOneEmployee", null);
__decorate([
    (0, common_1.Patch)('employees/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_employee_dto_1.UpdateEmployeeDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "updateEmployee", null);
__decorate([
    (0, common_1.Delete)('employees/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "removeEmployee", null);
__decorate([
    (0, common_1.Post)('attendance'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_attendance_dto_1.CreateAttendanceDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "logAttendance", null);
__decorate([
    (0, common_1.Get)('attendance/:employeeId'),
    __param(0, (0, common_1.Param)('employeeId')),
    __param(1, (0, common_1.Query)('month')),
    __param(2, (0, common_1.Query)('year')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "getMonthlyAttendance", null);
__decorate([
    (0, common_1.Post)('commission-rules'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_commission_rule_dto_1.CreateCommissionRuleDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "createCommissionRule", null);
__decorate([
    (0, common_1.Get)('commission-rules'),
    __param(0, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "getCommissionRules", null);
__decorate([
    (0, common_1.Patch)('commission-rules/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_commission_rule_dto_1.UpdateCommissionRuleDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "updateCommissionRule", null);
__decorate([
    (0, common_1.Delete)('commission-rules/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "deleteCommissionRule", null);
__decorate([
    (0, common_1.Get)('commissions/:employeeId'),
    __param(0, (0, common_1.Param)('employeeId')),
    __param(1, (0, common_1.Query)('mois')),
    __param(2, (0, common_1.Query)('annee')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "getEmployeeCommissions", null);
__decorate([
    (0, common_1.Post)('payroll/generate'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_payroll_dto_1.GeneratePayrollDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "generatePayroll", null);
__decorate([
    (0, common_1.Post)('payroll/:id/validate'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "validatePayroll", null);
__decorate([
    (0, common_1.Post)('payroll/:id/pay'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "payPayroll", null);
__decorate([
    (0, common_1.Get)('payroll'),
    __param(0, (0, common_1.Query)('mois')),
    __param(1, (0, common_1.Query)('annee')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "findAllPayroll", null);
__decorate([
    (0, common_1.Patch)('payroll/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_payroll_dto_1.UpdatePayrollDto]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "updatePayroll", null);
__decorate([
    (0, common_1.Delete)('payroll/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "deletePayroll", null);
__decorate([
    (0, common_1.Get)('payroll/:id/pdf'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PersonnelController.prototype, "getPayrollPdf", null);
__decorate([
    (0, common_1.Post)('employees/:id/advance'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "recordAdvance", null);
__decorate([
    (0, common_1.Get)('employees/:id/advances'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "getEmployeeAdvances", null);
__decorate([
    (0, common_1.Get)('dashboard/stats'),
    __param(0, (0, common_1.Query)('mois')),
    __param(1, (0, common_1.Query)('annee')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], PersonnelController.prototype, "getDashboardStats", null);
exports.PersonnelController = PersonnelController = __decorate([
    (0, common_1.Controller)('personnel'),
    __metadata("design:paramtypes", [personnel_service_1.PersonnelService,
        attendance_service_1.AttendanceService,
        commission_service_1.CommissionService,
        payroll_service_1.PayrollService,
        config_1.ConfigService])
], PersonnelController);
//# sourceMappingURL=personnel.controller.js.map