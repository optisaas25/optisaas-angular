import { PrismaService } from '../../prisma/prisma.service';
import { CreateCommissionRuleDto } from './dto/create-commission-rule.dto';
import { UpdateCommissionRuleDto } from './dto/update-commission-rule.dto';
export declare class CommissionService {
    private prisma;
    constructor(prisma: PrismaService);
    createRule(dto: CreateCommissionRuleDto): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    getRules(centreId?: string): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }[]>;
    updateRule(id: string, dto: UpdateCommissionRuleDto): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    deleteRule(id: string): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    calculateForInvoice(factureId: string, tx?: any): Promise<any[] | null>;
    getEmployeeCommissions(employeeId: string, mois: string, annee?: number): Promise<({
        facture: {
            numero: string;
            dateEmission: Date;
            totalTTC: number;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        montant: number;
        factureId: string;
        employeeId: string;
        mois: string;
    })[]>;
    getTotalCommissions(employeeId: string, mois: string, annee?: number): Promise<number>;
    recalculateForPeriod(mois: string): Promise<{
        invoicesProcessed: number;
        commissionsCreated: number;
    }>;
}
