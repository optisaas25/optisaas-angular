export declare class PersonnelModule {
}
