"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommissionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let CommissionService = class CommissionService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async createRule(dto) {
        return this.prisma.commissionRule.create({ data: dto });
    }
    async getRules(centreId) {
        return this.prisma.commissionRule.findMany({
            where: centreId ? { centreId } : {},
        });
    }
    async updateRule(id, dto) {
        return this.prisma.commissionRule.update({
            where: { id },
            data: dto,
        });
    }
    async deleteRule(id) {
        return this.prisma.commissionRule.delete({
            where: { id },
        });
    }
    async calculateForInvoice(factureId, tx) {
        const prisma = tx || this.prisma;
        const facture = await prisma.facture.findUnique({
            where: { id: factureId },
            include: { vendeur: true },
        });
        if (!facture || !facture.vendeurId || !facture.vendeur)
            return null;
        const employee = facture.vendeur;
        const mois = facture.dateEmission.toISOString().substring(0, 7);
        await prisma.commission.deleteMany({
            where: { factureId: facture.id },
        });
        const rules = await prisma.commissionRule.findMany({
            where: {
                poste: employee.poste,
                OR: [{ centreId: facture.centreId }, { centreId: null }],
            },
        });
        const lines = typeof facture.lignes === 'string'
            ? JSON.parse(facture.lignes)
            : facture.lignes;
        if (!Array.isArray(lines))
            return null;
        const results = [];
        for (const line of lines) {
            let typeArticle = null;
            if (line.productId) {
                const product = await prisma.product.findUnique({
                    where: { id: line.productId },
                });
                if (product) {
                    typeArticle = product.typeArticle;
                }
            }
            if (!typeArticle && line.description) {
                const desc = line.description.toUpperCase();
                if (desc.includes('MONTURE'))
                    typeArticle = 'MONTURE';
                else if (desc.includes('VERRE'))
                    typeArticle = 'VERRE';
                else if (desc.includes('LENTILLE'))
                    typeArticle = 'LENTILLE';
                else if (desc.includes('ACCESSOIRE'))
                    typeArticle = 'ACCESSOIRE';
            }
            const rule = rules.find((r) => {
                if (!typeArticle)
                    return false;
                const rType = r.typeProduit.toUpperCase();
                const pType = typeArticle.toUpperCase();
                return rType === pType || pType.startsWith(rType + '_');
            }) || rules.find((r) => r.typeProduit === 'GLOBAL');
            if (rule) {
                const montantCom = (line.totalTTC || 0) * (rule.taux / 100);
                if (montantCom > 0) {
                    await prisma.commission.create({
                        data: {
                            employeeId: employee.id,
                            factureId: facture.id,
                            type: typeArticle || 'INCONNU',
                            montant: montantCom,
                            mois: mois,
                        },
                    });
                    results.push({ type: typeArticle, montant: montantCom });
                }
            }
        }
        return results;
    }
    async getEmployeeCommissions(employeeId, mois, annee) {
        const fullMois = annee ? `${annee}-${mois}` : mois;
        return this.prisma.commission.findMany({
            where: { employeeId, mois: fullMois },
            include: {
                facture: {
                    select: {
                        numero: true,
                        totalTTC: true,
                        dateEmission: true,
                    },
                },
            },
        });
    }
    async getTotalCommissions(employeeId, mois, annee) {
        const fullMois = annee ? `${annee}-${mois}` : mois;
        const aggregations = await this.prisma.commission.aggregate({
            where: { employeeId, mois: fullMois },
            _sum: { montant: true },
        });
        return aggregations._sum.montant || 0;
    }
    async recalculateForPeriod(mois) {
        const factures = await this.prisma.facture.findMany({
            where: {
                statut: { in: ['VALIDE', 'PAYEE', 'PARTIEL'] },
                dateEmission: {
                    gte: new Date(`${mois}-01`),
                    lt: new Date(new Date(`${mois}-01`).setMonth(new Date(`${mois}-01`).getMonth() + 1)),
                },
            },
        });
        console.log(`🔄 [CommissionService] Recalculating for ${factures.length} invoices in ${mois}`);
        let totalCreated = 0;
        for (const facture of factures) {
            await this.prisma.commission.deleteMany({
                where: { factureId: facture.id },
            });
            const results = await this.calculateForInvoice(facture.id);
            if (results && results.length > 0) {
                totalCreated += results.length;
            }
        }
        return {
            invoicesProcessed: factures.length,
            commissionsCreated: totalCreated,
        };
    }
};
exports.CommissionService = CommissionService;
exports.CommissionService = CommissionService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CommissionService);
//# sourceMappingURL=commission.service.js.map