"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonnelModule = void 0;
const common_1 = require("@nestjs/common");
const personnel_controller_1 = require("./personnel.controller");
const payroll_config_controller_1 = require("./payroll-config.controller");
const personnel_service_1 = require("./personnel.service");
const attendance_service_1 = require("./attendance.service");
const commission_service_1 = require("./commission.service");
const payroll_service_1 = require("./payroll.service");
const payslip_service_1 = require("./payslip.service");
const expenses_module_1 = require("../expenses/expenses.module");
const prisma_module_1 = require("../../prisma/prisma.module");
let PersonnelModule = class PersonnelModule {
};
exports.PersonnelModule = PersonnelModule;
exports.PersonnelModule = PersonnelModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, expenses_module_1.ExpensesModule],
        controllers: [personnel_controller_1.PersonnelController, payroll_config_controller_1.PayrollConfigController],
        providers: [
            personnel_service_1.PersonnelService,
            attendance_service_1.AttendanceService,
            commission_service_1.CommissionService,
            payroll_service_1.PayrollService,
            payslip_service_1.PayslipService,
        ],
        exports: [personnel_service_1.PersonnelService, commission_service_1.CommissionService],
    })
], PersonnelModule);
//# sourceMappingURL=personnel.module.js.map