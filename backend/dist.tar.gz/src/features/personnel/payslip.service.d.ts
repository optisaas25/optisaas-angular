export declare class PayslipService {
    private readonly uploadDir;
    constructor();
    generate(employee: any, payroll: any, commissions: any[], config?: any): Promise<unknown>;
}
