"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayrollConfigController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let PayrollConfigController = class PayrollConfigController {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    findAll() {
        return this.prisma.payrollConfig.findMany({
            orderBy: { annee: 'desc' },
        });
    }
    findOne(annee) {
        return this.prisma.payrollConfig.findUnique({
            where: { annee: parseInt(annee) },
        });
    }
    async create(data) {
        console.log('POST /personnel/payroll-config', data);
        const { id, createdAt, updatedAt, ...createData } = data;
        try {
            return await this.prisma.payrollConfig.create({
                data: {
                    ...createData,
                    annee: parseInt(data.annee),
                },
            });
        }
        catch (error) {
            console.error('❌ Error creating payroll config:', error);
            throw error;
        }
    }
    async update(id, data) {
        console.log('PUT /personnel/payroll-config/' + id, data);
        const { id: _, createdAt: __, updatedAt: ___, ...updateData } = data;
        try {
            return await this.prisma.payrollConfig.update({
                where: { id },
                data: {
                    ...updateData,
                    annee: parseInt(data.annee),
                },
            });
        }
        catch (error) {
            console.error('Error updating payroll config:', error);
            throw error;
        }
    }
};
exports.PayrollConfigController = PayrollConfigController;
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PayrollConfigController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':annee'),
    __param(0, (0, common_1.Param)('annee')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PayrollConfigController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PayrollConfigController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PayrollConfigController.prototype, "update", null);
exports.PayrollConfigController = PayrollConfigController = __decorate([
    (0, common_1.Controller)('personnel/payroll-config'),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PayrollConfigController);
//# sourceMappingURL=payroll-config.controller.js.map