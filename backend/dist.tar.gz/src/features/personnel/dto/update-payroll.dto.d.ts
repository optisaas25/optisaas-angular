export declare class UpdatePayrollDto {
    salaireBase?: number;
    commissions?: number;
    heuresSup?: number;
    primes?: number;
    retenues?: number;
    avances?: number;
    grossSalary?: number;
    socialSecurityDeduction?: number;
    healthInsuranceDeduction?: number;
    incomeTaxDeduction?: number;
    professionalExpenses?: number;
    employerCharges?: number;
    netAPayer?: number;
    statut?: string;
}
