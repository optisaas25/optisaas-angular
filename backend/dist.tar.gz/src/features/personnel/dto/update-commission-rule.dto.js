"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateCommissionRuleDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_commission_rule_dto_1 = require("./create-commission-rule.dto");
class UpdateCommissionRuleDto extends (0, mapped_types_1.PartialType)(create_commission_rule_dto_1.CreateCommissionRuleDto) {
}
exports.UpdateCommissionRuleDto = UpdateCommissionRuleDto;
//# sourceMappingURL=update-commission-rule.dto.js.map