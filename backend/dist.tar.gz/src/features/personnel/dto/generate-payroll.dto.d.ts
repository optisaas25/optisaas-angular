export declare class GeneratePayrollDto {
    employeeId: string;
    mois: string;
    annee: number;
}
