export declare class CreateCommissionRuleDto {
    poste: string;
    centreId?: string;
    typeProduit: string;
    taux: number;
}
