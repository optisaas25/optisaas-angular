export declare class CreateAttendanceDto {
    employeeId: string;
    date: string;
    heuresTravaillees: number;
    retardMinutes: number;
    estAbsent: boolean;
    motif?: string;
}
