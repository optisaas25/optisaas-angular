import { CreateCommissionRuleDto } from './create-commission-rule.dto';
declare const UpdateCommissionRuleDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateCommissionRuleDto>>;
export declare class UpdateCommissionRuleDto extends UpdateCommissionRuleDto_base {
}
export {};
