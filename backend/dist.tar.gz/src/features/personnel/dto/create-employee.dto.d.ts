export declare class CreateEmployeeDto {
    matricule?: string;
    nom: string;
    prenom: string;
    cin?: string;
    telephone?: string;
    email?: string;
    adresse?: string;
    photoUrl?: string;
    poste: string;
    contrat: string;
    dateEmbauche?: string;
    salaireBase: number;
    statut?: string;
    centreIds: string[];
    userId?: string;
    childrenCount?: number;
    familyStatus?: string;
    paymentMode?: string;
    socialSecurityAffiliation?: boolean;
}
