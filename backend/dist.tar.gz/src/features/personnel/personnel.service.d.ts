import { PrismaService } from '../../prisma/prisma.service';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';
export declare class PersonnelService {
    private prisma;
    constructor(prisma: PrismaService);
    create(createEmployeeDto: CreateEmployeeDto): Promise<{
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    findAll(centreId?: string): Promise<({
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    })[]>;
    findOne(id: string): Promise<{
        user: {
            email: string;
            centreRoles: {
                id: string;
                centreId: string;
                userId: string;
                centreName: string;
                role: string;
                entrepotIds: string[];
                entrepotNames: string[];
            }[];
        } | null;
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    update(id: string, updateEmployeeDto: UpdateEmployeeDto): Promise<{
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    remove(id: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
}
