"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayslipService = void 0;
const common_1 = require("@nestjs/common");
const pdfkit_1 = __importDefault(require("pdfkit"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let PayslipService = class PayslipService {
    uploadDir = path.join(process.cwd(), 'uploads', 'payslips');
    constructor() {
        if (!fs.existsSync(this.uploadDir)) {
            fs.mkdirSync(this.uploadDir, { recursive: true });
        }
    }
    async generate(employee, payroll, commissions, config) {
        const doc = new pdfkit_1.default({ margin: 50, size: 'A4' });
        const fileName = `payslip-${employee.id}-${payroll.mois}-${payroll.annee}.pdf`;
        const filePath = path.join(this.uploadDir, fileName);
        const stream = fs.createWriteStream(filePath);
        doc.pipe(stream);
        doc
            .fontSize(22)
            .font('Helvetica-Bold')
            .text('BULLETIN DE PAIE', { align: 'center' });
        doc.moveDown(0.5);
        doc
            .fontSize(10)
            .font('Helvetica')
            .text(`Période : ${payroll.mois}/${payroll.annee}`, { align: 'right' });
        doc.moveDown();
        const infoY = doc.y;
        doc
            .fontSize(10)
            .font('Helvetica-Bold')
            .text('INFORMATIONS EMPLOYÉ', 50, infoY);
        doc.font('Helvetica');
        doc.text(`Nom : ${employee.nom.toUpperCase()} ${employee.prenom}`, 50, infoY + 15);
        doc.text(`Matricule : ${employee.matricule || 'N/A'}`, 50, infoY + 30);
        doc.text(`Poste : ${employee.poste}`, 50, infoY + 45);
        doc.text(`CIN : ${employee.cin || 'N/A'}`, 50, infoY + 60);
        doc.text(`Date Embauche : ${new Date(employee.dateEmbauche).toLocaleDateString()}`, 300, infoY + 15);
        doc.text(`Type contrat : ${employee.contrat}`, 300, infoY + 30);
        doc.text(`Mode Paiement : ${employee.paymentMode || 'VIREMENT'}`, 300, infoY + 45);
        doc.moveDown(3);
        const gridY = doc.y;
        doc.rect(50, gridY - 5, 500, 20).fill('#f3f4f6');
        doc.fillColor('#000').font('Helvetica-Bold').fontSize(10);
        doc.text('DÉSIGNATION', 60, gridY);
        doc.text('GAINS', 350, gridY, { width: 80, align: 'right' });
        doc.text('RETENUES', 460, gridY, { width: 80, align: 'right' });
        doc.moveDown(1.5);
        doc.font('Helvetica').fontSize(10);
        let currentY = doc.y;
        doc.text('Salaire de Base', 60, currentY);
        doc.text(`${payroll.salaireBase.toFixed(2)}`, 350, currentY, {
            width: 80,
            align: 'right',
        });
        doc.moveDown();
        if (payroll.primes > 0) {
            currentY = doc.y;
            doc.text('Primes & Indemnités', 60, currentY);
            doc.text(`${payroll.primes.toFixed(2)}`, 350, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        if (payroll.commissions > 0) {
            currentY = doc.y;
            doc.text('Commissions sur Ventes (Total)', 60, currentY);
            doc.text(`${payroll.commissions.toFixed(2)}`, 350, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        if (payroll.heuresSup > 0) {
            currentY = doc.y;
            doc.text('Heures Supplémentaires', 60, currentY);
            doc.text(`${payroll.heuresSup.toFixed(2)}`, 350, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        doc.moveDown(0.5);
        doc.font('Helvetica-Bold');
        currentY = doc.y;
        doc.rect(50, currentY - 5, 500, 20).fill('#f9fafb');
        doc.fillColor('#000').text('SALAIRE BRUT GLOBAL', 60, currentY);
        doc.text(`${payroll.grossSalary.toFixed(2)}`, 350, currentY, {
            width: 80,
            align: 'right',
        });
        doc.font('Helvetica').moveDown(1.5);
        if (payroll.socialSecurityDeduction > 0) {
            currentY = doc.y;
            const rate = config ? ` (${config.socialSecurityRate_S}%)` : '';
            doc.text(`CNSS (Sécurité Sociale)${rate}`, 60, currentY);
            doc.text(`${payroll.socialSecurityDeduction.toFixed(2)}`, 460, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        if (payroll.healthInsuranceDeduction > 0) {
            currentY = doc.y;
            const rate = config ? ` (${config.healthInsuranceRate_S}%)` : '';
            doc.text(`AMO (Assurance Maladie)${rate}`, 60, currentY);
            doc.text(`${payroll.healthInsuranceDeduction.toFixed(2)}`, 460, currentY, { width: 80, align: 'right' });
            doc.moveDown();
        }
        if (payroll.incomeTaxDeduction > 0) {
            currentY = doc.y;
            doc.text('IR (Impôt sur le Revenu)', 60, currentY);
            doc.text(`${payroll.incomeTaxDeduction.toFixed(2)}`, 460, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        if (payroll.avances > 0) {
            currentY = doc.y;
            doc.text('Avances sur salaire (Acomptes)', 60, currentY);
            doc.text(`${payroll.avances.toFixed(2)}`, 460, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        if (payroll.retenues > 0) {
            currentY = doc.y;
            doc.text('Autres retenues (Absences, etc.)', 60, currentY);
            doc.text(`${payroll.retenues.toFixed(2)}`, 460, currentY, {
                width: 80,
                align: 'right',
            });
            doc.moveDown();
        }
        doc.moveDown();
        doc.fontSize(8).fillColor('#666');
        doc.text(`Base de calcul Net Imposable : ${(payroll.taxableNet || 0).toFixed(2)} MAD`, 50, doc.y);
        doc.fillColor('#000').fontSize(10);
        doc.moveDown(2);
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        doc.fontSize(16).font('Helvetica-Bold').text('NET À PAYER', 50, doc.y);
        const formattedNet = (payroll.netAPayer || 0)
            .toFixed(2)
            .replace('.', ',')
            .replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
        doc.text(`${formattedNet} MAD`, 350, doc.y, { width: 200, align: 'right' });
        doc
            .fontSize(9)
            .font('Helvetica')
            .text('Fait à ...................., le ' +
            new Date().toLocaleDateString('fr-FR'), 50, 720);
        doc.text("Signature de l'employeur", 400, 720);
        doc.text("Signature de l'employé (précedée de lu et approuvé)", 50, 750);
        doc.end();
        return new Promise((resolve, reject) => {
            stream.on('finish', () => resolve(`/uploads/payslips/${fileName}`));
            stream.on('error', reject);
        });
    }
};
exports.PayslipService = PayslipService;
exports.PayslipService = PayslipService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], PayslipService);
//# sourceMappingURL=payslip.service.js.map