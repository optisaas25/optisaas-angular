import { PrismaService } from '../../prisma/prisma.service';
import { CreateAttendanceDto } from './dto/create-attendance.dto';
export declare class AttendanceService {
    private prisma;
    constructor(prisma: PrismaService);
    log(createAttendanceDto: CreateAttendanceDto): Promise<{
        id: string;
        createdAt: Date;
        date: Date;
        motif: string | null;
        employeeId: string;
        heuresTravaillees: number;
        retardMinutes: number;
        estAbsent: boolean;
    }>;
    getEmployeeMonthly(employeeId: string, month: string, year: number): Promise<{
        id: string;
        createdAt: Date;
        date: Date;
        motif: string | null;
        employeeId: string;
        heuresTravaillees: number;
        retardMinutes: number;
        estAbsent: boolean;
    }[]>;
    getStats(employeeId: string, month: string, year: number): Promise<{
        totalHours: number;
        totalLateMinutes: number;
        absencesCount: number;
        attendancesCount: number;
    }>;
}
