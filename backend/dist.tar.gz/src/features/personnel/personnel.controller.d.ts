import { ConfigService } from '@nestjs/config';
import { PersonnelService } from './personnel.service';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';
import { AttendanceService } from './attendance.service';
import { CreateAttendanceDto } from './dto/create-attendance.dto';
import { CommissionService } from './commission.service';
import { CreateCommissionRuleDto } from './dto/create-commission-rule.dto';
import { UpdateCommissionRuleDto } from './dto/update-commission-rule.dto';
import { PayrollService } from './payroll.service';
import { GeneratePayrollDto } from './dto/generate-payroll.dto';
import { UpdatePayrollDto } from './dto/update-payroll.dto';
export declare class PersonnelController {
    private readonly personnelService;
    private readonly attendanceService;
    private readonly commissionService;
    private readonly payrollService;
    private readonly configService;
    constructor(personnelService: PersonnelService, attendanceService: AttendanceService, commissionService: CommissionService, payrollService: PayrollService, configService: ConfigService);
    createEmployee(createEmployeeDto: CreateEmployeeDto): Promise<{
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    findAllEmployees(centreId?: string): Promise<({
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    })[]>;
    findOneEmployee(id: string): Promise<{
        user: {
            email: string;
            centreRoles: {
                id: string;
                centreId: string;
                userId: string;
                centreName: string;
                role: string;
                entrepotIds: string[];
                entrepotNames: string[];
            }[];
        } | null;
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    updateEmployee(id: string, updateEmployeeDto: UpdateEmployeeDto): Promise<{
        centres: ({
            centre: {
                nom: string;
            };
        } & {
            centreId: string;
            employeeId: string;
        })[];
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    removeEmployee(id: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string | null;
        nom: string;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
        prenom: string;
        photoUrl: string | null;
        matricule: string | null;
        cin: string | null;
        poste: string;
        contrat: string;
        dateEmbauche: Date;
        salaireBase: number;
        childrenCount: number;
        paymentMode: string;
        socialSecurityAffiliation: boolean;
        familyStatus: string;
    }>;
    logAttendance(createAttendanceDto: CreateAttendanceDto): Promise<{
        id: string;
        createdAt: Date;
        date: Date;
        motif: string | null;
        employeeId: string;
        heuresTravaillees: number;
        retardMinutes: number;
        estAbsent: boolean;
    }>;
    getMonthlyAttendance(employeeId: string, month: string, year: string): Promise<{
        id: string;
        createdAt: Date;
        date: Date;
        motif: string | null;
        employeeId: string;
        heuresTravaillees: number;
        retardMinutes: number;
        estAbsent: boolean;
    }[]>;
    createCommissionRule(dto: CreateCommissionRuleDto): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    getCommissionRules(centreId?: string): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }[]>;
    updateCommissionRule(id: string, dto: UpdateCommissionRuleDto): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    deleteCommissionRule(id: string): Promise<{
        id: string;
        centreId: string | null;
        poste: string;
        typeProduit: string;
        taux: number;
    }>;
    getEmployeeCommissions(employeeId: string, mois: string, annee?: string): Promise<({
        facture: {
            numero: string;
            dateEmission: Date;
            totalTTC: number;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        montant: number;
        factureId: string;
        employeeId: string;
        mois: string;
    })[]>;
    generatePayroll(dto: GeneratePayrollDto): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    }>;
    validatePayroll(id: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    }>;
    payPayroll(id: string, body: {
        centreId: string;
        userId: string;
        modePaiement?: string;
        banque?: string;
        reference?: string;
        dateEcheance?: string;
    }, authHeader?: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    }>;
    private getUserId;
    findAllPayroll(mois?: string, annee?: string, centreId?: string): Promise<({
        employee: {
            centres: {
                centreId: string;
                employeeId: string;
            }[];
        } & {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string | null;
            nom: string;
            adresse: string | null;
            telephone: string | null;
            email: string | null;
            prenom: string;
            photoUrl: string | null;
            matricule: string | null;
            cin: string | null;
            poste: string;
            contrat: string;
            dateEmbauche: Date;
            salaireBase: number;
            childrenCount: number;
            paymentMode: string;
            socialSecurityAffiliation: boolean;
            familyStatus: string;
        };
    } & {
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    })[]>;
    updatePayroll(id: string, dto: UpdatePayrollDto): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    }>;
    deletePayroll(id: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        commissions: number;
        employeeId: string;
        mois: string;
        salaireBase: number;
        annee: number;
        heuresSup: number;
        primes: number;
        retenues: number;
        avances: number;
        grossSalary: number;
        socialSecurityDeduction: number;
        healthInsuranceDeduction: number;
        incomeTaxDeduction: number;
        professionalExpenses: number;
        employerCharges: number;
        netAPayer: number;
        pdfUrl: string | null;
        expenseId: string | null;
        taxableNet: number;
    }>;
    getPayrollPdf(id: string): Promise<{
        url: unknown;
    }>;
    recordAdvance(id: string, body: {
        amount: number;
        mode: string;
        centreId: string;
        userId: string;
    }): Promise<{
        id: string;
        dateEcheance: Date | null;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        montant: number;
        date: Date;
        reference: string | null;
        description: string | null;
        categorie: string;
        modePaiement: string;
        justificatifUrl: string | null;
        factureFournisseurId: string | null;
        bonLivraisonId: string | null;
        echeanceId: string | null;
        creePar: string | null;
        validePar: string | null;
        fournisseurId: string | null;
        creeParId: string | null;
        valideParId: string | null;
        employeeId: string | null;
    }>;
    getEmployeeAdvances(id: string): Promise<{
        id: string;
        dateEcheance: Date | null;
        statut: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        montant: number;
        date: Date;
        reference: string | null;
        description: string | null;
        categorie: string;
        modePaiement: string;
        justificatifUrl: string | null;
        factureFournisseurId: string | null;
        bonLivraisonId: string | null;
        echeanceId: string | null;
        creePar: string | null;
        validePar: string | null;
        fournisseurId: string | null;
        creeParId: string | null;
        valideParId: string | null;
        employeeId: string | null;
    }[]>;
    getDashboardStats(mois?: string, annee?: string, centreId?: string): Promise<{
        totalNet: number;
        totalCommissions: number;
        totalEmployerCharges: number;
        employeeCount: number;
        history: any[];
        posteDistribution: {
            name: string;
            value: number;
        }[];
    }>;
}
