import { PrismaService } from '../../prisma/prisma.service';
export declare class StockAvailabilityService {
    private prisma;
    constructor(prisma: PrismaService);
    checkAvailability(id: string): Promise<{
        hasConflicts: boolean;
        conflicts: any[];
    }>;
}
