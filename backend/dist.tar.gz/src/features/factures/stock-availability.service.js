"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockAvailabilityService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let StockAvailabilityService = class StockAvailabilityService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async checkAvailability(id) {
        const facture = await this.prisma.facture.findUnique({
            where: { id },
            include: { client: true },
        });
        if (!facture) {
            throw new common_1.NotFoundException(`Document ${id} non trouvé`);
        }
        const lines = facture.lignes || [];
        const conflicts = [];
        const localCentreId = facture.centreId || facture.client?.centreId;
        for (const line of lines) {
            const pid = line.productId;
            if (!pid)
                continue;
            const requestedQty = Number(line.qte) || 1;
            const localProduct = await this.prisma.product.findFirst({
                where: {
                    OR: [
                        { id: pid },
                        {
                            AND: [
                                {
                                    designation: (line.designation ||
                                        line.description ||
                                        '').trim(),
                                },
                                { entrepot: { centreId: localCentreId } },
                            ],
                        },
                    ],
                },
                include: { entrepot: { include: { centre: true } } },
            });
            let alreadyTakenQty = 0;
            if (facture.proprietes?.stockDecremented) {
                alreadyTakenQty = requestedQty;
            }
            const availableQty = (localProduct?.quantiteActuelle || 0) + alreadyTakenQty;
            const isAvailableLocally = availableQty >= requestedQty;
            if (!isAvailableLocally) {
                const otherCentersStock = await this.prisma.product.findMany({
                    where: {
                        designation: (line.designation || line.description || '').trim(),
                        entrepot: { centreId: { not: localCentreId } },
                        quantiteActuelle: { gt: 0 },
                    },
                    include: {
                        entrepot: {
                            include: {
                                centre: true,
                            },
                        },
                    },
                });
                conflicts.push({
                    productId: pid,
                    designation: line.description || line.designation,
                    requestedQty,
                    localAvailableQty: localProduct?.quantiteActuelle || 0,
                    localCentreId,
                    alternatives: otherCentersStock.map((p) => ({
                        productId: p.id,
                        centreId: p.entrepot?.centreId,
                        centreNom: p.entrepot?.centre?.nom || 'Autre Centre',
                        availableQty: p.quantiteActuelle,
                        entrepotNom: p.entrepot?.nom,
                    })),
                });
            }
        }
        return {
            hasConflicts: conflicts.length > 0,
            conflicts,
        };
    }
};
exports.StockAvailabilityService = StockAvailabilityService;
exports.StockAvailabilityService = StockAvailabilityService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StockAvailabilityService);
//# sourceMappingURL=stock-availability.service.js.map