export declare enum FactureType {
    FACTURE = "FACTURE",
    DEVIS = "DEVIS",
    AVOIR = "AVOIR",
    BL = "BL",
    BON_COMM = "BON_COMM",
    BON_COMMANDE = "BON_COMMANDE",
    BON_DE_COMMANDE = "BON_DE_COMMANDE",
    PROFORMA = "PROFORMA"
}
export declare class CreateFactureDto {
    numero?: string;
    clientId: string;
    ficheId?: string;
    type: FactureType;
    statut: string;
    totalHT: number;
    totalTTC: number;
    totalTVA?: number;
    remise?: number;
    dateEmission: Date;
    dateEcheance?: Date;
    lignes?: any[];
    centreId?: string;
    acompteAPayer?: number;
    resteAPayer?: number;
    montantLettres?: string;
    notes?: string;
    originalFactureId?: string;
    proprietes?: any;
    vendeurId?: string;
}
