"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacturesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const loyalty_service_1 = require("../loyalty/loyalty.service");
const paiements_service_1 = require("../paiements/paiements.service");
const stock_availability_service_1 = require("./stock-availability.service");
const products_service_1 = require("../products/products.service");
const commission_service_1 = require("../personnel/commission.service");
let FacturesService = class FacturesService {
    prisma;
    loyaltyService;
    paiementsService;
    productsService;
    commissionService;
    stockAvailabilityService;
    constructor(prisma, loyaltyService, paiementsService, productsService, commissionService, stockAvailabilityService) {
        this.prisma = prisma;
        this.loyaltyService = loyaltyService;
        this.paiementsService = paiementsService;
        this.productsService = productsService;
        this.commissionService = commissionService;
        this.stockAvailabilityService = stockAvailabilityService;
    }
    async onModuleInit() {
        try {
            await this.cleanupExpiredDrafts();
        }
        catch (e) {
            console.error('❌ [FacturesService] Failed during cleanupExpiredDrafts:', e);
        }
        try {
            await this.migrateDraftsToDevis();
        }
        catch (e) {
            console.error('❌ [FacturesService] Failed during migrateDraftsToDevis:', e);
        }
        try {
            await this.migrateBroNumbersToDevis();
        }
        catch (e) {
            console.error('❌ [FacturesService] Failed during migrateBroNumbersToDevis:', e);
        }
    }
    async create(data, userId) {
        const client = await this.prisma.client.findUnique({
            where: { id: data.clientId },
        });
        if (!client) {
            throw new common_1.NotFoundException(`Client ${data.clientId} non trouvé`);
        }
        const cleanData = { ...data };
        delete cleanData.client;
        delete cleanData.paiements;
        delete cleanData.fiche;
        const invoiceCentreId = cleanData.centreId || client.centreId;
        if (cleanData.ficheId) {
            const existing = await this.prisma.facture.findFirst({
                where: { ficheId: cleanData.ficheId },
            });
            if (existing) {
                console.log(`♻️ [UPSERT] Found existing invoice for fiche ${cleanData.ficheId}. Switching to update.`);
                return this.update({
                    where: { id: existing.id },
                    data: { ...cleanData, statut: cleanData.statut || 'DEVIS_EN_COURS' },
                }, userId);
            }
        }
        return this.prisma.$transaction(async (tx) => {
            let resolvedVendeurId = cleanData.vendeurId || cleanData.proprietes?.vendeurId;
            if (!resolvedVendeurId && userId) {
                const user = await tx.user.findUnique({
                    where: { id: userId },
                    include: { employee: true },
                });
                if (user?.employee)
                    resolvedVendeurId = user.employee.id;
            }
            const type = cleanData.type || 'DEVIS';
            const numero = await this.generateNextNumber(type, tx);
            let facture = await tx.facture.create({
                data: {
                    ...cleanData,
                    numero,
                    vendeurId: resolvedVendeurId || null,
                    centreId: invoiceCentreId,
                    statut: cleanData.statut || (type === 'DEVIS' ? 'DEVIS_EN_COURS' : 'VALIDE'),
                    resteAPayer: cleanData.totalTTC || 0,
                },
            });
            console.log(`✅ [CREATE] ${facture.type} ${facture.numero} created.`);
            const isOfficial = ['FACTURE', 'BL', 'AVOIR', 'BON_COMM', 'BON_COMMANDE'].includes(facture.type);
            const isValidated = ['VALIDE', 'PAYEE', 'PARTIEL', 'VENTE_EN_INSTANCE'].includes(facture.statut);
            const shouldDecrement = (isOfficial && isValidated) || facture.proprietes?.forceStockDecrement === true;
            if (shouldDecrement) {
                await this.decrementStockForInvoice(tx, facture, userId);
            }
            const props = facture.proprietes || {};
            const pointsToUse = Number(props.pointsUtilises || 0);
            const pointsAlreadySpent = props.pointsSpent === true;
            if (isOfficial && pointsToUse > 0 && !pointsAlreadySpent) {
                console.log(`🎯 [FIDELIO] Deducting ${pointsToUse} points for official document ${facture.numero}`);
                await this.loyaltyService.spendPoints(facture.clientId, pointsToUse, `Utilisation sur ${facture.type} ${facture.numero}`, facture.id, tx);
                facture = await tx.facture.update({
                    where: { id: facture.id },
                    data: {
                        proprietes: {
                            ...props,
                            pointsSpent: true,
                        },
                    },
                });
            }
            if (facture.vendeurId && isValidated) {
                await this.commissionService.calculateForInvoice(facture.id, tx);
            }
            return tx.facture.findUnique({
                where: { id: facture.id },
                include: { client: true, fiche: true, paiements: true }
            });
        });
    }
    async generateNextNumber(type, tx) {
        const year = new Date().getFullYear();
        const prefix = this.getPrefix(type);
        const prisma = tx || this.prisma;
        const lastDoc = await prisma.facture.findFirst({
            where: {
                numero: {
                    startsWith: `${prefix}-${year}-`,
                },
            },
            orderBy: {
                numero: 'desc',
            },
        });
        let sequence = 1;
        if (lastDoc) {
            const parts = lastDoc.numero.split('-');
            const lastPart = parts[parts.length - 1].trim();
            const lastSeq = parseInt(lastPart);
            if (!isNaN(lastSeq)) {
                sequence = lastSeq + 1;
            }
        }
        return `${prefix}-${year}-${sequence.toString().padStart(3, '0')}`;
    }
    async decrementStockForInvoice(tx, invoice, userId) {
        console.log(`🎬[DEBUG] Starting Stock Decrement for ${invoice.numero}(${invoice.id})`);
        const fullInvoice = await tx.facture.findUnique({
            where: { id: invoice.id },
            include: { client: true },
        });
        if (!fullInvoice) {
            console.log(`❌[DEBUG] Invoice not found in DB: ${invoice.id} `);
            return;
        }
        const props = fullInvoice.proprietes || {};
        const forceDecrement = props.forceStockDecrement === true ||
            props.forceStockDecrement === 'true';
        console.log(`🔍[DEBUG] Properties for ${fullInvoice.numero}: stockDecremented = ${props.stockDecremented}, forceStockDecrement = ${forceDecrement} `);
        if (props.stockDecremented === true || props.stockDecremented === 'true') {
            console.log(`⏩[DEBUG] SKIP: Stock already marked as decremented for ${fullInvoice.numero} (Idempotency enforced)`);
            return;
        }
        let linesToProcess = [];
        try {
            linesToProcess =
                typeof fullInvoice.lignes === 'string'
                    ? JSON.parse(fullInvoice.lignes)
                    : fullInvoice.lignes;
        }
        catch (e) {
            console.error(`❌[DEBUG] Failed to parse lines for ${fullInvoice.numero}: `, e);
        }
        if (!Array.isArray(linesToProcess) || linesToProcess.length === 0) {
            console.log(`⏩[DEBUG] SKIP: No lines to process in invoice ${fullInvoice.numero} `);
            return;
        }
        console.log(`📋[DEBUG] Found ${linesToProcess.length} lines.Processing...`);
        for (const line of linesToProcess) {
            const pid = line.productId;
            const qte = Number(line.qte);
            if (isNaN(qte) || qte <= 0) {
                console.log(`   🚫[DEBUG] Skipping line: "${line.description}"(Invalid Qty: ${qte})`);
                continue;
            }
            console.log(`   🔎[DEBUG] Eval: "${line.description}" | PID: ${pid} | Qty: ${qte} `);
            let product = null;
            if (pid) {
                product = await tx.product.findUnique({
                    where: { id: pid },
                    include: { entrepot: true },
                });
            }
            const invoiceCentreId = fullInvoice.centreId || fullInvoice.client?.centreId;
            if (!product ||
                (product.entrepot?.centreId !== invoiceCentreId && invoiceCentreId)) {
                console.log(`   🔄[DEBUG] Falling back to model-based search for: "${line.description}" (Product Wh: ${product?.entrepot?.centreId || 'None'} vs Invoice Centre: ${invoiceCentreId})`);
                const targetCentreId = invoiceCentreId;
                if (targetCentreId) {
                    const localMatch = await this.productsService.findLocalCounterpart({
                        designation: (line.designation || line.description || '').trim(),
                        codeInterne: (line.codeInterne || line.reference || '').trim(),
                        codeBarres: (line.codeBarres || '').trim(),
                        centreId: targetCentreId,
                    });
                    if (localMatch) {
                        console.log(`   ✨[DEBUG] Found local counterpart: ${localMatch.id} (${localMatch.designation})`);
                        product = localMatch;
                    }
                    else {
                        console.log(`   ⚠️ [DEBUG] No local counterpart found for: "${line.description}" in center ${targetCentreId}`);
                    }
                }
            }
            if (!product) {
                console.log(`   ❌[DEBUG] Product NOT FOUND locally: ${pid} (${line.description})`);
                continue;
            }
            const entrepotId = line.entrepotId || product.entrepotId;
            const isEligible = !!entrepotId;
            if (isEligible) {
                const actionDesc = fullInvoice.type === 'AVOIR' ? 'Incrementing' : 'Decrementing';
                const moveQty = fullInvoice.type === 'AVOIR' ? qte : -qte;
                const stockChange = fullInvoice.type === 'AVOIR'
                    ? { increment: qte }
                    : { decrement: qte };
                const moveType = fullInvoice.type === 'AVOIR' ? 'ENTREE_RETOUR' : 'SORTIE_VENTE';
                if (fullInvoice.type !== 'AVOIR' && product.quantiteActuelle < qte) {
                    const msg = `Stock insuffisant pour "${product.designation}" (Réf: ${line.reference || 'N/A'}). Disponible: ${product.quantiteActuelle}, Requis: ${qte}`;
                    console.error(`❌[STOCK] ${msg}`);
                    throw new common_1.BadRequestException(msg);
                }
                await tx.product.update({
                    where: { id: product.id },
                    data: { quantiteActuelle: stockChange },
                });
                await tx.mouvementStock.create({
                    data: {
                        type: moveType,
                        quantite: moveQty,
                        produitId: product.id,
                        entrepotSourceId: fullInvoice.type === 'AVOIR' ? null : entrepotId,
                        entrepotDestinationId: fullInvoice.type === 'AVOIR' ? entrepotId : null,
                        factureId: fullInvoice.id,
                        prixAchatUnitaire: product.prixAchatHT,
                        prixVenteUnitaire: fullInvoice.type === 'AVOIR' ? undefined : line.prixUnitaireTTC,
                        motif: fullInvoice.fiche
                            ? `Vente Monture - Fiche n° ${fullInvoice.fiche.numero}${fullInvoice.fiche.dateCreation ? ' du ' + new Date(fullInvoice.fiche.dateCreation).toLocaleDateString('fr-FR') : ''} (${fullInvoice.statut})`
                            : `Facturation ${fullInvoice.numero} (${fullInvoice.statut})`,
                        utilisateur: userId ? `User ${userId} ` : 'System',
                        userId: userId || null,
                        dateMovement: new Date(),
                    },
                });
                console.log(`   ✅[DEBUG] Success: ${actionDesc} complete.`);
            }
        }
        await tx.facture.update({
            where: { id: fullInvoice.id },
            data: {
                proprietes: {
                    ...props,
                    stockDecremented: true,
                    forceStockDecrement: false,
                    dateStockDecrement: new Date(),
                },
            },
        });
        console.log(`🎬[DEBUG] Stock Decrement Complete & Flagged for ${fullInvoice.numero}`);
    }
    async verifyProductsAreReceived(lignes, type) {
        if (type === 'AVOIR' || type === 'AVOIR_FOURNISSEUR' || type === 'BON_COMM')
            return;
        if (!Array.isArray(lignes))
            return;
        for (const line of lignes) {
            const pid = line.productId;
            if (!pid)
                continue;
            const product = await this.prisma.product.findUnique({
                where: { id: pid },
                select: {
                    id: true,
                    designation: true,
                    specificData: true,
                    entrepot: { select: { centreId: true } },
                },
            });
            if (product && product.entrepot?.centreId && type !== 'AVOIR') {
                const sd = product.specificData || {};
                if (sd.pendingIncoming) {
                    const status = sd.pendingIncoming.status || 'RESERVED';
                    const detail = status === 'SHIPPED'
                        ? "en cours d'expédition"
                        : 'réservé à la source';
                    throw new common_1.BadRequestException(`Impossible de valider la facture : le produit "${product.designation}" est ${detail} (Transfert en cours). ` +
                        `Veuillez d'abord confirmer la réception du produit pour alimenter le stock local.`);
                }
            }
        }
    }
    async checkStockAvailability(id) {
        return this.stockAvailabilityService.checkAvailability(id);
    }
    async findAll(params) {
        const { skip, take = 10, cursor, where, orderBy } = params;
        const factures = await this.prisma.facture.findMany({
            skip,
            take,
            cursor,
            where,
            orderBy,
            include: {
                client: true,
                fiche: true,
                paiements: true,
            },
        });
        return factures;
    }
    async findOne(id) {
        return this.prisma.facture.findUnique({
            where: { id },
            include: {
                client: true,
                fiche: true,
                paiements: true,
            },
        });
    }
    async restoreStockForCancelledInvoice(tx, invoice) {
        console.log(`🔄[DEBUG] Starting Stock Restoration for ${invoice.numero}(${invoice.id})`);
        const fullInvoice = await tx.facture.findUnique({
            where: { id: invoice.id },
            include: { client: true },
        });
        if (!fullInvoice)
            return;
        const props = fullInvoice.proprietes || {};
        if (!props.stockDecremented) {
            console.log(`⏩[DEBUG] Stock was never decremented for ${fullInvoice.numero}. Skipping.`);
            return;
        }
        let linesToProcess = [];
        try {
            linesToProcess =
                typeof fullInvoice.lignes === 'string'
                    ? JSON.parse(fullInvoice.lignes)
                    : fullInvoice.lignes;
        }
        catch (e) {
            console.error(`❌[DEBUG] Failed to parse lines for restoration of ${fullInvoice.numero}: `, e);
        }
        const invoiceCentreId = fullInvoice.centreId || fullInvoice.client?.centreId;
        for (const line of linesToProcess) {
            const qte = Number(line.qte);
            const pid = line.productId;
            if (!pid || isNaN(qte) || qte <= 0)
                continue;
            let product = await tx.product.findUnique({
                where: { id: pid },
                include: { entrepot: true },
            });
            if (!product ||
                (product.entrepot?.centreId !== invoiceCentreId && invoiceCentreId)) {
                const targetCentreId = invoiceCentreId;
                if (targetCentreId) {
                    const localMatch = await this.productsService.findLocalCounterpart({
                        designation: (line.designation || line.description || '').trim(),
                        codeInterne: (line.codeInterne || line.reference || '').trim(),
                        codeBarres: (line.codeBarres || '').trim(),
                        centreId: targetCentreId,
                    });
                    if (localMatch)
                        product = localMatch;
                }
            }
            if (product) {
                await tx.product.update({
                    where: { id: product.id },
                    data: { quantiteActuelle: { increment: qte } },
                });
                await tx.mouvementStock.create({
                    data: {
                        produitId: product.id,
                        entrepotDestinationId: product.entrepotId,
                        factureId: fullInvoice.id,
                        type: 'ENTREE_RETOUR',
                        quantite: qte,
                        motif: `Annulation/Conversion ${invoice.numero} - Stock restauré`,
                        utilisateur: 'System',
                        dateMovement: new Date(),
                    },
                });
            }
        }
        await tx.facture.update({
            where: { id: invoice.id },
            data: {
                proprietes: {
                    ...props,
                    stockDecremented: false,
                    stockRestored: true,
                    restoredAt: new Date(),
                },
            },
        });
    }
    async update(params, userId, tx) {
        const runUpdate = async (txClient) => {
            const { where, data } = params;
            const currentFacture = (await txClient.facture.findUnique({
                where,
                include: { paiements: true, client: true },
            }));
            if (!currentFacture) {
                throw new common_1.NotFoundException(`Facture ${where.id} non trouvée`);
            }
            if (!data.centreId && !currentFacture.centreId && (data.clientId || currentFacture.clientId)) {
                const cid = data.clientId || currentFacture.clientId;
                const targetClient = await txClient.client.findUnique({ where: { id: cid }, select: { centreId: true } });
                if (targetClient?.centreId) {
                    data.centreId = targetClient.centreId;
                }
            }
            const num = (currentFacture.numero || '').trim().toUpperCase();
            const isCurrentlyDevis = (currentFacture.type === 'DEVIS' ||
                currentFacture.statut === 'BROUILLON' ||
                num.startsWith('DEV') ||
                num.startsWith('BRO')) &&
                currentFacture.type !== 'FACTURE';
            const effectiveType = data.type || currentFacture.type;
            if (isCurrentlyDevis &&
                ['BON_COMM', 'BON_COMMANDE', 'BON_DE_COMMANDE', 'FACTURE', 'BL'].includes(effectiveType)) {
                const stockCheck = await this.checkStockAvailability(currentFacture.id);
                if (stockCheck.hasConflicts) {
                    throw new common_1.ConflictException({
                        message: 'Impossible de transformer : produits en rupture de stock.',
                        conflicts: stockCheck.conflicts,
                    });
                }
                console.log(`📌 [TRANSITION] ${currentFacture.numero} -> ${effectiveType}`);
                data.numero = await this.generateNextNumber(effectiveType, txClient);
                if (['BON_COMM', 'BON_COMMANDE', 'BON_DE_COMMANDE'].includes(effectiveType)) {
                    data.statut = 'VENTE_EN_INSTANCE';
                }
            }
            const isBecomingValid = data.statut === 'VALIDE';
            const isTargetingBC = ['BON_COMM', 'BON_DE_COMMANDE', 'BON_COMMANDE'].includes(data.type || '');
            const isFirstValidation = !currentFacture.numero?.startsWith('FAC');
            const amountChanged = data.totalTTC !== undefined && Math.abs((data.totalTTC || 0) - (currentFacture.totalTTC || 0)) > 0.1;
            const shouldTriggerFiscalFlow = isBecomingValid && !isTargetingBC && (isFirstValidation || amountChanged || data.proprietes?.forceFiscal === true);
            if (shouldTriggerFiscalFlow) {
                await this.verifyProductsAreReceived(currentFacture.lignes, 'FACTURE');
                const targetType = data.type || currentFacture.type;
                const officialNumber = await this.generateNextNumber(targetType, txClient);
                const { client, paiements, fiche, id, ...existingFlat } = currentFacture;
                const { client: dClient, paiements: dPai, fiche: dFiche, ...incomingData } = data;
                const cleanProprietes = {
                    ...(existingFlat.proprietes || {}),
                    ...(incomingData.proprietes || {}),
                    stockDecremented: false,
                    dateStockDecrement: null,
                    ancienneReference: currentFacture.numero,
                    forceStockDecrement: true,
                };
                const newInvoiceData = {
                    ...existingFlat,
                    ...incomingData,
                    proprietes: cleanProprietes,
                    numero: officialNumber,
                    statut: 'VALIDE',
                    dateEmission: new Date(),
                    type: data.type || 'FACTURE',
                    clientId: currentFacture.clientId,
                    centreId: currentFacture.centreId,
                };
                if (currentFacture.numero.startsWith('FAC')) {
                    console.log(`ℹ️ [FISCAL] official invoice conversion. Creating AVOIR for ${currentFacture.numero}`);
                    const avoirData = {
                        type: 'AVOIR',
                        statut: 'VALIDE',
                        numero: await this.generateNextNumber('AVOIR', txClient),
                        dateEmission: new Date(),
                        clientId: currentFacture.clientId,
                        centreId: currentFacture.centreId,
                        lignes: currentFacture.lignes.map(l => ({ ...l, prixUnitaireTTC: -l.prixUnitaireTTC, totalTTC: -l.totalTTC })),
                        totalHT: -currentFacture.totalHT,
                        totalTVA: -currentFacture.totalTVA,
                        totalTTC: -currentFacture.totalTTC,
                        resteAPayer: 0,
                        proprietes: { ...currentFacture.proprietes, stockDecremented: false, factureOriginale: currentFacture.numero, isAutoGenerated: true },
                    };
                    const autoAvoir = await txClient.facture.create({ data: avoirData });
                    if (currentFacture.proprietes?.stockDecremented) {
                        await this.decrementStockForInvoice(txClient, autoAvoir, userId);
                    }
                }
                else {
                    await this.restoreStockForCancelledInvoice(txClient, currentFacture);
                }
                await txClient.facture.update({
                    where: { id: currentFacture.id },
                    data: { statut: 'ANNULEE', resteAPayer: 0, ficheId: null }
                });
                const newInvoice = await txClient.facture.create({ data: newInvoiceData });
                await txClient.facture.update({
                    where: { id: currentFacture.id },
                    data: { notes: `Remplacée par ${newInvoice.numero}` }
                });
                const pMove = await txClient.paiement.findMany({ where: { factureId: currentFacture.id } });
                const totalPaid = pMove.reduce((s, p) => s + Number(p.montant), 0);
                if (pMove.length > 0) {
                    await txClient.paiement.updateMany({ where: { factureId: currentFacture.id }, data: { factureId: newInvoice.id } });
                }
                let finalStatut = 'VALIDE';
                let reste = Math.max(0, Number(newInvoice.totalTTC) - totalPaid);
                if (totalPaid >= Number(newInvoice.totalTTC) - 0.05) {
                    finalStatut = 'PAYEE';
                    reste = 0;
                }
                else if (totalPaid > 0) {
                    finalStatut = 'PARTIEL';
                }
                const finalInvoice = await txClient.facture.update({
                    where: { id: newInvoice.id },
                    data: { ficheId: currentFacture.ficheId, statut: finalStatut, resteAPayer: reste }
                });
                await this.decrementStockForInvoice(txClient, finalInvoice, userId);
                if (finalInvoice.vendeurId)
                    await this.commissionService.calculateForInvoice(finalInvoice.id, txClient);
                await this.loyaltyService.awardPointsForPurchase(finalInvoice.id, txClient);
                return finalInvoice;
            }
            console.log(`[DIAGNOSTIC] FacturesService.update called for ${where.id}. Data:`, data.proprietes ? JSON.stringify(data.proprietes) : 'undef');
            const allowedFields = ['numero', 'type', 'dateEmission', 'dateEcheance', 'statut', 'clientId', 'ficheId', 'totalHT', 'totalTVA', 'totalTTC', 'resteAPayer', 'lignes', 'proprietes', 'parentFactureId', 'montantLettres', 'notes', 'centreId', 'exportComptable', 'typeOperation', 'vendeurId'];
            const cleanData = {};
            for (const field of allowedFields) {
                if (data[field] !== undefined)
                    cleanData[field] = data[field];
            }
            if (cleanData.proprietes) {
                const p = currentFacture.proprietes || {};
                cleanData.proprietes = {
                    ...p,
                    ...cleanData.proprietes,
                    stockDecremented: p.stockDecremented || cleanData.proprietes.stockDecremented,
                    pointsSpent: p.pointsSpent || cleanData.proprietes.pointsSpent,
                    pointsAwarded: p.pointsAwarded || cleanData.proprietes.pointsAwarded,
                };
            }
            const updatedType = cleanData.type || currentFacture.type;
            const isOfficialDoc = ['FACTURE', 'BL', 'AVOIR', 'BON_COMM', 'BON_COMMANDE'].includes(updatedType);
            if (isOfficialDoc && cleanData.proprietes?.pointsUtilises !== undefined) {
                const oldP = Number(currentFacture.proprietes?.pointsUtilises || 0);
                const newP = Number(cleanData.proprietes.pointsUtilises);
                const delta = newP - oldP;
                const wasSpent = currentFacture.proprietes?.pointsSpent === true;
                if (!wasSpent && newP > 0) {
                    console.log(`🎯 [FIDELIO] Upgrading doc to Official. Initial deduction of ${newP} points for ${currentFacture.numero}`);
                    await this.loyaltyService.spendPoints(currentFacture.clientId, newP, `Utilisation sur ${updatedType} ${currentFacture.numero}`, currentFacture.id, txClient);
                    cleanData.proprietes.pointsSpent = true;
                }
                else if (wasSpent && delta !== 0) {
                    console.log(`🎯 [FIDELIO] Adjusting points for Official doc. Delta: ${delta} points for ${currentFacture.numero}`);
                    await this.loyaltyService.spendPoints(currentFacture.clientId, delta, `Ajustement sur ${updatedType} ${currentFacture.numero}`, currentFacture.id, txClient);
                    cleanData.proprietes.pointsSpent = newP > 0;
                }
            }
            const updated = await txClient.facture.update({ where, data: cleanData });
            const isVal = ['VALIDE', 'PAYEE', 'PARTIEL', 'VENTE_EN_INSTANCE'].includes(updated.statut);
            if ((isOfficialDoc && isVal) || updated.proprietes?.forceStockDecrement === true) {
                await this.decrementStockForInvoice(txClient, updated, userId);
                if (updated.vendeurId)
                    await this.commissionService.calculateForInvoice(updated.id, txClient);
            }
            if (updated.statut === 'ANNULEE' && updated.proprietes?.restoreStock === true) {
                await this.restoreStockForCancelledInvoice(txClient, updated);
            }
            return updated;
        };
        return tx ? runUpdate(tx) : this.prisma.$transaction(async (newTx) => runUpdate(newTx));
    }
    async remove(where) {
        const facture = await this.prisma.facture.findUnique({ where, include: { paiements: true } });
        if (!facture)
            throw new common_1.NotFoundException('Facture non trouvée');
        const num = facture.numero.toUpperCase();
        const isOfficial = !num.startsWith('BRO') && !num.startsWith('DEV');
        let isLast = true;
        if (isOfficial) {
            const next = await this.prisma.facture.findFirst({
                where: {
                    type: facture.type,
                    numero: {
                        gt: facture.numero,
                        startsWith: this.getPrefix(facture.type)
                    }
                }
            });
            isLast = !next;
        }
        if (isLast) {
            return this.prisma.facture.delete({ where });
        }
        else {
            const avoirNumero = await this.generateNextNumber('AVOIR');
            const avoir = await this.prisma.facture.create({
                data: {
                    numero: avoirNumero, type: 'AVOIR', clientId: facture.clientId, statut: 'VALIDE', dateEmission: new Date(),
                    totalHT: -Math.abs(facture.totalHT), totalTVA: -Math.abs(facture.totalTVA), totalTTC: -Math.abs(facture.totalTTC), resteAPayer: 0,
                    lignes: facture.lignes.map(l => ({ ...l, prixUnitaireTTC: -Math.abs(l.prixUnitaireTTC), totalTTC: -Math.abs(l.totalTTC) })),
                    notes: `Avoir sur ${facture.numero}`, proprietes: { ...facture.proprietes, ficheId: facture.ficheId }
                }
            });
            await this.prisma.facture.update({ where: { id: facture.id }, data: { statut: 'ANNULEE', resteAPayer: 0 } });
            return { action: 'AVOIR_CREATED', avoir };
        }
    }
    getPrefix(type) {
        switch (type) {
            case 'FACTURE': return 'Fact';
            case 'DEVIS': return 'Devis';
            case 'AVOIR': return 'AVR';
            case 'BL': return 'BL';
            case 'BON_COMM':
            case 'BON_COMMANDE': return 'BC';
            default: return 'DOC';
        }
    }
    async applyPendingFidelioRewards(factureId, tx) {
        try {
            const invoice = await tx.facture.findUnique({ where: { id: factureId } });
            if (!invoice || invoice.resteAPayer <= 0)
                return;
            const rewards = await tx.rewardRedemption.findMany({ where: { clientId: invoice.clientId, isUsed: false }, orderBy: { redeemedAt: 'asc' } });
            if (rewards.length === 0)
                return;
            let remaining = invoice.resteAPayer;
            for (const r of rewards) {
                if (remaining <= 0)
                    break;
                const amount = Math.min(r.madValue, remaining);
                const p = await tx.paiement.create({
                    data: { montant: amount, mode: 'FIDELIO', statut: 'ENCAISSE', reference: `Bonus Fidelio - ${r.pointsUsed} pts`, notes: 'Paiement auto points', factureId: invoice.id, date: new Date() }
                });
                await tx.rewardRedemption.update({ where: { id: r.id }, data: { isUsed: true, paiementId: p.id } });
                remaining -= amount;
            }
            if (remaining < invoice.resteAPayer) {
                const remRounded = Math.max(0, parseFloat(remaining.toFixed(2)));
                let newStatut = invoice.statut;
                if (remRounded <= 0 && invoice.statut !== 'PAYEE')
                    newStatut = 'PAYEE';
                else if (remRounded > 0 && invoice.statut !== 'PARTIEL' && invoice.type === 'FACTURE')
                    newStatut = 'PARTIEL';
                await tx.facture.update({ where: { id: factureId }, data: { resteAPayer: remRounded, statut: newStatut } });
            }
        }
        catch (e) {
            console.error('❌ [FIDELIO] Reward apply fail:', e);
        }
    }
    async createExchange(invoiceId, items, centreId) {
        if (!centreId)
            throw new common_1.BadRequestException('ID du centre manquant');
        const original = await this.prisma.facture.findUnique({ where: { id: invoiceId } });
        if (!original)
            throw new common_1.NotFoundException('Facture initiale non trouvée');
        const lines = (typeof original.lignes === 'string' ? JSON.parse(original.lignes) : original.lignes);
        return this.prisma.$transaction(async (tx) => {
            const newNum = await this.generateNextNumber('FACTURE', tx);
            const avNum = await this.generateNextNumber('AVOIR', tx);
            const avoir = await tx.facture.create({
                data: {
                    numero: avNum, type: 'AVOIR', statut: 'VALIDE', clientId: original.clientId, parentFactureId: original.id, dateEmission: new Date(),
                    totalHT: -original.totalHT, totalTVA: -original.totalTVA, totalTTC: -original.totalTTC, resteAPayer: 0,
                    lignes: lines.map(l => ({ ...l, prixUnitaireTTC: -l.prixUnitaireTTC, totalTTC: -l.totalTTC })),
                    notes: `Avoir facture n° : ${original.numero}`, proprietes: { factureOriginale: original.numero, ficheId: original.ficheId }, centreId: original.centreId
                }
            });
            await tx.facture.update({ where: { id: original.id }, data: { statut: 'ANNULEE', ficheId: null, resteAPayer: 0, notes: `Remplacée par ${newNum}` } });
            const defectiveWh = await this.getOrCreateDefectiveWarehouse(tx, centreId);
            for (const item of items) {
                const line = lines[item.lineIndex];
                if (line && line.productId) {
                    const prod = await tx.product.findUnique({ where: { id: line.productId } });
                    if (prod) {
                        const targetWh = item.reason === 'DEFECTUEUX' ? defectiveWh.id : line.entrepotId;
                        await tx.product.update({ where: { id: prod.id }, data: { quantiteActuelle: { increment: item.quantiteRetour } } });
                        await tx.mouvementStock.create({
                            data: { type: 'ENTREE_RETOUR_CLIENT', quantite: item.quantiteRetour, produitId: prod.id, entrepotDestinationId: targetWh, factureId: original.id, motif: `Retour ${item.reason}`, utilisateur: 'System' }
                        });
                    }
                }
            }
            const newLines = lines.map((l, i) => {
                const ret = items.find(r => r.lineIndex === i);
                if (ret) {
                    const isMonture = l.designation?.toLowerCase().includes('monture');
                    return { ...l, designation: isMonture ? 'Monture Client' : l.designation, prixUnitaireTTC: 0, totalHT: 0, totalTVA: 0, totalTTC: 0, productId: null };
                }
                return l;
            });
            const nTTC = newLines.reduce((s, l) => s + l.totalTTC, 0);
            const newInvoice = await tx.facture.create({
                data: { numero: newNum, type: 'FACTURE', statut: 'VALIDE', clientId: original.clientId, centreId: original.centreId, dateEmission: new Date(), lignes: newLines, totalTTC: nTTC, resteAPayer: nTTC, ficheId: original.ficheId, parentFactureId: original.id }
            });
            const pTrans = await tx.paiement.findMany({ where: { factureId: original.id } });
            const totalP = pTrans.reduce((s, p) => s + p.montant, 0);
            await tx.paiement.updateMany({ where: { factureId: original.id }, data: { factureId: newInvoice.id } });
            if (totalP > nTTC) {
                const diff = totalP - nTTC;
                const ref = await tx.paiement.create({ data: { factureId: newInvoice.id, montant: -diff, mode: 'ESPECES', statut: 'DECAISSEMENT', date: new Date(), notes: 'Rendu monnaie' } });
                await this.paiementsService.handleCaisseIntegration(tx, ref, newInvoice);
            }
            await tx.facture.update({ where: { id: newInvoice.id }, data: { resteAPayer: Math.max(0, nTTC - totalP) } });
            return { avoir, newInvoice };
        });
    }
    async cleanupExpiredDrafts() {
        const twoMonthsAgo = new Date();
        twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
        const expired = await this.prisma.facture.findMany({ where: { statut: 'BROUILLON', dateEmission: { lt: twoMonthsAgo }, paiements: { none: {} } } });
        if (expired.length > 0) {
            await this.prisma.facture.updateMany({ where: { id: { in: expired.map(d => d.id) } }, data: { statut: 'ANNULEE', notes: 'Expiré' } });
        }
    }
    async migrateDraftsToDevis() {
        await this.prisma.facture.updateMany({ where: { statut: 'BROUILLON', type: 'FACTURE' }, data: { type: 'DEVIS' } });
    }
    async migrateBroNumbersToDevis() {
        const drafts = await this.prisma.facture.findMany({ where: { numero: { startsWith: 'BRO-' } } });
        for (const d of drafts) {
            await this.prisma.facture.update({ where: { id: d.id }, data: { numero: d.numero.replace('BRO-', 'Devis-') } });
        }
    }
    async getOrCreateDefectiveWarehouse(tx, centreId) {
        let wh = await tx.entrepot.findFirst({ where: { centreId, nom: { contains: 'défectueux', mode: 'insensitive' } } });
        if (!wh) {
            wh = await tx.entrepot.create({ data: { nom: 'Entrepot Défectueux', type: 'TRANSIT', centreId } });
        }
        return wh;
    }
};
exports.FacturesService = FacturesService;
exports.FacturesService = FacturesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        loyalty_service_1.LoyaltyService,
        paiements_service_1.PaiementsService,
        products_service_1.ProductsService,
        commission_service_1.CommissionService,
        stock_availability_service_1.StockAvailabilityService])
], FacturesService);
//# sourceMappingURL=factures.service.js.map