export declare class FacturesModule {
}
