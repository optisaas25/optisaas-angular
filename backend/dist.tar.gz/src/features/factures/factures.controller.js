"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacturesController = void 0;
const common_1 = require("@nestjs/common");
const jwt = __importStar(require("jsonwebtoken"));
const config_1 = require("@nestjs/config");
const factures_service_1 = require("./factures.service");
const create_facture_dto_1 = require("./dto/create-facture.dto");
const update_facture_dto_1 = require("./dto/update-facture.dto");
let FacturesController = class FacturesController {
    facturesService;
    configService;
    constructor(facturesService, configService) {
        this.facturesService = facturesService;
        this.configService = configService;
    }
    createExchange(id, body, centreId) {
        return this.facturesService.createExchange(id, body.itemsToReturn, centreId);
    }
    create(createFactureDto, centreId, authHeader) {
        if (centreId) {
            createFactureDto.centreId = centreId;
        }
        const userId = this.getUserId(authHeader);
        return this.facturesService.create(createFactureDto, userId);
    }
    findAll(clientId, type, statut, ficheId, unpaid, startDate, endDate, centreId) {
        if (ficheId) {
            return this.facturesService.findAll({
                where: { ficheId },
                take: 1,
            });
        }
        if (!centreId)
            return [];
        const where = { centreId };
        if (clientId)
            where.clientId = clientId;
        if (type)
            where.type = type;
        if (statut)
            where.statut = statut;
        if (startDate || endDate) {
            const dateRange = {};
            if (startDate) {
                const start = new Date(startDate);
                start.setHours(0, 0, 0, 0);
                dateRange.gte = start;
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                dateRange.lte = end;
            }
            where.createdAt = dateRange;
        }
        if (unpaid === 'true') {
            where.AND = [
                { resteAPayer: { gt: 0.05 } },
                { statut: { not: 'ANNULEE' } },
            ];
        }
        return this.facturesService.findAll({
            where,
            orderBy: { createdAt: 'desc' },
            take: 500,
        });
    }
    checkAvailability(id) {
        return this.facturesService.checkStockAvailability(id);
    }
    findOne(id) {
        return this.facturesService.findOne(id);
    }
    update(id, updateFactureDto, authHeader) {
        const userId = this.getUserId(authHeader);
        return this.facturesService.update({
            where: { id },
            data: updateFactureDto,
        }, userId);
    }
    getUserId(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer '))
            return undefined;
        try {
            const token = authHeader.split(' ')[1];
            const secret = this.configService.get('JWT_SECRET') || 'your-very-secret-key';
            const payload = jwt.verify(token, secret);
            return payload.sub;
        }
        catch (e) {
            return undefined;
        }
    }
    remove(id) {
        return this.facturesService.remove({ id });
    }
};
exports.FacturesController = FacturesController;
__decorate([
    (0, common_1.Post)(':id/exchange'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "createExchange", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('Tenant')),
    __param(2, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_facture_dto_1.CreateFactureDto, String, String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('statut')),
    __param(3, (0, common_1.Query)('ficheId')),
    __param(4, (0, common_1.Query)('unpaid')),
    __param(5, (0, common_1.Query)('startDate')),
    __param(6, (0, common_1.Query)('endDate')),
    __param(7, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id/check-availability'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "checkAvailability", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_facture_dto_1.UpdateFactureDto, String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FacturesController.prototype, "remove", null);
exports.FacturesController = FacturesController = __decorate([
    (0, common_1.Controller)('factures'),
    __metadata("design:paramtypes", [factures_service_1.FacturesService,
        config_1.ConfigService])
], FacturesController);
//# sourceMappingURL=factures.controller.js.map