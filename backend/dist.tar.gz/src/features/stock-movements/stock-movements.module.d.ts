export declare class StockMovementsModule {
}
