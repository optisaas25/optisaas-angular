"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockMovementsController = void 0;
const common_1 = require("@nestjs/common");
const stock_movements_service_1 = require("./stock-movements.service");
const bulk_alimentation_dto_1 = require("./dto/bulk-alimentation.dto");
let StockMovementsController = class StockMovementsController {
    service;
    constructor(service) {
        this.service = service;
    }
    bulkAlimentation(dto) {
        return this.service.processBulkAlimentation(dto);
    }
    findAllByProduct(productId) {
        return this.service.findAllByProduct(productId);
    }
    getHistory(dateFrom, dateTo, supplierId, docType, centreId) {
        return this.service.getHistory({
            dateFrom,
            dateTo,
            supplierId,
            docType,
            centreId,
        });
    }
    getOutHistory(dateFrom, dateTo, search, centreId) {
        return this.service.getOutHistory({ dateFrom, dateTo, search, centreId });
    }
    debugData() {
        return this.service.debugData();
    }
    deleteHistory(id) {
        return this.service.removeEntryHistory(id);
    }
};
exports.StockMovementsController = StockMovementsController;
__decorate([
    (0, common_1.Post)('bulk-alimentation'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_alimentation_dto_1.BulkAlimentationDto]),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "bulkAlimentation", null);
__decorate([
    (0, common_1.Get)('product/:productId'),
    __param(0, (0, common_1.Param)('productId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "findAllByProduct", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Query)('dateFrom')),
    __param(1, (0, common_1.Query)('dateTo')),
    __param(2, (0, common_1.Query)('supplierId')),
    __param(3, (0, common_1.Query)('docType')),
    __param(4, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Get)('out-history'),
    __param(0, (0, common_1.Query)('dateFrom')),
    __param(1, (0, common_1.Query)('dateTo')),
    __param(2, (0, common_1.Query)('search')),
    __param(3, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "getOutHistory", null);
__decorate([
    (0, common_1.Get)('debug-data'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "debugData", null);
__decorate([
    (0, common_1.Delete)('history/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockMovementsController.prototype, "deleteHistory", null);
exports.StockMovementsController = StockMovementsController = __decorate([
    (0, common_1.Controller)('stock-movements'),
    __metadata("design:paramtypes", [stock_movements_service_1.StockMovementsService])
], StockMovementsController);
//# sourceMappingURL=stock-movements.controller.js.map