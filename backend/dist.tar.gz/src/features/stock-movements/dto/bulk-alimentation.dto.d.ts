declare class AllocationDto {
    productId?: string;
    reference: string;
    nom: string;
    codeBarre?: string;
    categorie: string;
    marque?: string;
    warehouseId: string;
    quantite: number;
    prixAchat: number;
    prixVente: number;
    tva: number;
    materiau?: string;
    forme?: string;
    genre?: string;
    couleur?: string;
    calibre?: string;
    pont?: string;
}
export declare class BulkAlimentationDto {
    numeroFacture: string;
    dateEmission: string;
    dateEcheance?: string;
    type: string;
    fournisseurId: string;
    centreId?: string;
    base64File?: string;
    fileName?: string;
    allocations: AllocationDto[];
}
export {};
