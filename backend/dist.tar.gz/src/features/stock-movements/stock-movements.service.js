"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockMovementsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const products_service_1 = require("../products/products.service");
const date_utils_1 = require("../../shared/utils/date-utils");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let StockMovementsService = class StockMovementsService {
    prisma;
    productsService;
    constructor(prisma, productsService) {
        this.prisma = prisma;
        this.productsService = productsService;
    }
    async findAllByProduct(productId) {
        return this.prisma.mouvementStock.findMany({
            where: { produitId: productId },
            orderBy: { dateMovement: 'desc' },
            include: {
                entrepotSource: true,
                entrepotDestination: true,
                facture: {
                    include: {
                        fiche: true,
                        client: true,
                    },
                },
                bonLivraison: {
                    include: {
                        fiche: true,
                        client: true,
                    },
                },
            },
        });
    }
    async processBulkAlimentation(dto) {
        const { allocations, base64File, fileName, ...invoiceData } = dto;
        try {
            return await this.prisma.$transaction(async (tx) => {
                let pieceJointeUrl = '';
                if (base64File && fileName) {
                    const uploadDir = path.join(process.cwd(), 'uploads', 'invoices');
                    if (!fs.existsSync(uploadDir)) {
                        fs.mkdirSync(uploadDir, { recursive: true });
                    }
                    const fileExt = path.extname(fileName) || '.jpg';
                    const safeName = `inv_${Date.now()}${fileExt}`;
                    const filePath = path.join(uploadDir, safeName);
                    const buffer = Buffer.from(base64File.replace(/^data:.*?;base64,/, ''), 'base64');
                    fs.writeFileSync(filePath, buffer);
                    pieceJointeUrl = `/uploads/invoices/${safeName}`;
                }
                const totalHT = allocations.reduce((sum, a) => sum + Number(a.prixAchat) * Number(a.quantite), 0);
                const totalTTC = allocations.reduce((sum, a) => {
                    const tvaAmount = Number(a.prixAchat) * (Number(a.tva) / 100);
                    return sum + (Number(a.prixAchat) + tvaAmount) * Number(a.quantite);
                }, 0);
                let effectiveCentreId = invoiceData.centreId;
                if (!effectiveCentreId && allocations.length > 0) {
                    const firstWarehouseId = allocations[0].warehouseId;
                    const warehouse = await tx.entrepot.findUnique({
                        where: { id: firstWarehouseId },
                    });
                    if (warehouse?.centreId) {
                        effectiveCentreId = warehouse.centreId;
                        console.log(`💡 [STOCK] Inferred Centre ID from warehouse: ${effectiveCentreId}`);
                    }
                }
                const trimmedNumero = invoiceData.numeroFacture.trim();
                let invoice = await tx.factureFournisseur.findFirst({
                    where: {
                        fournisseurId: invoiceData.fournisseurId,
                        numeroFacture: {
                            equals: trimmedNumero,
                            mode: 'insensitive',
                        },
                    },
                    include: { echeances: true },
                });
                if (invoice) {
                    console.warn(`[STOCK] Duplicate alimentation attempt for invoice ${invoice.numeroFacture}`);
                    throw new common_1.BadRequestException(`La facture ${invoice.numeroFacture} existe déjà. Vous ne pouvez pas alimenter le stock deux fois sur la même facture/BL pour éviter les doublons.`);
                }
                invoice = await tx.factureFournisseur.create({
                    data: {
                        numeroFacture: invoiceData.numeroFacture,
                        dateEmission: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEmission),
                        dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEcheance || invoiceData.dateEmission),
                        type: invoiceData.type,
                        statut: 'A_PAYER',
                        montantHT: totalHT,
                        montantTVA: totalTTC - totalHT,
                        montantTTC: totalTTC,
                        fournisseurId: invoiceData.fournisseurId,
                        centreId: effectiveCentreId,
                        pieceJointeUrl: pieceJointeUrl,
                        echeances: {
                            create: [
                                {
                                    type: 'CHEQUE',
                                    dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEcheance || invoiceData.dateEmission),
                                    montant: totalTTC,
                                    statut: 'EN_ATTENTE',
                                },
                            ],
                        },
                    },
                    include: { echeances: true },
                });
                const supplier = await tx.fournisseur.findUnique({
                    where: { id: invoiceData.fournisseurId },
                });
                console.log(`🔍 [STOCK] Supplier: ${supplier?.nom}, ID: ${supplier?.id}`);
                const paymentConditions = (supplier?.convention?.echeancePaiement?.[0] ||
                    supplier?.conditionsPaiement ||
                    '').toLowerCase();
                console.log(`💳 [STOCK] Payment conditions: "${paymentConditions}"`);
                const isCashPayment = paymentConditions.includes('comptant') ||
                    paymentConditions.includes('espèces') ||
                    paymentConditions.includes('espece') ||
                    paymentConditions.includes('immédiat') ||
                    paymentConditions.includes('immediat') ||
                    paymentConditions === '';
                const isBL = invoiceData.type === 'BL';
                console.log(`💰 [STOCK] Is cash payment: ${isCashPayment}`);
                console.log(`🧾 [STOCK] Is BL: ${isBL}`);
                if (isCashPayment && !isBL) {
                    if (!effectiveCentreId) {
                        console.warn(`⚠️ [STOCK] Skipping automatic payment: Missing Centre ID for invoice ${invoiceData.numeroFacture} (and unable to infer from warehouse)`);
                    }
                    else {
                        console.log(`🚀 [STOCK] Automatic payment creation for cash supplier: ${supplier?.nom} (Centre: ${effectiveCentreId})`);
                        try {
                            const createdPayment = await tx.depense.create({
                                data: {
                                    reference: `PAY-${invoiceData.numeroFacture}`,
                                    montant: totalTTC,
                                    date: (0, date_utils_1.normalizeToUTCNoon)(invoiceData.dateEmission),
                                    categorie: 'ACHAT_STOCK',
                                    modePaiement: paymentConditions.includes('espèces') ||
                                        paymentConditions.includes('espece')
                                        ? 'ESPECES'
                                        : 'CHEQUE',
                                    fournisseurId: invoiceData.fournisseurId,
                                    factureFournisseurId: invoice.id,
                                    centreId: effectiveCentreId,
                                    statut: 'VALIDEE',
                                    description: `Paiement automatique - ${invoiceData.numeroFacture}`,
                                },
                            });
                            console.log(`✅ [STOCK] Payment created: ${createdPayment.id}, Amount: ${createdPayment.montant} DH`);
                            await tx.factureFournisseur.update({
                                where: { id: invoice.id },
                                data: { statut: 'PAYEE' },
                            });
                            if (invoice.echeances && invoice.echeances.length > 0) {
                                await tx.echeancePaiement.update({
                                    where: { id: invoice.echeances[0].id },
                                    data: { statut: 'PAYEE' },
                                });
                            }
                        }
                        catch (paymentError) {
                            console.error(`❌ [STOCK] ERROR creating payment:`, paymentError);
                        }
                    }
                }
                else {
                    console.log(`⏳ [STOCK] Deferred payment for ${supplier?.nom} - Conditions: ${paymentConditions}`);
                }
                for (const alloc of allocations) {
                    let targetProduct = await this.productsService.findLocalCounterpart({
                        designation: alloc.nom,
                        codeInterne: alloc.reference,
                        centreId: effectiveCentreId || '',
                        entrepotId: alloc.warehouseId,
                        couleur: alloc.couleur,
                    }, tx);
                    if (!targetProduct) {
                        targetProduct = await tx.product.findFirst({
                            where: {
                                OR: [
                                    { codeInterne: alloc.reference.trim() },
                                    ...(alloc.codeBarre
                                        ? [{ codeBarres: alloc.codeBarre.trim() }]
                                        : []),
                                ],
                                entrepotId: alloc.warehouseId,
                                ...(alloc.couleur ? { couleur: alloc.couleur } : {}),
                            },
                        });
                        if (targetProduct) {
                            console.log(`[STOCK] Produit existant trouvé par code/référence: ${targetProduct.designation}. Mise à jour automatique.`);
                        }
                    }
                    if (!targetProduct) {
                        const template = await tx.product.findFirst({
                            where: { designation: alloc.nom, codeInterne: alloc.reference },
                        });
                        console.log('[STOCK-DEBUG] Creating new product with alloc data:', {
                            ref: alloc.reference,
                            couleur: alloc.couleur,
                            materiau: alloc.materiau,
                            calibre: alloc.calibre,
                        });
                        targetProduct = await tx.product.create({
                            data: {
                                designation: alloc.nom,
                                marque: alloc.marque,
                                codeInterne: alloc.reference.trim(),
                                codeBarres: alloc.codeBarre?.trim() || alloc.reference.trim(),
                                typeArticle: template?.typeArticle || alloc.categorie || 'AUTRE',
                                couleur: alloc.couleur,
                                prixAchatHT: Number(alloc.prixAchat),
                                prixVenteHT: Number(alloc.prixVente),
                                prixVenteTTC: Number(alloc.prixVente) * (1 + Number(alloc.tva) / 100),
                                quantiteActuelle: 0,
                                seuilAlerte: template?.seuilAlerte || 2,
                                statut: 'DISPONIBLE',
                                entrepotId: alloc.warehouseId,
                                specificData: {
                                    ...(template?.specificData || {}),
                                    materiau: alloc.materiau,
                                    forme: alloc.forme,
                                    genre: alloc.genre,
                                    calibre: alloc.calibre,
                                    pont: alloc.pont,
                                },
                                utilisateurCreation: 'system',
                            },
                            include: { entrepot: true },
                        });
                    }
                    if (targetProduct) {
                        const existingStock = Number(targetProduct.quantiteActuelle || 0);
                        const existingPrice = Number(targetProduct.prixAchatHT || 0);
                        const newQty = Number(alloc.quantite);
                        const newPrice = Number(alloc.prixAchat);
                        let finalPrixAchatHT = newPrice;
                        if (existingStock > 0) {
                            const totalValue = existingStock * existingPrice + newQty * newPrice;
                            const totalQty = existingStock + newQty;
                            finalPrixAchatHT = totalValue / totalQty;
                        }
                        await tx.product.update({
                            where: { id: targetProduct.id },
                            data: {
                                quantiteActuelle: { increment: newQty },
                                prixAchatHT: finalPrixAchatHT,
                                prixVenteHT: Number(alloc.prixVente),
                                prixVenteTTC: Number(alloc.prixVente) * (1 + Number(alloc.tva) / 100),
                                marque: targetProduct.marque || alloc.marque,
                                typeArticle: targetProduct.typeArticle || alloc.categorie,
                                couleur: targetProduct.couleur || alloc.couleur,
                                specificData: {
                                    ...(targetProduct.specificData || {}),
                                    materiau: targetProduct.specificData?.materiau || alloc.materiau,
                                    forme: targetProduct.specificData?.forme || alloc.forme,
                                    genre: targetProduct.specificData?.genre || alloc.genre,
                                    calibre: targetProduct.specificData?.calibre || alloc.calibre,
                                    pont: targetProduct.specificData?.pont || alloc.pont,
                                },
                            },
                        });
                        await tx.mouvementStock.create({
                            data: {
                                type: 'ENTREE_ACHAT',
                                quantite: Number(alloc.quantite),
                                produitId: targetProduct.id,
                                entrepotDestinationId: alloc.warehouseId,
                                factureFournisseurId: invoice.id,
                                prixAchatUnitaire: Number(alloc.prixAchat),
                                motif: `Alimentation via ${invoice.numeroFacture}`,
                                dateMovement: new Date(),
                                utilisateur: 'system',
                            },
                        });
                    }
                }
                return invoice;
            });
        }
        catch (error) {
            console.error('[processBulkAlimentation ERROR]', error);
            try {
                const logPath = path.join(process.cwd(), 'last_error.log');
                const logMessage = `[${new Date().toISOString()}] ERROR: ${error.message}\nSTACK: ${error.stack}\nCODE: ${error.code}\nMETA: ${JSON.stringify(error.meta)}\n`;
                fs.appendFileSync(logPath, logMessage);
            }
            catch (e) { }
            if (error instanceof common_1.BadRequestException ||
                error instanceof common_1.NotFoundException) {
                throw error;
            }
            if (error.code === 'P2002') {
                const target = error.meta?.target || [];
                if (target.includes('numeroFacture')) {
                    throw new common_1.BadRequestException('Ce numéro de facture existe déjà pour ce fournisseur.');
                }
                if (target.includes('codeInterne') || target.includes('codeBarres')) {
                    throw new common_1.BadRequestException(`Un produit avec cette référence ou ce code-barres existe déjà dans cet entrepôt. Détails: ${JSON.stringify(target)}`);
                }
                throw new common_1.BadRequestException(`Erreur de contrainte unique (doublon) : ${target.join(', ')}`);
            }
            throw new common_1.BadRequestException(`Erreur lors de l'enregistrement : ${error.message}`);
        }
    }
    async getHistory(filters) {
        console.log('[STOCK-HISTORY] Filters received:', filters);
        const andConditions = [];
        if (filters.centreId &&
            filters.centreId !== 'null' &&
            filters.centreId !== 'undefined') {
            andConditions.push({
                OR: [{ centreId: filters.centreId }, { centreId: null }],
            });
        }
        if (filters.docType === 'BL') {
            andConditions.push({ type: 'BL' });
        }
        else if (filters.docType === 'FACTURE') {
            andConditions.push({
                type: {
                    in: [
                        'ACHAT_STOCK',
                        'FACTURE',
                        'ACHAT_PRODUITS',
                        'ACHAT VERRES OPTIQUES',
                        'RELEMENT_TEL_INTERNET',
                    ],
                },
            });
        }
        else {
            console.log('[STOCK-HISTORY] Using default inclusive filter');
        }
        if (filters.dateFrom || filters.dateTo) {
            const dateClause = {};
            if (filters.dateFrom && !isNaN(Date.parse(filters.dateFrom))) {
                dateClause.gte = new Date(filters.dateFrom);
            }
            if (filters.dateTo && !isNaN(Date.parse(filters.dateTo))) {
                dateClause.lte = new Date(filters.dateTo);
            }
            if (Object.keys(dateClause).length > 0) {
                andConditions.push({ dateEmission: dateClause });
            }
        }
        if (filters.supplierId &&
            filters.supplierId !== 'null' &&
            filters.supplierId !== 'undefined') {
            andConditions.push({ fournisseurId: filters.supplierId });
        }
        const whereClause = andConditions.length > 0 ? { AND: andConditions } : {};
        console.log('[STOCK-HISTORY] Query WhereClause:', JSON.stringify(whereClause, null, 2));
        return this.prisma.factureFournisseur.findMany({
            where: whereClause,
            take: 50,
            orderBy: { dateEmission: 'desc' },
            include: {
                fournisseur: true,
                mouvementsStock: {
                    include: {
                        produit: true,
                        entrepotDestination: true,
                    },
                },
            },
        });
    }
    async getOutHistory(filters) {
        const whereClause = {
            type: {
                in: [
                    'SORTIE',
                    'CASSE',
                    'AJUSTEMENT',
                    'RETOUR_FOURNISSEUR',
                    'TRANSFERT_SORTIE',
                    'TRANSFERT_ENTREE',
                    'RECEPTION',
                    'TRANSFERT_INIT',
                    'EXPEDITION',
                    'TRANSFERT_ANNULE',
                ],
            },
        };
        if (filters.centreId) {
            whereClause.OR = [
                { entrepotSource: { centreId: filters.centreId } },
                { entrepotDestination: { centreId: filters.centreId } },
                { entrepotSource: null, entrepotDestination: null },
            ];
        }
        if (filters.dateFrom || filters.dateTo) {
            whereClause.dateMovement = {};
            if (filters.dateFrom)
                whereClause.dateMovement.gte = new Date(filters.dateFrom);
            if (filters.dateTo)
                whereClause.dateMovement.lte = new Date(filters.dateTo);
        }
        if (filters.search) {
            const searchOR = [
                { motif: { contains: filters.search, mode: 'insensitive' } },
                {
                    produit: {
                        designation: { contains: filters.search, mode: 'insensitive' },
                    },
                },
                {
                    produit: {
                        codeInterne: { contains: filters.search, mode: 'insensitive' },
                    },
                },
            ];
            if (whereClause.OR) {
                whereClause.AND = [{ OR: whereClause.OR }, { OR: searchOR }];
                delete whereClause.OR;
            }
            else {
                whereClause.OR = searchOR;
            }
        }
        const movements = await this.prisma.mouvementStock.findMany({
            where: whereClause,
            take: 200,
            orderBy: { dateMovement: 'desc' },
            include: {
                produit: true,
                entrepotSource: {
                    include: { centre: true },
                },
                entrepotDestination: {
                    include: { centre: true },
                },
                facture: {
                    include: {
                        client: true,
                        fiche: true
                    },
                },
                bonLivraison: {
                    include: {
                        client: true,
                        fiche: true
                    },
                },
            },
        });
        const groups = [];
        const groupMap = new Map();
        movements.forEach((m) => {
            const date = new Date(m.dateMovement);
            const timeKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
            const key = `${m.motif}_${timeKey}`;
            if (!groupMap.has(key)) {
                const group = {
                    id: m.id,
                    motif: m.motif,
                    dateMovement: m.dateMovement,
                    utilisateur: m.utilisateur,
                    itemsCount: 0,
                    mouvementsStock: [],
                };
                groupMap.set(key, group);
                groups.push(group);
            }
            const currentGroup = groupMap.get(key);
            currentGroup.mouvementsStock.push(m);
            currentGroup.itemsCount += 1;
        });
        return groups;
    }
    async removeEntryHistory(id) {
        return await this.prisma.$transaction(async (tx) => {
            const invoice = await tx.factureFournisseur.findUnique({
                where: { id },
                include: { mouvementsStock: true },
            });
            if (!invoice)
                throw new common_1.NotFoundException('Entrée historique introuvable');
            const productIds = Array.from(new Set(invoice.mouvementsStock.map((m) => m.produitId)));
            await tx.mouvementStock.deleteMany({
                where: { factureFournisseurId: id },
            });
            for (const productId of productIds) {
                await this.productsService.syncProductState(productId, tx);
            }
            await tx.depense.deleteMany({
                where: { factureFournisseurId: id },
            });
            return await tx.factureFournisseur.delete({
                where: { id },
            });
        });
    }
    async debugData() {
        const count = await this.prisma.factureFournisseur.count();
        const movementCount = await this.prisma.mouvementStock.count();
        const recent = await this.prisma.factureFournisseur.findMany({
            take: 5,
            orderBy: { createdAt: 'desc' },
            select: { id: true, numeroFacture: true, centreId: true, type: true },
        });
        return {
            count,
            movementCount,
            recent,
        };
    }
};
exports.StockMovementsService = StockMovementsService;
exports.StockMovementsService = StockMovementsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        products_service_1.ProductsService])
], StockMovementsService);
//# sourceMappingURL=stock-movements.service.js.map