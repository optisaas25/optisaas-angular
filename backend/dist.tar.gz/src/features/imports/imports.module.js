"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportsModule = void 0;
const common_1 = require("@nestjs/common");
const imports_controller_1 = require("./imports.controller");
const imports_service_1 = require("./imports.service");
const prisma_module_1 = require("../../prisma/prisma.module");
const clients_module_1 = require("../clients/clients.module");
const products_module_1 = require("../products/products.module");
const bon_livraison_module_1 = require("../bon-livraison/bon-livraison.module");
const loyalty_module_1 = require("../loyalty/loyalty.module");
let ImportsModule = class ImportsModule {
};
exports.ImportsModule = ImportsModule;
exports.ImportsModule = ImportsModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, clients_module_1.ClientsModule, products_module_1.ProductsModule, bon_livraison_module_1.BonLivraisonModule, loyalty_module_1.LoyaltyModule],
        controllers: [imports_controller_1.ImportsController],
        providers: [imports_service_1.ImportsService],
        exports: [imports_service_1.ImportsService],
    })
], ImportsModule);
//# sourceMappingURL=imports.module.js.map