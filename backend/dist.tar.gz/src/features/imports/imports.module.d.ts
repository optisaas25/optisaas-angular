export declare class ImportsModule {
}
