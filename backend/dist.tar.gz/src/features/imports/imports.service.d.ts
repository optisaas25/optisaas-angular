import { PrismaService } from '../../prisma/prisma.service';
import { LoyaltyService } from '../loyalty/loyalty.service';
export declare class ImportsService {
    private prisma;
    private loyaltyService;
    private ioEmitterClient;
    private socketPath;
    private invoiceNumbersForChunk;
    constructor(prisma: PrismaService, loyaltyService: LoyaltyService);
    private normalizeInvoiceNum;
    private logToFile;
    private isRowEmpty;
    private isHeaderRow;
    parseFile(buffer: Buffer): Promise<{
        headers: string[];
        data: any;
        preview: any;
    }>;
    importClients(data: any[], mapping: any, centreId?: string): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    private robustParseFicheNumber;
    private parseAmount;
    private parseDate;
    private inferExpenseCategory;
    importFiches(data: any[], mapping: any, centreId?: string, importType?: string): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importProducts(data: any[], mapping: any, warehouseId: string): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importFournisseurs(data: any[], mapping: any): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importFacturesFournisseurs(data: any[], mapping: any, centreId?: string, isBLOverride?: any): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importPaiementsFournisseurs(data: any[], mapping: any): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importFacturesVentes(data: any[], mapping: any, centreId?: string): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importPaiementsClients(data: any[], mapping: any): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    importDepenses(data: any[], mapping: any, centreId?: string): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    private findOrCreateFournisseur;
    getDefaultCentreId(): Promise<string>;
    clearData(): Promise<{
        message: string;
    }>;
}
