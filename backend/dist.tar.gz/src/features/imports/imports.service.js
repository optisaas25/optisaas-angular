"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const loyalty_service_1 = require("../loyalty/loyalty.service");
const XLSX = require('xlsx');
const crypto = require('crypto');
let ImportsService = class ImportsService {
    prisma;
    loyaltyService;
    ioEmitterClient = null;
    socketPath = '/tmp/golden-cluster.sock';
    invoiceNumbersForChunk = null;
    constructor(prisma, loyaltyService) {
        this.prisma = prisma;
        this.loyaltyService = loyaltyService;
    }
    normalizeInvoiceNum(num) {
        if (num === undefined || num === null || num === '')
            return '';
        const sn = String(num).replace(/\s+/g, ' ').trim().toUpperCase();
        return sn;
    }
    logToFile(msg) {
        const fs = require('fs');
        const timestamp = new Date().toISOString();
        console.log(`[ServiceLog] ${msg}`);
        try {
            fs.appendFileSync('import_execute.log', `${timestamp} [ServiceLog] ${msg}\n`);
        }
        catch (e) {
        }
    }
    isRowEmpty(row, mapping) {
        if (!row)
            return true;
        const mappedValues = Object.values(mapping).filter((v) => v !== undefined && v !== null && v !== '');
        if (mappedValues.length === 0)
            return false;
        const hasData = mappedValues.some((csvHeader) => {
            const val = row[csvHeader];
            return val !== undefined && val !== null && String(val).trim() !== '';
        });
        return !hasData;
    }
    isHeaderRow(row, mapping, index) {
        if (!row || index > 2)
            return false;
        const synonyms = [
            'numero',
            'facture',
            'date',
            'montant',
            'client',
            'fournisseur',
            'type',
            'designation',
            'code',
            'prix',
            'ttc',
            'fourn',
            'npiece',
            'piece',
        ];
        let matches = 0;
        let totalMapped = 0;
        for (const [key, csvHeader] of Object.entries(mapping)) {
            if (!csvHeader)
                continue;
            totalMapped++;
            const val = String(row[csvHeader] || '')
                .toLowerCase()
                .trim();
            const fieldName = key.toLowerCase();
            if (val && (val === fieldName || synonyms.includes(val))) {
                matches++;
            }
        }
        return matches >= 2 && matches / totalMapped >= 0.5;
    }
    async parseFile(buffer) {
        try {
            console.log(`Parsing buffer of size: ${buffer.length}`);
            const workbook = XLSX.read(buffer, { type: 'buffer' });
            console.log('Workbook read. Sheet names:', workbook.SheetNames);
            if (workbook.SheetNames.length === 0) {
                throw new Error('No sheets found in workbook');
            }
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json(worksheet, {
                defval: '',
                cellDates: true,
            });
            console.log(`Parsed ${data.length} rows`);
            const headers = data.length > 0 ? Object.keys(data[0]) : [];
            console.log('Headers detected:', headers);
            const result = {
                headers,
                data,
                preview: data.slice(0, 5),
            };
            console.log('About to return result with keys:', Object.keys(result));
            console.log('Result.headers length:', result.headers.length);
            console.log('Result.data length:', result.data.length);
            console.log('Result.preview length:', result.preview.length);
            return result;
        }
        catch (error) {
            console.error('Parse error details:', error);
            throw new common_1.BadRequestException('Failed to parse file: ' + error.message);
        }
    }
    async importClients(data, mapping, centreId) {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        console.log(`Starting importClients with centreId: ${centreId}`);
        const phoneGroups = new Map();
        const sharedPhones = new Map();
        const phoneCounts = new Map();
        data.forEach((row) => {
            const tel = row[mapping.telephone];
            const nom = row[mapping.nom];
            const code = row[mapping.codeClient];
            if (tel && (nom || code)) {
                if (!phoneCounts.has(tel))
                    phoneCounts.set(tel, new Set());
                phoneCounts.get(tel).add(code || nom);
                sharedPhones.set(tel, nom || 'Inconnu');
            }
        });
        for (const [tel, people] of phoneCounts) {
            if (people.size > 1) {
                const familyName = sharedPhones.get(tel);
                let group = await this.prisma.groupe.findFirst({
                    where: { nom: `Famille ${familyName}` },
                });
                if (!group) {
                    group = await this.prisma.groupe.create({
                        data: {
                            nom: `Famille ${familyName}`,
                            description: `Groupe créé automatiquement par import (Tél: ${tel})`,
                            type: 'FAMILY',
                        },
                    });
                }
                phoneGroups.set(tel, group.id);
            }
        }
        const codes = new Set();
        const names = new Set();
        const phones = new Set();
        data.forEach((row) => {
            const code = row[mapping.codeClient];
            const nom = row[mapping.nom];
            const tel = row[mapping.telephone];
            if (code)
                codes.add(String(code).trim());
            if (nom)
                names.add(String(nom).trim());
            if (tel)
                phones.add(String(tel).trim());
        });
        const allExistingClients = [];
        const codesArray = Array.from(codes);
        const namesArray = Array.from(names);
        const QUERY_CHUNK_SIZE = 500;
        for (let i = 0; i < Math.max(codesArray.length, namesArray.length); i += QUERY_CHUNK_SIZE) {
            const codesChunk = codesArray.slice(i, i + QUERY_CHUNK_SIZE);
            const namesChunk = namesArray.slice(i, i + QUERY_CHUNK_SIZE);
            const chunk = await this.prisma.client.findMany({
                where: {
                    OR: [
                        { codeClient: { in: codesChunk } },
                        { nom: { in: namesChunk, mode: 'insensitive' } },
                    ],
                },
            });
            allExistingClients.push(...chunk);
        }
        const clientByCode = new Map(allExistingClients
            .filter((c) => c.codeClient)
            .map((c) => [String(c.codeClient).trim(), c]));
        const clientByNameTel = new Map(allExistingClients
            .filter((c) => c.nom && c.telephone)
            .map((c) => [
            `${String(c.nom).toLowerCase().trim()}_${String(c.telephone).trim()}`,
            c,
        ]));
        const clientsToCreate = [];
        const clientsToUpdate = [];
        for (const [index, row] of data.entries()) {
            try {
                const clientData = {
                    typeClient: 'PARTICULIER',
                    dateCreation: new Date(),
                    statut: 'ACTIF',
                    centreId: centreId,
                };
                const rowTel = row[mapping.telephone];
                if (rowTel && phoneGroups.has(rowTel)) {
                    clientData.groupeId = phoneGroups.get(rowTel);
                }
                for (const [dbField, csvHeader] of Object.entries(mapping)) {
                    if (csvHeader && row[csvHeader] !== undefined) {
                        let value = row[csvHeader];
                        if (dbField === 'dateCreation' || dbField === 'dateNaissance') {
                            const parsed = this.parseDate(value);
                            value =
                                dbField === 'dateCreation' ? parsed || new Date() : parsed;
                        }
                        else if (dbField === 'tvaAssujetti') {
                            value =
                                value === 'true' ||
                                    value === true ||
                                    value === 1 ||
                                    value === '1';
                        }
                        else if (dbField === 'pointsFidelite') {
                            value =
                                value !== null && value !== undefined
                                    ? parseInt(String(value), 10) || 0
                                    : 0;
                        }
                        else if (![
                            'couvertureSociale',
                            'numCouvertureSociale',
                            'groupeFamille',
                            'dossierMedical',
                            'contacts',
                            'convention',
                        ].includes(dbField)) {
                            value =
                                value !== null && value !== undefined
                                    ? String(value).trim() || null
                                    : null;
                        }
                        clientData[dbField] = value;
                    }
                }
                const assurance = clientData.couvertureSociale
                    ? String(clientData.couvertureSociale).trim()
                    : null;
                const numero = clientData.numCouvertureSociale
                    ? String(clientData.numCouvertureSociale).trim()
                    : null;
                if (assurance || numero) {
                    clientData.couvertureSociale = {
                        assurance: assurance || null,
                        numero: numero || null,
                    };
                }
                else {
                    clientData.couvertureSociale = null;
                }
                delete clientData.numCouvertureSociale;
                if (!clientData.raisonSociale && !clientData.identifiantFiscal) {
                    clientData.typeClient = 'particulier';
                }
                else if (clientData.raisonSociale) {
                    clientData.typeClient = 'societe';
                }
                let existingClient = null;
                if (clientData.codeClient) {
                    existingClient = clientByCode.get(String(clientData.codeClient));
                }
                else if (clientData.nom && clientData.telephone) {
                    const key = `${String(clientData.nom).toLowerCase().trim()}_${String(clientData.telephone).trim()}`;
                    existingClient = clientByNameTel.get(key);
                }
                if (existingClient) {
                    const updateData = {};
                    let hasUpdates = false;
                    if (!existingClient.centreId && centreId) {
                        updateData.centreId = centreId;
                        hasUpdates = true;
                    }
                    for (const key of Object.keys(clientData)) {
                        if ((existingClient[key] === null ||
                            existingClient[key] === '' ||
                            existingClient[key] === undefined) &&
                            clientData[key]) {
                            updateData[key] = clientData[key];
                            hasUpdates = true;
                        }
                    }
                    if (hasUpdates) {
                        clientsToUpdate.push({ id: existingClient.id, data: updateData });
                    }
                    else {
                        results.success++;
                    }
                }
                else {
                    clientsToCreate.push(clientData);
                }
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message}`);
            }
        }
        if (clientsToCreate.length > 0) {
            await this.prisma.client.createMany({
                data: clientsToCreate,
                skipDuplicates: true,
            });
            results.success += clientsToCreate.length;
        }
        if (clientsToUpdate.length > 0) {
            const UPDATE_BATCH_SIZE = 15;
            for (let i = 0; i < clientsToUpdate.length; i += UPDATE_BATCH_SIZE) {
                const batch = clientsToUpdate.slice(i, i + UPDATE_BATCH_SIZE);
                const updatePromises = batch.map((upd) => this.prisma.client
                    .update({
                    where: { id: upd.id },
                    data: upd.data,
                })
                    .then(() => {
                    results.updated++;
                    results.success++;
                })
                    .catch((err) => {
                    console.error(`Update failed for client ID ${upd.id}:`, err.message);
                    results.failed++;
                    results.errors.push(`Client ID ${upd.id}: ${err.message}`);
                }));
                await Promise.all(updatePromises);
            }
        }
        return results;
    }
    robustParseFicheNumber(val) {
        if (val === undefined || val === null || val === '')
            return null;
        const str = String(val).trim();
        if (!str)
            return null;
        const parts = str.split(/[^0-9]/).filter((p) => p.length > 0);
        if (parts.length === 0)
            return null;
        let seq = parseInt(parts[0]);
        let year = 0;
        if (parts.length > 1) {
            const p1 = parseInt(parts[0]);
            const p2 = parseInt(parts[1]);
            if (p1 >= 1900 && p1 < 2100) {
                year = p1 % 100;
                seq = p2;
            }
            else if (p2 >= 1900 && p2 < 2100) {
                year = p2 % 100;
                seq = p1;
            }
            else if (p1 >= 20 && p1 < 50 && p2 > 50) {
                year = p1;
                seq = p2;
            }
            else if (p2 >= 20 && p2 < 50) {
                year = p2;
                seq = p1;
            }
            else {
                year = p2 % 100;
                seq = p1;
            }
        }
        if (year > 0) {
            return year * 1000000 + (seq % 1000000);
        }
        return seq;
    }
    parseAmount(v) {
        if (v === undefined || v === null || v === '')
            return 0;
        if (typeof v === 'number')
            return v;
        const s = String(v)
            .replace(/\s/g, '')
            .replace(',', '.')
            .replace(/[^0-9.-]/g, '');
        const val = parseFloat(s);
        return isNaN(val) ? 0 : val;
    }
    parseDate(v) {
        if (v === undefined ||
            v === null ||
            String(v).trim() === '' ||
            v === 0 ||
            v === '0')
            return null;
        let val = v;
        if (typeof v === 'string' && /^\d+(\.\d+)?$/.test(v)) {
            val = parseFloat(v);
        }
        if (typeof val === 'number' && val > 0 && val < 60000) {
            const d = new Date(Math.round((val - 25569) * 86400 * 1000));
            if (d.getFullYear() < 1980)
                return null;
            return d;
        }
        const d = new Date(v);
        if (!isNaN(d.getTime())) {
            if (d.getFullYear() <= 1970 && typeof v === 'number' && v > 0) {
                const corrected = new Date(Math.round((v - 25569) * 86400 * 1000));
                if (corrected.getFullYear() < 1980)
                    return null;
                return corrected;
            }
            if (d.getFullYear() < 1980)
                return null;
            return d;
        }
        if (typeof v === 'string') {
            const parts = v.split(/[-/]/);
            if (parts.length === 3) {
                let day, month, year;
                if (parts[0].length === 4) {
                    year = parseInt(parts[0], 10);
                    month = parseInt(parts[1], 10) - 1;
                    day = parseInt(parts[2], 10);
                }
                else {
                    day = parseInt(parts[0], 10);
                    month = parseInt(parts[1], 10) - 1;
                    year = parseInt(parts[2], 10);
                }
                if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                    const pd = new Date(year, month, day);
                    if (!isNaN(pd.getTime()) && pd.getFullYear() >= 1980)
                        return pd;
                }
            }
        }
        return null;
    }
    inferExpenseCategory(description) {
        const desc = description.toLowerCase();
        if (desc.includes('salaire') ||
            desc.includes('salary') ||
            desc.includes('paie')) {
            return 'SALAIRE';
        }
        if (desc.includes('cnss') || desc.includes('securite sociale')) {
            return 'CHARGES_SOCIALES';
        }
        if (desc.includes('amo') ||
            desc.includes('assurance maladie') ||
            desc.includes('mutuelle')) {
            return 'ASSURANCE';
        }
        if (desc.includes('loyer') || desc.includes('rent')) {
            return 'LOYER';
        }
        if (desc.includes('electricite') ||
            desc.includes('eau') ||
            desc.includes('internet') ||
            desc.includes('telephone')) {
            return 'CHARGES_FIXES';
        }
        return 'AUTRE_DEPENSE';
    }
    async importFiches(data, mapping, centreId, importType = 'fiches') {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        const log = (msg) => {
            const now = new Date();
            console.log(`[${now.toISOString().split('T')[1].split('.')[0]}] 📄 ${msg}`);
        };
        const fichesToCreate = [];
        const facturesToCreate = [];
        const parseNum = (v) => {
            if (v === undefined || v === null || v === '')
                return undefined;
            const raw = String(v).trim();
            const digitCount = (raw.match(/\d/g) || []).length;
            const alphaCount = (raw.match(/[a-zA-Z]/g) || []).length;
            if (alphaCount > 2 || digitCount === 0)
                return undefined;
            const val = raw.replace(',', '.').replace(/[^-0-9.]/g, '');
            const n = parseFloat(val);
            return isNaN(n) ? undefined : n;
        };
        const parseDate = (v) => this.parseDate(v);
        try {
            const codes = new Set();
            const names = new Set();
            const phones = new Set();
            data.forEach((row) => {
                const code = row[mapping.codeClient];
                if (code)
                    codes.add(String(code));
                const name = row[mapping.nom];
                const phone = row[mapping.telephone];
                if (name)
                    names.add(String(name));
                if (phone)
                    phones.add(String(phone));
            });
            log(`Searching for clients in batch... (${codes.size} codes, ${names.size} names)`);
            const allClients = [];
            const codesArray = Array.from(codes);
            const namesArray = Array.from(names);
            const phonesArray = Array.from(phones);
            const QUERY_CHUNK_SIZE = 500;
            for (let i = 0; i < Math.max(codesArray.length, namesArray.length); i += QUERY_CHUNK_SIZE) {
                const codesChunk = codesArray.slice(i, i + QUERY_CHUNK_SIZE);
                const namesChunk = namesArray.slice(i, i + QUERY_CHUNK_SIZE);
                const phonesChunk = phonesArray.slice(i, i + QUERY_CHUNK_SIZE);
                const chunkClients = await this.prisma.client.findMany({
                    where: {
                        OR: [
                            { codeClient: { in: codesChunk } },
                            {
                                AND: [
                                    { nom: { in: namesChunk, mode: 'insensitive' } },
                                    { telephone: { in: phonesChunk } },
                                ],
                            },
                        ],
                    },
                    select: { id: true, codeClient: true, nom: true, telephone: true },
                });
                allClients.push(...chunkClients);
            }
            log(`Found ${allClients.length} potential client matches for this batch`);
            const codeMap = new Map();
            const identityMap = new Map();
            allClients.forEach((c) => {
                if (c.codeClient)
                    codeMap.set(String(c.codeClient).trim(), c.id);
                if (c.nom && c.telephone) {
                    const key = `${String(c.nom).toLowerCase().trim()}_${String(c.telephone).trim()}`;
                    identityMap.set(key, c.id);
                }
            });
            const missingClients = [];
            const processedCodes = new Set(codeMap.keys());
            const processedIdentities = new Set(identityMap.keys());
            const processedNames = new Set();
            data.forEach((row, idx) => {
                const mappedRow = {};
                for (const k of Object.keys(mapping)) {
                    if (mapping[k])
                        mappedRow[k] = row[mapping[k]];
                }
                const code = mappedRow.codeClient ? String(mappedRow.codeClient) : null;
                const nom = mappedRow.nom
                    ? String(mappedRow.nom).toLowerCase().trim()
                    : '';
                const tel = mappedRow.telephone
                    ? String(mappedRow.telephone).trim()
                    : '';
                const identKey = nom && tel ? `${nom}_${tel}` : null;
                let isMissing = false;
                if (code && !processedCodes.has(code)) {
                    isMissing = true;
                    processedCodes.add(code);
                }
                else if (!code && identKey && !processedIdentities.has(identKey)) {
                    isMissing = true;
                    processedIdentities.add(identKey);
                }
                else if (!code && !identKey && nom && !processedNames.has(nom)) {
                    isMissing = true;
                    processedNames.add(nom);
                }
                else if (!code &&
                    !identKey &&
                    !nom &&
                    tel &&
                    !processedNames.has(`tel_${tel} `)) {
                    isMissing = true;
                    processedNames.add(`tel_${tel} `);
                }
                if (isMissing) {
                    const clientTmpId = crypto.randomUUID();
                    if (code)
                        codeMap.set(code, clientTmpId);
                    if (identKey)
                        identityMap.set(identKey, clientTmpId);
                    if (nom && !identKey) {
                        const fallbackKey = `name_${nom}`;
                        if (!identityMap.has(fallbackKey))
                            identityMap.set(fallbackKey, clientTmpId);
                    }
                    const clientData = {
                        codeClient: code || null,
                        nom: typeof mappedRow.nom === 'string' && mappedRow.nom.trim()
                            ? mappedRow.nom.trim()
                            : tel
                                ? `Client Tel ${tel} `
                                : code
                                    ? `Client ${code} `
                                    : 'Client Inconnu',
                        prenom: typeof mappedRow.prenom === 'string' && mappedRow.prenom.trim()
                            ? mappedRow.prenom.trim()
                            : typeof mappedRow.prenom === 'number'
                                ? String(mappedRow.prenom)
                                : null,
                        telephone: tel || null,
                        email: typeof mappedRow.email === 'string' && mappedRow.email.trim()
                            ? mappedRow.email.trim()
                            : null,
                        adresse: typeof mappedRow.adresse === 'string' && mappedRow.adresse.trim()
                            ? mappedRow.adresse.trim()
                            : null,
                        ville: typeof mappedRow.ville === 'string' && mappedRow.ville.trim()
                            ? mappedRow.ville.trim()
                            : null,
                        codePostal: typeof mappedRow.codePostal === 'string' &&
                            mappedRow.codePostal.trim()
                            ? mappedRow.codePostal.trim()
                            : typeof mappedRow.codePostal === 'number'
                                ? String(mappedRow.codePostal)
                                : null,
                        dateNaissance: parseDate(mappedRow.dateNaissance),
                        dateCreation: parseDate(mappedRow.dateCreation) || new Date(),
                        typeClient: 'PHYSIQUE',
                        statut: 'ACTIF',
                        centreId: centreId || null,
                    };
                    const assuranceIns = mappedRow.couvertureSociale
                        ? String(mappedRow.couvertureSociale).trim()
                        : null;
                    const numeroIns = mappedRow.numCouvertureSociale
                        ? String(mappedRow.numCouvertureSociale).trim()
                        : null;
                    if (assuranceIns || numeroIns) {
                        clientData.couvertureSociale = {
                            assurance: assuranceIns || null,
                            numero: numeroIns || null,
                        };
                    }
                    else {
                        clientData.couvertureSociale = null;
                    }
                    missingClients.push(clientData);
                }
            });
            if (missingClients.length > 0) {
                log(`⚡ Aggressive Auto - creating ${missingClients.length} missing clients...`);
                await this.prisma.client.createMany({
                    data: missingClients,
                    skipDuplicates: true,
                });
                const newClients = [];
                const procCodesArray = Array.from(processedCodes);
                const namesArrayRefetch = Array.from(names);
                const phonesArrayRefetch = Array.from(phones);
                for (let i = 0; i < Math.max(procCodesArray.length, namesArrayRefetch.length); i += QUERY_CHUNK_SIZE) {
                    const codesChunk = procCodesArray.slice(i, i + QUERY_CHUNK_SIZE);
                    const namesChunk = namesArrayRefetch.slice(i, i + QUERY_CHUNK_SIZE);
                    const phonesChunk = phonesArrayRefetch.slice(i, i + QUERY_CHUNK_SIZE);
                    const clientsChunk = await this.prisma.client.findMany({
                        where: {
                            OR: [
                                { codeClient: { in: codesChunk } },
                                {
                                    AND: [
                                        { nom: { in: namesChunk } },
                                        { telephone: { in: phonesChunk } },
                                    ],
                                },
                                { nom: { in: namesChunk } },
                                { telephone: { in: phonesChunk } },
                            ],
                        },
                        select: { id: true, codeClient: true, nom: true, telephone: true },
                    });
                    newClients.push(...clientsChunk);
                }
                newClients.forEach((c) => {
                    if (c.codeClient)
                        codeMap.set(String(c.codeClient).trim(), c.id);
                    if (c.nom && c.telephone) {
                        const key = `${String(c.nom).toLowerCase().trim()}_${String(c.telephone).trim()}`;
                        identityMap.set(key, c.id);
                    }
                    if (c.nom) {
                        const nameKey = String(c.nom).toLowerCase().trim();
                        if (!identityMap.has(nameKey))
                            identityMap.set(nameKey, c.id);
                    }
                    if (c.telephone) {
                        const telKey = `tel_${String(c.telephone).trim()}`;
                        if (!identityMap.has(telKey))
                            identityMap.set(telKey, c.id);
                    }
                });
            }
            const groupedFiches = new Map();
            data.forEach((row, idx) => {
                const fid = row[mapping.fiche_id] ||
                    row[mapping.numero] ||
                    row['Fiche'] ||
                    row['fiche'] ||
                    null;
                const dateVal = row[mapping.dateCreation] || row[mapping.date_ordonnance];
                let dateStr = 'nodate';
                if (dateVal) {
                    const d = new Date(dateVal);
                    if (!isNaN(d.getTime())) {
                        dateStr = d.toISOString().split('T')[0];
                    }
                }
                let key = '';
                if (fid && fid !== '0' && fid !== 0) {
                    key = `FID_${fid}`;
                }
                else {
                    key = `UNIQUE_${idx}`;
                }
                if (!groupedFiches.has(key))
                    groupedFiches.set(key, []);
                groupedFiches.get(key).push(row);
            });
            log(`Grouped ${data.length} rows into ${groupedFiches.size} unique fiches`);
            log(`Pre-fetching existing Fiches to avoid N+1 latency...`);
            const ficheQueries = [];
            const ficheLookupMap = new Map();
            for (const [key, rows] of groupedFiches) {
                const firstRow = rows[0];
                const sharedMapped = {};
                for (const k of Object.keys(mapping)) {
                    if (mapping[k])
                        sharedMapped[k] = firstRow[mapping[k]];
                }
                let cId = null;
                if (sharedMapped.codeClient) {
                    cId = codeMap.get(String(sharedMapped.codeClient));
                }
                else if (sharedMapped.nom || sharedMapped.telephone) {
                    const nomStr = sharedMapped.nom
                        ? String(sharedMapped.nom).toLowerCase().trim()
                        : '';
                    const telStr = sharedMapped.telephone
                        ? String(sharedMapped.telephone).trim()
                        : '';
                    const identKey = nomStr && telStr
                        ? `${nomStr}_${telStr}`
                        : nomStr || `tel_${telStr}`;
                    cId = identityMap.get(identKey);
                }
                const pm = {};
                rows.forEach((r) => {
                    for (const k of Object.keys(mapping)) {
                        if (mapping[k] !== undefined && mapping[k] !== null) {
                            let v = r[mapping[k]];
                            if (typeof v === 'string' && !v.trim())
                                v = '';
                            if (v !== undefined &&
                                v !== null &&
                                v !== '' &&
                                (pm[k] === undefined || pm[k] === null || pm[k] === '')) {
                                pm[k] = v;
                            }
                        }
                    }
                });
                const rawFNum = pm.fiche_id || pm.numero || pm.numero_fiche;
                const fNumInt = rawFNum
                    ? parseInt(String(rawFNum).split(/[^0-9]/)[0], 10)
                    : NaN;
                if (cId && !isNaN(fNumInt)) {
                    ficheQueries.push({ clientId: cId, numero: fNumInt });
                }
            }
            if (ficheQueries.length > 0) {
                log(`Executing pre-fetch query for ${ficheQueries.length} possible existing Fiches...`);
                const chunkSize = 1500;
                for (let i = 0; i < ficheQueries.length; i += chunkSize) {
                    const chunk = ficheQueries.slice(i, i + chunkSize);
                    const existing = await this.prisma.fiche.findMany({
                        where: { OR: chunk },
                        select: { id: true, numero: true, clientId: true },
                    });
                    existing.forEach((ex) => ficheLookupMap.set(`${ex.clientId}_${String(ex.numero).trim()}`, ex));
                }
                log(`Found ${ficheLookupMap.size} existing Fiches in the database.`);
            }
            let groupIndex = 0;
            for (const [key, rows] of groupedFiches) {
                try {
                    const firstRow = rows[0];
                    const sharedMapped = {};
                    for (const k of Object.keys(mapping)) {
                        if (mapping[k])
                            sharedMapped[k] = firstRow[mapping[k]];
                    }
                    let clientId = null;
                    if (sharedMapped.codeClient) {
                        clientId = codeMap.get(String(sharedMapped.codeClient));
                    }
                    else if (sharedMapped.nom || sharedMapped.telephone) {
                        const nomStr = sharedMapped.nom
                            ? String(sharedMapped.nom).toLowerCase().trim()
                            : '';
                        const telStr = sharedMapped.telephone
                            ? String(sharedMapped.telephone).trim()
                            : '';
                        const identKey = nomStr && telStr
                            ? `${nomStr}_${telStr}`
                            : nomStr || `tel_${telStr}`;
                        clientId = identityMap.get(identKey);
                    }
                    if (!clientId) {
                        log(`Skipping group ${key}: No client found(code: ${sharedMapped.codeClient}, nom: ${sharedMapped.nom}, tel: ${sharedMapped.telephone})`);
                        results.skipped += rows.length;
                        continue;
                    }
                    const pm = {};
                    rows.forEach((row) => {
                        for (const k of Object.keys(mapping)) {
                            if (mapping[k]) {
                                let val = row[mapping[k]];
                                if (typeof val === 'string' && !val.trim())
                                    val = '';
                                if (val !== undefined && val !== null && val !== '') {
                                    if (pm[k] === undefined || pm[k] === null || pm[k] === '') {
                                        pm[k] = val;
                                    }
                                }
                            }
                        }
                    });
                    let finalType = 'produit';
                    let hasMontureData = false;
                    let hasLentilleData = false;
                    const explicitType = pm.fiche_type
                        ? String(pm.fiche_type).trim().toUpperCase()
                        : null;
                    hasMontureData = !!(pm.monture_marque ||
                        pm.monture_reference ||
                        pm.verres_type ||
                        pm.verres_prix_od ||
                        pm.verres_prix_og ||
                        pm.verres_marque ||
                        pm.verres_matiere);
                    hasLentilleData = !!(pm.lentilles_marque ||
                        pm.od_rayon ||
                        pm.og_rayon ||
                        pm.lentilles_marque_od ||
                        pm.lentilles_marque_og ||
                        pm.lentilles_prix ||
                        pm.lentilles_usage);
                    const hasPrescription = !!(pm.od_sphere ||
                        pm.og_sphere ||
                        pm.od_cylindre ||
                        pm.og_cylindre);
                    if (explicitType === 'M') {
                        finalType = 'monture';
                    }
                    else if (explicitType === 'L') {
                        finalType = 'lentilles';
                    }
                    else {
                        if (hasLentilleData)
                            finalType = 'lentilles';
                        else if (hasMontureData || hasPrescription)
                            finalType = 'monture';
                    }
                    if (explicitType === 'M')
                        hasMontureData = true;
                    if (explicitType === 'L')
                        hasLentilleData = true;
                    groupIndex++;
                    const content = {
                        ordonnance: {
                            od: {
                                sphere: parseNum(pm.od_sphere),
                                cylindre: parseNum(pm.od_cylindre),
                                axe: parseNum(pm.od_axe),
                                addition: parseNum(pm.od_addition),
                                k1: parseNum(pm.od_k1),
                                k2: parseNum(pm.od_k2),
                            },
                            og: {
                                sphere: parseNum(pm.og_sphere),
                                cylindre: parseNum(pm.og_cylindre),
                                axe: parseNum(pm.og_axe),
                                addition: parseNum(pm.og_addition),
                                k1: parseNum(pm.og_k1),
                                k2: parseNum(pm.og_k2),
                            },
                            epOD: parseNum(pm.ep_od),
                            epOG: parseNum(pm.ep_og),
                            dateOrdonnance: parseDate(pm.date_ordonnance),
                            nomMedecin: pm.nom_medecin,
                        },
                        equipements: [],
                        notes: pm.notes,
                        fournisseur: pm.fournisseur,
                        factureFournisseur: pm.facture_fournisseur,
                        dateLivraisonEstimee: parseDate(pm.dateLivraisonEstimee),
                    };
                    if (hasMontureData) {
                        content.monture = {
                            marque: pm.monture_marque,
                            modele: pm.monture_modele,
                            reference: pm.monture_reference,
                            prixMonture: parseNum(pm.monture_prix) || 0,
                        };
                        content.verres = {
                            type: pm.verres_type || 'Unifocal',
                            indice: pm.verres_indice,
                            matiere: pm.verres_matiere,
                            marque: pm.verres_marque,
                            traitement: pm.verres_traitement ? [pm.verres_traitement] : [],
                            prixOD: parseNum(pm.verres_prix_od) || 0,
                            prixOG: parseNum(pm.verres_prix_og) || 0,
                            matiereOD: pm.verres_matiere_od || pm.verres_matiere,
                            matiereOG: pm.verres_matiere_og || pm.verres_matiere,
                            indiceOD: pm.verres_indice_od || pm.verres_indice,
                            indiceOG: pm.verres_indice_og || pm.verres_indice,
                            differentODOG: !!(pm.og_sphere ||
                                pm.og_cylindre ||
                                pm.og_axe ||
                                pm.verres_prix_og ||
                                (pm.verres_matiere_od &&
                                    pm.verres_matiere_og &&
                                    pm.verres_matiere_od !== pm.verres_matiere_og) ||
                                (pm.verres_indice_od &&
                                    pm.verres_indice_og &&
                                    pm.verres_indice_od !== pm.verres_indice_og)),
                        };
                    }
                    if (hasLentilleData) {
                        content.lentilles = {
                            type: pm.lentilles_usage || 'Mensuelle',
                            diffLentilles: !!(pm.og_rayon ||
                                pm.og_diametre ||
                                pm.og_sphere ||
                                pm.og_cylindre ||
                                pm.og_axe ||
                                (pm.lentilles_marque_od &&
                                    pm.lentilles_marque_og &&
                                    pm.lentilles_marque_od !== pm.lentilles_marque_og)),
                            od: {
                                marque: pm.lentilles_marque_od || pm.lentilles_marque,
                                modele: pm.lentilles_modele_od || pm.lentilles_modele,
                                rayon: parseNum(pm.od_rayon),
                                diametre: parseNum(pm.od_diametre),
                                sphere: parseNum(pm.od_sphere),
                                cylindre: parseNum(pm.od_cylindre),
                                axe: parseNum(pm.od_axe),
                                prix: parseNum(pm.lentilles_prix) || 0,
                                quantite: parseNum(pm.lentilles_qte) || 1,
                            },
                            og: {
                                marque: pm.lentilles_marque_og || pm.lentilles_marque,
                                modele: pm.lentilles_modele_og || pm.lentilles_modele,
                                rayon: parseNum(pm.og_rayon),
                                diametre: parseNum(pm.og_diametre),
                                sphere: parseNum(pm.og_sphere),
                                cylindre: parseNum(pm.og_cylindre),
                                axe: parseNum(pm.og_axe),
                                prix: parseNum(pm.lentilles_prix) || 0,
                                quantite: parseNum(pm.lentilles_qte) || 1,
                            },
                        };
                    }
                    const addedProductsRefs = new Set();
                    rows.forEach((row, rowIndex) => {
                        const m = {};
                        for (const k of Object.keys(mapping))
                            if (mapping[k])
                                m[k] = row[mapping[k]];
                        const addProd = (ref, desc, qte, prix) => {
                            if ((ref || desc) && !addedProductsRefs.has(ref + desc)) {
                                if (!content.produits)
                                    content.produits = [];
                                content.produits.push({
                                    reference: String(ref || ''),
                                    designation: String(desc || ''),
                                    quantite: parseNum(qte) || 1,
                                    prixUnitaire: parseNum(prix) || 0,
                                    prixTotal: (parseNum(qte) || 1) * (parseNum(prix) || 0),
                                });
                                addedProductsRefs.add(ref + desc);
                            }
                        };
                        addProd(m.produit_ref, m.produit_designation, m.produit_qte, m.produit_prix);
                        addProd(m.produit2_ref, m.produit2_designation, m.produit2_qte, m.produit2_prix);
                        const createEquip = (mtType, mtData, vrData) => ({
                            type: mtType || 'Monture',
                            dateAjout: new Date(),
                            monture: {
                                marque: mtData.marque,
                                modele: mtData.modele,
                                reference: mtData.reference || 'Equipement Extra',
                                prixMonture: parseNum(mtData.prix) || 0,
                            },
                            verres: {
                                type: 'Unifocal',
                                marque: vrData.marque,
                                prixOD: parseNum(vrData.prix_od) || 0,
                                prixOG: parseNum(vrData.prix_og) || parseNum(vrData.prix_od) || 0,
                            },
                        });
                        if (rowIndex > 0) {
                            const hasPrimaryData = m.monture_marque ||
                                m.monture_reference ||
                                m.verres_marque ||
                                m.verres_prix_od ||
                                m.lentilles_marque ||
                                m.lentilles_prix ||
                                m.od_rayon;
                            if (hasPrimaryData) {
                                const isMainMontureEmpty = !content.monture?.marque ||
                                    content.monture?.marque === 'CLIENT';
                                const isMainVerresEmpty = !content.verres?.marque;
                                const isMainLentillesEmpty = !content.lentilles?.od?.marque &&
                                    !content.lentilles?.og?.marque;
                                if (isMainMontureEmpty &&
                                    m.monture_marque &&
                                    m.monture_marque !== 'CLIENT') {
                                    if (!content.monture)
                                        content.monture = {};
                                    content.monture.marque = m.monture_marque;
                                    content.monture.modele =
                                        m.monture_modele || content.monture.modele;
                                    content.monture.reference =
                                        m.monture_reference || content.monture.reference;
                                    content.monture.prixMonture =
                                        parseNum(m.monture_prix) || content.monture.prixMonture;
                                    console.log(`MERGED Subsequent Row ${rowIndex} Monture into Main: ${m.monture_marque} `);
                                }
                                else if (isMainVerresEmpty && m.verres_marque) {
                                    if (!content.verres)
                                        content.verres = { type: 'Unifocal' };
                                    content.verres.marque = m.verres_marque;
                                    content.verres.prixOD =
                                        parseNum(m.verres_prix_od) || content.verres.prixOD;
                                    content.verres.prixOG =
                                        parseNum(m.verres_prix_og) ||
                                            parseNum(m.verres_prix_od) ||
                                            content.verres.prixOG;
                                    console.log(`MERGED Subsequent Row ${rowIndex} Verres into Main: ${m.verres_marque} `);
                                }
                                else if (isMainLentillesEmpty &&
                                    (m.lentilles_marque ||
                                        m.lentilles_marque_od ||
                                        m.lentilles_marque_og)) {
                                    if (!content.lentilles) {
                                        content.lentilles = {
                                            type: m.lentilles_usage || 'Mensuelle',
                                            od: {},
                                            og: {},
                                        };
                                    }
                                    content.lentilles.od.marque =
                                        m.lentilles_marque_od ||
                                            m.lentilles_marque ||
                                            content.lentilles.od.marque;
                                    content.lentilles.og.marque =
                                        m.lentilles_marque_og ||
                                            m.lentilles_marque ||
                                            content.lentilles.og.marque;
                                    content.lentilles.od.prix =
                                        parseNum(m.lentilles_prix) || content.lentilles.od.prix;
                                    content.lentilles.og.prix =
                                        parseNum(m.lentilles_prix) || content.lentilles.og.prix;
                                    console.log(`MERGED Subsequent Row ${rowIndex} Lentilles into Main`);
                                }
                                else {
                                    content.equipements.push(createEquip('Monture', {
                                        marque: m.monture_marque,
                                        modele: m.monture_modele,
                                        reference: m.monture_reference,
                                        prix: m.monture_prix,
                                    }, {
                                        marque: m.verres_marque,
                                        prix_od: m.verres_prix_od,
                                        prix_og: m.verres_prix_og,
                                    }));
                                }
                            }
                        }
                        else {
                            const v_od = m.verres_prix_od;
                            const v_og = m.verres_prix_og;
                            const m_prix = m.monture_prix;
                            const l_prix = m.lentilles_prix;
                            const v_od_n = parseNum(v_od) || 0;
                            const v_og_n = parseNum(v_og) || 0;
                            const m_prix_n = parseNum(m_prix) || 0;
                            const l_prix_n = parseNum(l_prix) || 0;
                            if (content.verres && content.verres.prixOD === 0 && v_od_n > 0) {
                                content.verres.prixOD = v_od_n;
                            }
                            if (content.verres &&
                                content.verres.prixOG === 0 &&
                                (v_og_n > 0 || v_od_n > 0)) {
                                content.verres.prixOG = v_og_n || v_od_n;
                            }
                            if (content.monture &&
                                (content.monture.prixMonture === 0 ||
                                    !content.monture.prixMonture) &&
                                m_prix_n > 0) {
                                content.monture.prixMonture = m_prix_n;
                            }
                            if (content.lentilles &&
                                content.lentilles.od &&
                                (content.lentilles.od.prix === 0 ||
                                    !content.lentilles.od.prix) &&
                                l_prix_n > 0) {
                                content.lentilles.od.prix = l_prix_n;
                                if (content.lentilles.og)
                                    content.lentilles.og.prix = l_prix_n;
                            }
                        }
                        if (m.monture2_marque ||
                            m.monture2_reference ||
                            m.verres2_marque ||
                            m.verres2_prix_od) {
                            const matchesMain = m.monture2_marque === content.monture?.marque &&
                                m.monture2_reference === content.monture?.reference;
                            if (!matchesMain) {
                                content.equipements.push(createEquip('Monture', {
                                    marque: m.monture2_marque,
                                    modele: m.monture2_modele,
                                    reference: m.monture2_reference || 'Equipement 2',
                                    prix: m.monture2_prix,
                                }, {
                                    marque: m.verres2_marque,
                                    prix_od: m.verres2_prix_od,
                                    prix_og: m.verres2_prix_og,
                                }));
                            }
                            else {
                                if (content.monture &&
                                    content.monture.prixMonture === 0 &&
                                    m.monture2_prix) {
                                    content.monture.prixMonture = parseNum(m.monture2_prix) || 0;
                                }
                            }
                        }
                    });
                    const totalPaye = rows.reduce((sum, r) => sum + (parseNum(r[mapping.montantPaye]) || 0), 0);
                    const totalAmount = parseNum(pm.montantTotal) || 0;
                    const rawValide = String(pm.valide ?? '').toLowerCase().trim();
                    const rawFacture = String(pm.facture ?? '').toLowerCase().trim();
                    const isFauxValide = ['faux', 'false', 'non', 'no', '0'].includes(rawValide) || pm.valide === false;
                    const isValide = !isFauxValide;
                    const isFacture = ['vrai', 'true', 'oui', 'yes', '1'].includes(rawFacture) || pm.facture === true;
                    const hasInvoiceNum = !!(pm.numero || pm.fiche_id || pm.numero_fiche);
                    let docType = 'DEVIS';
                    let docStatut = 'BROUILLON';
                    let finalPrefix = '';
                    if (isValide) {
                        if (isFacture) {
                            docType = 'FACTURE';
                            docStatut = 'VALIDE';
                            finalPrefix = 'Fact-';
                        }
                        else {
                            docType = 'BON_COMMANDE';
                            docStatut = 'VENTE_EN_INSTANCE';
                            finalPrefix = 'BC-';
                        }
                    }
                    const shouldCreateInvoice = isValide;
                    const ficheId = crypto.randomUUID();
                    if (!this.invoiceNumbersForChunk) {
                        this.invoiceNumbersForChunk = new Set();
                    }
                    const ficheNumero = this.robustParseFicheNumber(pm.numero || pm.fiche_id || pm.numero_fiche);
                    const ficheObject = {
                        id: ficheId,
                        clientId: clientId,
                        type: finalType,
                        statut: String(pm.statut || 'livre').toLowerCase(),
                        dateCreation: parseDate(pm.dateCreation) || new Date(),
                        montantTotal: totalAmount,
                        montantPaye: totalPaye,
                        content: content,
                    };
                    if (ficheNumero) {
                        ficheObject.numero = ficheNumero;
                    }
                    let existingFiche = null;
                    if (ficheNumero && clientId) {
                        existingFiche = ficheLookupMap.get(`${clientId}_${String(ficheNumero).trim()}`);
                    }
                    if (existingFiche) {
                        ficheObject.id = existingFiche.id;
                        results.updated++;
                    }
                    else {
                        fichesToCreate.push(ficheObject);
                        if (ficheNumero && clientId) {
                            ficheLookupMap.set(`${clientId}_${String(ficheNumero).trim()}`, ficheObject);
                        }
                    }
                    if (shouldCreateInvoice) {
                        const factureId = crypto.randomUUID();
                        let invoiceNumero = pm.numero
                            ? String(pm.numero)
                            : pm.fiche_id
                                ? String(pm.fiche_id)
                                : pm.numero_fiche
                                    ? String(pm.numero_fiche)
                                    : null;
                        if (!invoiceNumero ||
                            invoiceNumero === 'nofid' ||
                            invoiceNumero === 'null' ||
                            invoiceNumero === 'undefined') {
                            invoiceNumero = `IMP-${docType}-${Date.now()}-${groupIndex}`;
                        }
                        else {
                            let cleanNum = String(invoiceNumero).trim();
                            if (docType !== 'DEVIS' && !cleanNum.startsWith(finalPrefix)) {
                                invoiceNumero = `${finalPrefix}${cleanNum}`;
                            }
                            else {
                                invoiceNumero = cleanNum;
                            }
                        }
                        const resteAPayer = Math.max(0, totalAmount - totalPaye);
                        const finalStatut = resteAPayer <= 0 && docType === 'FACTURE' ? 'PAYEE' : docStatut;
                        if (!this.invoiceNumbersForChunk.has(invoiceNumero)) {
                            this.invoiceNumbersForChunk.add(invoiceNumero);
                            facturesToCreate.push({
                                id: factureId,
                                numero: invoiceNumero,
                                type: docType,
                                statut: finalStatut,
                                clientId: clientId,
                                ficheId: ficheObject.id,
                                centreId: centreId || null,
                                dateEmission: parseDate(pm.dateCreation) || new Date(),
                                totalHT: totalAmount / 1.2,
                                totalTVA: totalAmount - totalAmount / 1.2,
                                totalTTC: totalAmount,
                                resteAPayer: resteAPayer,
                                _acompte: totalPaye,
                                lignes: (() => {
                                    const lines = [];
                                    const addLine = (desc, qte, price, typeArticle) => {
                                        if (price > 0 || desc) {
                                            lines.push({
                                                description: desc || 'Article',
                                                qte: qte || 1,
                                                prixUnitaireTTC: price || 0,
                                                remise: 0,
                                                totalTTC: (qte || 1) * (price || 0),
                                                ...(typeArticle ? { typeArticle } : {}),
                                            });
                                        }
                                    };
                                    if (content.monture && content.monture.marque) {
                                        const desc = `Monture ${content.monture.marque} ${content.monture.reference || ''}`.trim();
                                        addLine(desc, 1, content.monture.prixMonture, 'MONTURE');
                                    }
                                    if (content.verres) {
                                        const prixVerres = (content.verres.prixOD || 0) + (content.verres.prixOG || 0);
                                        if (prixVerres > 0 || content.verres.marque) {
                                            const desc = `Verres ${content.verres.type} ${content.verres.marque || ''}`.trim();
                                            addLine(desc, 1, prixVerres, 'VERRE');
                                        }
                                    }
                                    if (content.lentilles) {
                                        const prixLentilles = (content.lentilles.od?.prix || 0) +
                                            (content.lentilles.og?.prix || 0);
                                        if (prixLentilles > 0 ||
                                            content.lentilles.od?.marque ||
                                            content.lentilles.og?.marque) {
                                            addLine('Lentilles de contact', 1, prixLentilles, 'LENTILLES');
                                        }
                                    }
                                    if (content.produits && Array.isArray(content.produits)) {
                                        content.produits.forEach((p) => {
                                            addLine(p.designation, p.quantite, p.prixUnitaire, 'ACCESSOIRE');
                                        });
                                    }
                                    if (content.equipements && Array.isArray(content.equipements)) {
                                        content.equipements.forEach((eq, idx) => {
                                            if (eq.monture) {
                                                const desc = `Equipement ${idx + 2} - Monture ${eq.monture.marque || ''}`.trim();
                                                addLine(desc, 1, eq.monture.prixMonture, 'MONTURE');
                                            }
                                            if (eq.verres) {
                                                const prixV = (eq.verres.prixOD || 0) + (eq.verres.prixOG || 0);
                                                const desc = `Equipement ${idx + 2} - Verres ${eq.verres.marque || ''}`.trim();
                                                addLine(desc, 1, prixV, 'VERRE');
                                            }
                                        });
                                    }
                                    const currentTotal = lines.reduce((acc, l) => acc + l.totalTTC, 0);
                                    if (lines.length === 0 && totalAmount > 0) {
                                        addLine('Import Global - Détail manquant', 1, totalAmount);
                                    }
                                    return lines;
                                })(),
                                proprietes: {},
                            });
                        }
                    }
                    results.success++;
                }
                catch (error) {
                    results.failed++;
                    if (results.errors.length < 100)
                        results.errors.push(`Groupe ${key}: ${error.message} `);
                }
            }
        }
        catch (globalError) {
            console.error('CRITICAL IMPORT ERROR:', globalError);
            results.failed = data.length;
            results.errors.push(`Erreur Critique: ${globalError.message} `);
        }
        console.log(`🚀 Sequential bulk inserting ${fichesToCreate.length} fiches then ${facturesToCreate.length} factures...`);
        const CHUNK_SIZE = 5000;
        for (let i = 0; i < fichesToCreate.length; i += CHUNK_SIZE) {
            const ficheChunk = fichesToCreate.slice(i, i + CHUNK_SIZE);
            try {
                const result = await this.prisma.fiche.createMany({
                    data: ficheChunk,
                    skipDuplicates: true,
                });
                console.log(`   [Fiches] Chunk ${i / CHUNK_SIZE + 1}: Requested ${ficheChunk.length}, Persisted ${result.count}`);
            }
            catch (ficheErr) {
                console.error('❌ Fiche chunk insert error:', ficheErr.message);
            }
        }
        if (facturesToCreate.length > 0) {
            console.log(`🚀 Inserting ${facturesToCreate.length} factures...`);
            for (let i = 0; i < facturesToCreate.length; i += CHUNK_SIZE) {
                const factureChunk = facturesToCreate.slice(i, i + CHUNK_SIZE);
                try {
                    const result = await this.prisma.facture.createMany({
                        data: factureChunk.map(({ _acompte, ...rest }) => rest),
                        skipDuplicates: true,
                    });
                    console.log(`   [Factures] Chunk ${i / CHUNK_SIZE + 1}: Requested ${factureChunk.length}, Persisted ${result.count}`);
                }
                catch (factureErr) {
                    console.error('❌ Facture chunk insert error:', factureErr.message);
                    try {
                        const fs = require('fs');
                        fs.writeFileSync('facture-error-dump.json', JSON.stringify({
                            message: factureErr.message,
                            code: factureErr.code,
                            meta: factureErr.meta,
                            sample: factureChunk[0]
                        }, null, 2));
                    }
                    catch (e) { }
                }
            }
            console.log(`✅ Skipping loyalty points for bulk import (${facturesToCreate.length} factures).`);
        }
        const paymentsToCreate = [];
        for (const f of facturesToCreate) {
            if (f._acompte && f._acompte > 0) {
                paymentsToCreate.push({
                    factureId: f.id,
                    montant: f._acompte,
                    date: f.dateEmission || new Date(),
                    mode: 'ESPECES',
                    statut: 'ENCAISSE',
                    notes: 'Acompte Import (Délivrance)',
                });
            }
        }
        if (paymentsToCreate.length > 0) {
            try {
                await this.prisma.paiement.createMany({
                    data: paymentsToCreate,
                    skipDuplicates: true,
                });
                console.log(`✅ Bulk created ${paymentsToCreate.length} acomptes.`);
            }
            catch (err) {
                console.error('❌ Error creating acompte payments in bulk:', err.message);
            }
        }
        return results;
    }
    async importProducts(data, mapping, warehouseId) {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        for (const [index, row] of data.entries()) {
            let productData = {};
            try {
                productData = {
                    typeArticle: 'MONTURE',
                    statut: 'ACTIF',
                    entrepotId: warehouseId,
                    utilisateurCreation: 'IMPORT_SYSTEM',
                    seuilAlerte: 1,
                };
                const specificData = {};
                for (const [dbField, csvHeader] of Object.entries(mapping)) {
                    if (csvHeader && row[csvHeader] !== undefined) {
                        let value = row[csvHeader];
                        if ([
                            'prixAchatHT',
                            'prixVenteHT',
                            'prixVenteTTC',
                            'quantiteActuelle',
                            'seuilAlerte',
                            'coefficient',
                            'tauxTVA',
                        ].includes(dbField)) {
                            value = parseFloat(value) || 0;
                        }
                        if ([
                            'codeInterne',
                            'codeBarres',
                            'designation',
                            'marque',
                            'modele',
                            'couleur',
                        ].includes(dbField)) {
                            value = String(value || '');
                        }
                        if (dbField === 'montage') {
                            specificData.cerclage = value;
                        }
                        else {
                            productData[dbField] = value;
                        }
                    }
                }
                if (Object.keys(specificData).length > 0) {
                    productData.specificData = specificData;
                }
                if (!productData.designation &&
                    (productData.marque || productData.modele)) {
                    productData.designation = [
                        productData.marque,
                        productData.modele,
                        productData.couleur,
                    ]
                        .filter(Boolean)
                        .join(' ');
                }
                if (!productData.designation) {
                    const debugInfo = {
                        row,
                        mapping,
                        productData,
                    };
                    require('fs').writeFileSync('debug_import_error.json', JSON.stringify(debugInfo, null, 2));
                    console.error('❌ Designation Validation Fail:', debugInfo);
                    throw new Error('Designation is required (Marque/Modèle missing?)');
                }
                if (!productData.codeInterne) {
                    productData.codeInterne = 'IMP-' + Date.now() + '-' + index;
                }
                if (!productData.codeBarres) {
                    productData.codeBarres = productData.codeInterne;
                }
                const existingProduct = await this.prisma.product.findFirst({
                    where: {
                        entrepotId: warehouseId,
                        OR: [
                            { codeInterne: productData.codeInterne },
                            { codeBarres: productData.codeBarres },
                        ],
                    },
                });
                if (existingProduct) {
                    const updates = {};
                    let hasUpdates = false;
                    for (const [key, value] of Object.entries(productData)) {
                        if ([
                            'entrepotId',
                            'utilisateurCreation',
                            'createdAt',
                            'updatedAt',
                        ].includes(key))
                            continue;
                        const existingValue = existingProduct[key];
                        if (existingValue == null ||
                            existingValue === '' ||
                            existingValue === 0) {
                            if (value != null && value !== '' && value !== 0) {
                                updates[key] = value;
                                hasUpdates = true;
                            }
                        }
                    }
                    if (hasUpdates) {
                        await this.prisma.product.update({
                            where: { id: existingProduct.id },
                            data: updates,
                        });
                        results.updated++;
                        results.success++;
                    }
                    else {
                        results.success++;
                        this.logToFile(`Product Row ${index + 1}: Informative - Duplicate found.Counting as success.`);
                    }
                }
                else {
                    await this.prisma.product.create({
                        data: productData,
                    });
                    results.success++;
                }
            }
            catch (error) {
                results.failed++;
                console.error('❌ Prisma Import Error:', {
                    row: index + 1,
                    error: error.message,
                    code: error.code,
                    productData,
                });
                require('fs').writeFileSync('debug_import_fail_row.json', JSON.stringify({
                    row: index + 1,
                    productData,
                    error: error.message,
                }, null, 2));
                if (error.code === 'P2002') {
                    results.skipped++;
                }
                else {
                    results.failed++;
                    let errorMsg = error.message;
                    if (error.code === 'P2003') {
                        errorMsg = `Invalid reference: ${error.meta?.field_name || 'foreign key constraint'} `;
                    }
                    else if (error.message.includes('Argument')) {
                        const match = error.message.match(/Argument `(\w +)`/);
                        if (match) {
                            errorMsg = `Missing or invalid field: ${match[1]} `;
                        }
                    }
                    results.errors.push(`Row ${index + 1}: ${errorMsg} `);
                }
            }
        }
        return results;
    }
    async importFournisseurs(data, mapping) {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        for (let index = 0; index < data.length; index++) {
            const row = data[index];
            try {
                const nom = row[mapping.nom] ? String(row[mapping.nom]).trim() : null;
                if (!nom) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Missing supplier name`);
                    continue;
                }
                const code = row[mapping.code];
                let existingFournisseur = null;
                existingFournisseur = await this.prisma.fournisseur.findFirst({
                    where: { nom },
                });
                const fournisseurData = {
                    nom,
                    contact: row[mapping.contact]
                        ? String(row[mapping.contact]).trim()
                        : null,
                    email: row[mapping.email] ? String(row[mapping.email]).trim() : null,
                    telephone: row[mapping.telephone]
                        ? String(row[mapping.telephone]).trim()
                        : null,
                    adresse: row[mapping.adresse]
                        ? String(row[mapping.adresse]).trim()
                        : null,
                    ville: row[mapping.ville] ? String(row[mapping.ville]).trim() : null,
                    siteWeb: row[mapping.siteWeb]
                        ? String(row[mapping.siteWeb]).trim()
                        : null,
                    ice: row[mapping.ice] ? String(row[mapping.ice]).trim() : null,
                    rc: row[mapping.rc] ? String(row[mapping.rc]).trim() : null,
                    identifiantFiscal: row[mapping.identifiantFiscal]
                        ? String(row[mapping.identifiantFiscal]).trim()
                        : null,
                    patente: row[mapping.patente]
                        ? String(row[mapping.patente]).trim()
                        : null,
                    cnss: row[mapping.cnss] ? String(row[mapping.cnss]).trim() : null,
                    rib: row[mapping.rib] ? String(row[mapping.rib]).trim() : null,
                    banque: row[mapping.banque]
                        ? String(row[mapping.banque]).trim()
                        : null,
                    conditionsPaiement: row[mapping.conditionsPaiement]
                        ? String(row[mapping.conditionsPaiement]).trim()
                        : null,
                };
                if (existingFournisseur) {
                    await this.prisma.fournisseur.update({
                        where: { id: existingFournisseur.id },
                        data: fournisseurData,
                    });
                    results.updated++;
                }
                else {
                    await this.prisma.fournisseur.create({
                        data: fournisseurData,
                    });
                    results.success++;
                }
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message} `);
            }
        }
        return results;
    }
    async importFacturesFournisseurs(data, mapping, centreId, isBLOverride) {
        const [allSuppliers, allClients] = await Promise.all([
            this.prisma.fournisseur.findMany(),
            this.prisma.client.findMany({
                select: { id: true, codeClient: true, nom: true, telephone: true },
            }),
        ]);
        const supplierMap = new Map();
        allSuppliers.forEach((s) => {
            if (s.nom)
                supplierMap.set(s.nom.toUpperCase(), s);
            if (s.ice)
                supplierMap.set(s.ice.toUpperCase(), s);
        });
        const clientCodeMap = new Map();
        const clientIdentityMap = new Map();
        allClients.forEach((c) => {
            if (c.codeClient)
                clientCodeMap.set(c.codeClient.trim(), c.id);
            const nom = c.nom ? c.nom.trim().toUpperCase() : 'INCONNU';
            clientIdentityMap.set(`${nom}|${c.telephone?.trim()}`, c.id);
        });
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        let lastSupplier = null;
        let lastDateEmission = null;
        let lastNum = null;
        let lastRef = null;
        let lastIsBL = false;
        const sessionNumMap = new Map();
        console.log(`[IMPORT-FF-STRICT-1:1] STARTING BATCH AT ${new Date().toISOString()}`);
        console.log(`[IMPORT-FF-STRICT-1:1] Current results.updated: ${results.updated}`);
        console.log(`[IMPORT-FF] Starting import of ${data.length} rows`);
        console.log('[IMPORT-FF] Mapping received:', JSON.stringify(mapping));
        if (data.length > 0) {
            console.log('[IMPORT-FF] First row preview:', JSON.stringify(data[0]).slice(0, 500));
        }
        for (let index = 0; index < data.length; index++) {
            if (index % 100 === 0) {
                console.log(`[IMPORT-FF] Processing row ${index}... Current results: ${JSON.stringify(results)}`);
            }
            const row = data[index];
            try {
                const nomFournisseur = row[mapping.nomFournisseur] ||
                    row[mapping.fournisseur] ||
                    row[mapping.nom];
                const codeFournisseur = row[mapping.codeFournisseur];
                let numeroFacture = this.normalizeInvoiceNum(row[mapping.numeroFacture] || row[mapping.facture]);
                const referenceInterne = row[mapping.referenceInterne] ||
                    row[mapping.facture] ||
                    numeroFacture ||
                    '';
                const dateEmissionInput = row[mapping.dateEmission];
                if (this.isRowEmpty(row, mapping)) {
                    console.log(`[IMPORT-FF] Row ${index} skipped: EMPTY`);
                    results.skipped++;
                    continue;
                }
                if (this.isHeaderRow(row, mapping, index)) {
                    if (index === 0 ||
                        (!numeroFacture && !nomFournisseur && !codeFournisseur)) {
                        console.log(`[IMPORT-FF] Row ${index} skipped: HEADER DETECTED`);
                        results.skipped++;
                        continue;
                    }
                }
                let supplier = null;
                if (codeFournisseur || nomFournisseur) {
                    supplier =
                        supplierMap.get(String(codeFournisseur || '').toUpperCase()) ||
                            supplierMap.get(String(nomFournisseur || '').toUpperCase());
                    if (!supplier) {
                        supplier = await this.findOrCreateFournisseur((nomFournisseur || codeFournisseur), index);
                        if (supplier)
                            supplierMap.set(supplier.nom.toUpperCase(), supplier);
                    }
                }
                if (!supplier && !nomFournisseur && !codeFournisseur && lastSupplier) {
                    supplier = lastSupplier;
                }
                if (!supplier) {
                    supplier = await this.findOrCreateFournisseur('FOURNISSEUR INCONNU', index);
                    if (supplier)
                        supplierMap.set(supplier.nom.toUpperCase(), supplier);
                }
                if (!supplier) {
                    console.log(`[IMPORT-FF] Row ${index} failed: NO SUPPLIER FOUND`);
                    results.failed++;
                    results.errors.push(`Row ${index + 1}: Supplier not found`);
                    continue;
                }
                const dateEmission = this.parseDate(dateEmissionInput) ||
                    (numeroFacture === lastNum ? lastDateEmission : null) ||
                    new Date();
                const dateEcheance = this.parseDate(row[mapping.dateEcheance]);
                const montantHT = this.parseAmount(row[mapping.montantHT]);
                const montantTVA = this.parseAmount(row[mapping.montantTVA]);
                let montantTTC = this.parseAmount(row[mapping.montantTTC]);
                if (!montantTTC && (montantHT || montantTVA))
                    montantTTC = (montantHT || 0) + (montantTVA || 0);
                let isBL = false;
                if (isBLOverride !== undefined && isBLOverride !== null) {
                    isBL =
                        isBLOverride === true ||
                            isBLOverride === 'true' ||
                            isBLOverride === 1;
                }
                else {
                    const blVal = row[mapping.isBL];
                    if (blVal !== undefined) {
                        isBL =
                            blVal === true ||
                                blVal === 'true' ||
                                blVal === 1 ||
                                String(blVal).toUpperCase() === 'BL';
                    }
                    else if (numeroFacture === lastNum) {
                        isBL = lastIsBL;
                    }
                }
                lastSupplier = supplier;
                lastDateEmission = dateEmission;
                lastNum = numeroFacture;
                lastRef = referenceInterne || lastRef;
                lastIsBL = isBL;
                if (!numeroFacture && isBL) {
                    numeroFacture =
                        referenceInterne || `BL-AUTO-${index}-${new Date().getTime()}`;
                    console.log(`[IMPORT-FF] Row ${index}: Missing numeroFacture for BL. Using fallback: ${numeroFacture}`);
                }
                if (!numeroFacture) {
                    if (centreId && montantTTC > 0) {
                        const echeance = await this.prisma.echeancePaiement.create({
                            data: {
                                montant: montantTTC,
                                dateEcheance: dateEmission,
                                type: row[mapping.modePaiement] || 'ESPECES',
                                statut: 'EN_ATTENTE',
                            },
                        });
                        await this.prisma.depense.create({
                            data: {
                                date: dateEmission,
                                montant: montantTTC,
                                categorie: this.inferExpenseCategory(referenceInterne || supplier.nom),
                                description: `Achat sans facture (Fournisseur: ${supplier.nom})`,
                                modePaiement: row[mapping.modePaiement] || 'ESPECES',
                                statut: 'A_PAYER',
                                fournisseurId: supplier.id,
                                centreId: centreId || null,
                                echeanceId: echeance.id,
                            },
                        });
                        results.success++;
                    }
                    else {
                        console.log(`[IMPORT-FF] Row ${index} skipped: missing both invoice number and valid amount.`);
                        results.skipped++;
                    }
                    continue;
                }
                let finalNum = numeroFacture;
                let dupIndex = 1;
                while (true) {
                    const exists = isBL
                        ? await this.prisma.bonLivraison.findUnique({
                            where: {
                                fournisseurId_numeroBL: {
                                    fournisseurId: supplier.id,
                                    numeroBL: finalNum,
                                },
                            },
                        })
                        : await this.prisma.factureFournisseur.findUnique({
                            where: {
                                fournisseurId_numeroFacture: {
                                    fournisseurId: supplier.id,
                                    numeroFacture: finalNum,
                                },
                            },
                        });
                    if (!exists)
                        break;
                    finalNum = `${numeroFacture}_${dupIndex++}`;
                }
                if (finalNum !== numeroFacture) {
                    console.log(`[STRICT-1:1-v2] Adjusted duplicate: ${numeroFacture} -> ${finalNum} (Supplier: ${supplier.id})`);
                }
                numeroFacture = finalNum;
                {
                    const dbExisting = null;
                    let clientId = null;
                    let ficheId = null;
                    const fNumInput = row[mapping.ficheNumero];
                    if (fNumInput) {
                        const fNumParsed = parseInt(String(fNumInput).replace(/\D/g, ''));
                        if (!isNaN(fNumParsed)) {
                            const fiche = await this.prisma.fiche.findFirst({
                                where: { numero: fNumParsed },
                                include: { client: true },
                            });
                            const f = fiche;
                            if (f && f.client) {
                                ficheId = f.id;
                                clientId = f.clientId;
                            }
                        }
                    }
                    if (!clientId) {
                        const clientInput = row[mapping.client] || row[mapping.nomClient];
                        if (clientInput) {
                            const client = await this.prisma.client.findFirst({
                                where: {
                                    OR: [
                                        { id: String(clientInput) },
                                        { codeClient: String(clientInput) },
                                        {
                                            nom: {
                                                contains: String(clientInput),
                                                mode: 'insensitive',
                                            },
                                        },
                                    ],
                                },
                            });
                            if (client) {
                                const c = client;
                                clientId = c.id;
                                const clientFiches = await this.prisma.fiche.findMany({
                                    where: { clientId: c.id },
                                });
                                if (c && clientFiches.length > 0) {
                                    const c = client;
                                    let closestFiche = clientFiches[0];
                                    let minDiff = Math.abs(new Date(clientFiches[0].dateCreation).getTime() -
                                        dateEmission.getTime());
                                    for (const f of clientFiches) {
                                        const diff = Math.abs(new Date(f.dateCreation).getTime() -
                                            dateEmission.getTime());
                                        if (diff < minDiff) {
                                            minDiff = diff;
                                            closestFiche = f;
                                        }
                                    }
                                    ficheId = closestFiche.id;
                                }
                            }
                        }
                    }
                    if (!clientId) {
                        const cCode = row[mapping.codeClient];
                        const cNom = row[mapping.nomClient] || row[mapping.nom];
                        const cTel = row[mapping.telephoneClient] || row[mapping.telephone];
                        if (cCode)
                            clientId = clientCodeMap.get(String(cCode).trim()) || null;
                        if (!clientId && cNom && cTel)
                            clientId =
                                clientIdentityMap.get(`${String(cNom).trim().toUpperCase()}|${String(cTel).trim()}`) || null;
                        if (clientId && !ficheId) {
                            const bestFiche = await this.prisma.fiche.findFirst({
                                where: {
                                    clientId: clientId ?? undefined,
                                    dateCreation: { lte: dateEmission },
                                },
                                orderBy: { dateCreation: 'desc' },
                            });
                            if (bestFiche) {
                                ficheId = bestFiche.id;
                            }
                        }
                    }
                    if (isBL) {
                        const record = await this.prisma.bonLivraison.create({
                            data: {
                                numeroBL: numeroFacture,
                                dateEmission,
                                dateEcheance,
                                montantHT: montantHT || 0,
                                montantTVA: montantTVA || 0,
                                montantTTC: montantTTC || 0,
                                statut: 'VALIDEE',
                                type: row[mapping.type] || 'ACHAT_STOCK',
                                fournisseurId: supplier.id,
                                centreId: centreId || null,
                                clientId,
                                ficheId,
                                categorieBL: row[mapping.categorieBL] || null,
                            },
                        });
                        await this.prisma.echeancePaiement.create({
                            data: {
                                bonLivraisonId: record.id,
                                montant: montantTTC || 0,
                                dateEcheance: dateEcheance || dateEmission,
                                type: row[mapping.modePaiement] || 'ESPECES',
                                statut: 'EN_ATTENTE',
                            },
                        });
                    }
                    else {
                        const record = await this.prisma.factureFournisseur.create({
                            data: {
                                numeroFacture,
                                dateEmission,
                                dateEcheance,
                                montantHT: montantHT || 0,
                                montantTVA: montantTVA || 0,
                                montantTTC: montantTTC || 0,
                                quantite: this.parseAmount(row[mapping.quantite]),
                                statut: 'A_PAYER',
                                type: row[mapping.type] || 'ACHAT_STOCK',
                                fournisseurId: supplier.id,
                                centreId: centreId || null,
                                referenceInterne,
                                clientId,
                                ficheId,
                            },
                        });
                        await this.prisma.echeancePaiement.create({
                            data: {
                                factureFournisseurId: record.id,
                                montant: montantTTC || 0,
                                dateEcheance: dateEcheance || dateEmission,
                                type: row[mapping.modePaiement] || 'ESPECES',
                                statut: 'EN_ATTENTE',
                            },
                        });
                    }
                    results.success++;
                }
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message}`);
            }
        }
        return results;
    }
    async importPaiementsFournisseurs(data, mapping) {
        const [allSuppliers] = await Promise.all([
            this.prisma.fournisseur.findMany(),
        ]);
        const supplierMap = new Map();
        allSuppliers.forEach((s) => {
            if (s.nom)
                supplierMap.set(s.nom.toUpperCase(), s);
            if (s.ice)
                supplierMap.set(s.ice.toUpperCase(), s);
        });
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        for (let index = 0; index < data.length; index++) {
            const row = data[index];
            try {
                if (this.isRowEmpty(row, mapping) ||
                    this.isHeaderRow(row, mapping, index))
                    continue;
                const nomFournisseur = row[mapping.nomFournisseur] ||
                    row[mapping.fournisseur] ||
                    row[mapping.nom];
                const codeFournisseur = row[mapping.codeFournisseur];
                const numeroFacture = this.normalizeInvoiceNum(row[mapping.numeroFacture] ||
                    row[mapping.npiece] ||
                    row[mapping.facture]);
                const referenceReglement = row[mapping.reference];
                const dateReglement = this.parseDate(row[mapping.datePaiement]) || new Date();
                const montant = this.parseAmount(row[mapping.montant] || row[mapping.montantTTC]);
                if (montant === 0)
                    continue;
                let supplier = supplierMap.get(String(codeFournisseur || '').toUpperCase()) ||
                    supplierMap.get(String(nomFournisseur || '').toUpperCase());
                if (!supplier) {
                    supplier = await this.findOrCreateFournisseur((nomFournisseur ||
                        codeFournisseur ||
                        'FOURNISSEUR_INCONNU'), index);
                    if (supplier)
                        supplierMap.set(supplier.nom.toUpperCase(), supplier);
                }
                if (!supplier) {
                    results.failed++;
                    results.errors.push(`Row ${index + 1}: Supplier not found`);
                    continue;
                }
                let facture;
                let depense;
                let bl;
                if (numeroFacture && numeroFacture.length > 0) {
                    facture = await this.prisma.factureFournisseur.findFirst({
                        where: {
                            fournisseurId: supplier.id,
                            OR: [
                                {
                                    numeroFacture: { equals: numeroFacture, mode: 'insensitive' },
                                },
                                {
                                    numeroFacture: {
                                        startsWith: numeroFacture + '_',
                                        mode: 'insensitive',
                                    },
                                },
                                {
                                    referenceInterne: {
                                        equals: numeroFacture,
                                        mode: 'insensitive',
                                    },
                                },
                                {
                                    referenceInterne: {
                                        startsWith: `AUTO-CREATED (nPiece: ${numeroFacture}`,
                                        mode: 'insensitive',
                                    },
                                },
                            ],
                        },
                        orderBy: {
                            statut: 'asc',
                        },
                    });
                    if (!facture) {
                        bl = await this.prisma.bonLivraison.findFirst({
                            where: {
                                fournisseurId: supplier.id,
                                OR: [
                                    { numeroBL: { equals: numeroFacture, mode: 'insensitive' } },
                                    {
                                        numeroBL: {
                                            startsWith: numeroFacture + '_',
                                            mode: 'insensitive',
                                        },
                                    },
                                ],
                            },
                            orderBy: {
                                statut: 'asc',
                            },
                        });
                    }
                }
                if (!facture && montant > 0) {
                    facture = await this.prisma.factureFournisseur.findFirst({
                        where: {
                            fournisseurId: supplier.id,
                            montantTTC: montant,
                            statut: { in: ['A_PAYER', 'PARTIELLE'] },
                        },
                        orderBy: { dateEmission: 'asc' },
                    });
                }
                if (!facture && montant > 0) {
                    depense = await this.prisma.depense.findFirst({
                        where: {
                            fournisseurId: supplier.id,
                            montant: montant,
                            statut: { in: ['A_PAYER', 'NON_PAYEE', 'PARTIELLE'] },
                        },
                    });
                }
                const safeRef = referenceReglement && String(referenceReglement).trim().length > 0
                    ? String(referenceReglement).trim()
                    : null;
                if (!facture && !bl && !depense) {
                    if (numeroFacture) {
                        facture = await this.prisma.factureFournisseur.create({
                            data: {
                                numeroFacture,
                                dateEmission: dateReglement,
                                montantHT: 0,
                                montantTVA: 0,
                                montantTTC: montant,
                                statut: 'PAYEE',
                                fournisseurId: supplier.id,
                                type: 'ACHAT_STOCK',
                                centreId: supplier.centreId || (await this.getDefaultCentreId()),
                                referenceInterne: `AUTO-CREATED (nPiece: ${numeroFacture})`,
                            },
                        });
                        await this.prisma.echeancePaiement.create({
                            data: {
                                factureFournisseurId: facture ? facture.id : undefined,
                                bonLivraisonId: bl ? bl.id : undefined,
                                montant,
                                dateEncaissement: dateReglement,
                                dateEcheance: dateReglement,
                                reference: safeRef,
                                statut: 'PAYEE',
                                type: row[mapping.modePaiement] || 'PAIEMENT',
                                remarque: `AUTO-CREATED FROM UNMATCHED PAYMENT (nPiece: ${numeroFacture})`,
                            },
                        });
                        results.success++;
                        continue;
                    }
                    else {
                        const newEcheance = await this.prisma.echeancePaiement.create({
                            data: {
                                montant,
                                dateEncaissement: dateReglement,
                                dateEcheance: dateReglement,
                                reference: safeRef,
                                statut: 'PAYEE',
                                type: row[mapping.modePaiement] || 'ESPECES',
                                remarque: `AUTO-CREATED FROM UNMATCHED PAYMENT (Row ${index + 1})`,
                            },
                        });
                        depense = await this.prisma.depense.create({
                            data: {
                                date: dateReglement,
                                montant,
                                categorie: 'AUTRE',
                                description: `Paiement sans facture: ${safeRef || 'Sans Ref'}`,
                                modePaiement: row[mapping.modePaiement] || 'ESPECES',
                                statut: 'PAYEE',
                                centreId: supplier.centreId || (await this.getDefaultCentreId()),
                                fournisseurId: supplier.id,
                                echeanceId: newEcheance.id,
                            },
                        });
                        results.success++;
                        continue;
                    }
                }
                const idempotencyWhere = {
                    montant,
                    dateEncaissement: dateReglement,
                    statut: { in: ['PAYEE', 'ENCAISSE'] },
                };
                if (facture)
                    idempotencyWhere.factureFournisseurId = facture.id;
                if (depense && depense.echeanceId)
                    idempotencyWhere.id = depense.echeanceId;
                if (safeRef) {
                    idempotencyWhere.reference = safeRef;
                    const existing = await this.prisma.echeancePaiement.findFirst({
                        where: idempotencyWhere,
                    });
                    if (existing) {
                        results.skipped++;
                        continue;
                    }
                }
                else {
                    const existing = await this.prisma.echeancePaiement.findFirst({
                        where: idempotencyWhere,
                    });
                    if (existing) {
                        results.skipped++;
                        continue;
                    }
                }
                let echeanceIdToUpdate = null;
                if (facture) {
                    const pending = await this.prisma.echeancePaiement.findFirst({
                        where: { factureFournisseurId: facture.id, statut: 'EN_ATTENTE' },
                        orderBy: { dateEcheance: 'asc' },
                    });
                    if (pending) {
                        echeanceIdToUpdate = pending.id;
                    }
                    else {
                        const existingAdd = await this.prisma.echeancePaiement.findFirst({
                            where: {
                                factureFournisseurId: facture.id,
                                montant,
                                dateEncaissement: dateReglement,
                                statut: { in: ['PAYEE', 'ENCAISSE'] },
                                reference: safeRef,
                            },
                        });
                        if (existingAdd) {
                            results.skipped++;
                            continue;
                        }
                        await this.prisma.echeancePaiement.create({
                            data: {
                                factureFournisseurId: facture.id,
                                montant,
                                dateEncaissement: dateReglement,
                                dateEcheance: dateReglement,
                                reference: safeRef,
                                statut: 'PAYEE',
                                type: row[mapping.modePaiement] || 'PAIEMENT',
                                remarque: `ADDITIONAL PAYMENT (nPiece: ${numeroFacture})`,
                            },
                        });
                    }
                }
                else if (depense) {
                    echeanceIdToUpdate = depense.echeanceId;
                }
                if (echeanceIdToUpdate) {
                    await this.prisma.echeancePaiement.update({
                        where: { id: echeanceIdToUpdate },
                        data: {
                            montant,
                            dateEncaissement: dateReglement,
                            reference: safeRef,
                            statut: 'PAYEE',
                            type: row[mapping.modePaiement] || 'PAIEMENT',
                        },
                    });
                }
                if (facture) {
                    const agg = await this.prisma.echeancePaiement.aggregate({
                        where: { factureFournisseurId: facture.id, statut: 'PAYEE' },
                        _sum: { montant: true },
                    });
                    const paid = agg._sum.montant || 0;
                    const isAutoCreated = facture.referenceInterne?.includes('AUTO-CREATED');
                    const targetTotal = isAutoCreated
                        ? Math.max(facture.montantTTC, paid)
                        : facture.montantTTC;
                    await this.prisma.factureFournisseur.update({
                        where: { id: facture.id },
                        data: {
                            statut: paid >= targetTotal ? 'PAYEE' : 'PARTIELLE',
                            montantTTC: isAutoCreated ? targetTotal : undefined,
                        },
                    });
                }
                else if (depense) {
                    await this.prisma.depense.update({
                        where: { id: depense.id },
                        data: { statut: 'PAYEE' },
                    });
                }
                results.success++;
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message}`);
            }
        }
        return results;
    }
    async importFacturesVentes(data, mapping, centreId) {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        const codes = new Set();
        const names = new Set();
        data.forEach((row) => {
            if (row[mapping.codeClient])
                codes.add(String(row[mapping.codeClient]).trim());
            if (row[mapping.nomClient])
                names.add(String(row[mapping.nomClient]).trim());
        });
        const allClients = await this.prisma.client.findMany({
            where: {
                OR: [
                    { codeClient: { in: Array.from(codes) } },
                    { nom: { in: Array.from(names) } },
                ],
            },
            select: { id: true, codeClient: true, nom: true },
        });
        const clientByCode = new Map(allClients.filter((c) => c.codeClient).map((c) => [c.codeClient, c]));
        const clientByName = new Map(allClients
            .filter((c) => c.nom)
            .map((c) => [c.nom.toLowerCase().trim(), c]));
        const factureNums = data
            .filter((row) => row[mapping.numero] || row['Fiche'] || row['fiche'] || row[mapping.fiche_id])
            .map((row) => String(row[mapping.numero] || row['Fiche'] || row['fiche'] || row[mapping.fiche_id]).trim());
        const ficheNums = data
            .map((row) => {
            const val = row['Fiche'] || row['fiche'] || row[mapping.fiche_id];
            if (!val)
                return NaN;
            return this.robustParseFicheNumber(val) || NaN;
        })
            .filter((n) => !isNaN(n));
        const existingFactures = [];
        for (let i = 0; i < factureNums.length; i += 500) {
            const chunk = factureNums.slice(i, i + 500);
            const facturesChunk = await this.prisma.facture.findMany({
                where: {
                    OR: [
                        { numero: { in: chunk } },
                        { numero: { in: chunk.map((n) => `Fact-${n}`) } },
                        { numero: { in: chunk.map((n) => `BC-${n}`) } },
                        {
                            numero: {
                                in: chunk.map((n) => n.startsWith('Fact-') ? n.replace(/^Fact-/, '') : n.startsWith('BC-') ? n.replace(/^BC-/, '') : n),
                            },
                        },
                    ],
                },
            });
            existingFactures.push(...facturesChunk);
        }
        const factureLookupMap = new Map();
        existingFactures.forEach((f) => {
            factureLookupMap.set(f.numero, f);
            const simpleNum = f.numero.replace(/^(Fact-|BC-|FAC-)/, '');
            if (!factureLookupMap.has(simpleNum))
                factureLookupMap.set(simpleNum, f);
            const parts = simpleNum.split(/[^0-9]/).filter(p => p.length > 0);
            if (parts.length > 0) {
                const pureNum = parts[0];
                const year = parts.length > 1 ? parts[1] : null;
                if (!factureLookupMap.has(pureNum))
                    factureLookupMap.set(pureNum, f);
                if (year) {
                    factureLookupMap.set(`${year}_${pureNum}`, f);
                    const shortYear = year.length === 4 ? year.substring(2) : year;
                    factureLookupMap.set(`${shortYear}_${pureNum}`, f);
                }
                if (!factureLookupMap.has(`Fact-${pureNum}`))
                    factureLookupMap.set(`Fact-${pureNum}`, f);
                if (!factureLookupMap.has(`BC-${pureNum}`))
                    factureLookupMap.set(`BC-${pureNum}`, f);
            }
        });
        const existingFiches = await this.prisma.fiche.findMany({
            where: { numero: { in: ficheNums } },
            select: {
                id: true,
                numero: true,
                clientId: true,
                facture: {
                    select: {
                        id: true,
                        numero: true,
                        totalTTC: true,
                        resteAPayer: true,
                        clientId: true,
                    },
                },
            },
        });
        existingFiches.forEach((f) => {
            if (f.numero) {
                const numStr = String(f.numero);
                if (f.facture && !factureLookupMap.has(numStr)) {
                    factureLookupMap.set(numStr, f.facture);
                }
                const robustFicheNum = this.robustParseFicheNumber(f.numero);
                if (robustFicheNum && f.facture && !factureLookupMap.has(robustFicheNum)) {
                    factureLookupMap.set(robustFicheNum, f.facture);
                }
            }
        });
        const ficheLookupMap = new Map();
        existingFiches.forEach((f) => {
            if (f.numero)
                ficheLookupMap.set(Number(f.numero), f);
        });
        const facturesToCreate = [];
        const facturesToUpdate = [];
        for (let index = 0; index < data.length; index++) {
            const row = data[index];
            try {
                if (this.isRowEmpty(row, mapping) ||
                    (index === 0 && this.isHeaderRow(row, mapping, index))) {
                    results.skipped++;
                    continue;
                }
                const codeClient = row[mapping.codeClient]
                    ? String(row[mapping.codeClient]).trim()
                    : null;
                const nomClient = row[mapping.nomClient]
                    ? String(row[mapping.nomClient]).trim()
                    : null;
                const numero = row[mapping.numero] || row['Fiche'] || row['fiche']
                    ? String(row[mapping.numero] || row['Fiche'] || row['fiche']).trim()
                    : null;
                if (!numero) {
                    results.failed++;
                    results.errors.push(`Row ${index + 1}: Numero manquant`);
                    continue;
                }
                let client = null;
                if (codeClient)
                    client = clientByCode.get(codeClient) || null;
                if (!client && nomClient)
                    client = clientByName.get(nomClient.toLowerCase().trim()) || null;
                const rawFicheRef = row['Fiche'] || row['fiche'] || row[mapping.fiche_id];
                const inputFicheNum = this.robustParseFicheNumber(rawFicheRef) || NaN;
                let existingFacture = factureLookupMap.get(numero);
                let linkedFiche = null;
                if (!existingFacture && !isNaN(inputFicheNum)) {
                    linkedFiche = ficheLookupMap.get(inputFicheNum);
                    if (linkedFiche && linkedFiche.facture) {
                        existingFacture = linkedFiche.facture;
                    }
                }
                if (!existingFacture) {
                    let numericPartStr = '';
                    const parts = numero.split(/[^0-9]/).filter((p) => p.length > 0);
                    if (parts.length > 0) {
                        numericPartStr = parts[0];
                    }
                    const dateEmissionForYear = this.parseDate(row[mapping.dateEmission]) || new Date();
                    const yearSuffix = dateEmissionForYear.getFullYear().toString().substring(2);
                    existingFacture =
                        factureLookupMap.get(`Fact-${numero}`) ||
                            factureLookupMap.get(`BC-${numero}`) ||
                            factureLookupMap.get(numericPartStr) ||
                            factureLookupMap.get(`Fact-${numericPartStr}`) ||
                            factureLookupMap.get(`BC-${numericPartStr}`) ||
                            factureLookupMap.get(`${yearSuffix}_${numericPartStr}`) ||
                            factureLookupMap.get(inputFicheNum);
                }
                let clientId = client ? client.id : null;
                if (!clientId && existingFacture)
                    clientId = existingFacture.clientId;
                if (!clientId && linkedFiche)
                    clientId = linkedFiche.clientId;
                if (!clientId) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Client introuvable`);
                    continue;
                }
                const totalTTC = parseFloat(String(row[mapping.totalTTC] || 0)) || 0;
                const totalHT = totalTTC / 1.2;
                const totalTVA = totalTTC - totalHT;
                let invoiceNumero = numero;
                if (!invoiceNumero.startsWith('Fact-') && !invoiceNumero.startsWith('BC-')) {
                    invoiceNumero = `Fact-${invoiceNumero}`;
                }
                if (existingFacture) {
                    facturesToUpdate.push({
                        id: existingFacture.id,
                        data: {
                            numero: invoiceNumero,
                        },
                    });
                    results.success++;
                }
                else {
                    results.failed++;
                    results.errors.push(`Row ${index + 1}: Aucun document correspondant trouvé pour le Dossier ${rawFicheRef || numero}`);
                }
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message}`);
            }
        }
        if (facturesToCreate.length > 0) {
            await this.prisma.facture.createMany({
                data: facturesToCreate,
                skipDuplicates: true,
            });
            results.success += facturesToCreate.length;
        }
        if (facturesToUpdate.length > 0) {
            const BATCH_SIZE = 10;
            for (let i = 0; i < facturesToUpdate.length; i += BATCH_SIZE) {
                const batch = facturesToUpdate.slice(i, i + BATCH_SIZE);
                for (const upd of batch) {
                    try {
                        await this.prisma.facture.update({
                            where: { id: upd.id },
                            data: upd.data,
                        });
                        results.updated++;
                        results.success++;
                    }
                    catch (updErr) {
                        console.error(`Row Update Fail: ${upd.id}`, updErr);
                        results.failed++;
                    }
                }
            }
        }
        return results;
    }
    async importPaiementsClients(data, mapping) {
        console.log('[ImportLog] PaiementsClients — OPTIMIZED BULK MODE');
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        try {
            const t0 = Date.now();
            const [allFiches, allFactures, allClients] = await Promise.all([
                this.prisma.fiche.findMany({
                    select: { id: true, numero: true, clientId: true },
                }),
                this.prisma.facture.findMany({
                    select: {
                        id: true,
                        ficheId: true,
                        clientId: true,
                        totalTTC: true,
                        resteAPayer: true,
                        numero: true,
                        type: true,
                    },
                }),
                this.prisma.client.findMany({
                    select: { id: true, codeClient: true, nom: true, telephone: true },
                }),
            ]);
            const ficheByCompteur = new Map();
            allFiches.forEach((f) => {
                if (f.numero)
                    ficheByCompteur.set(Number(f.numero), f);
            });
            const factureByFicheId = new Map();
            const factureByNumero = new Map();
            allFactures.forEach((f) => {
                if (f.ficheId)
                    factureByFicheId.set(f.ficheId, f);
                if (f.numero)
                    factureByNumero.set(f.numero.trim(), f);
            });
            const clientByCode = new Map();
            const clientByNomLower = new Map();
            allClients.forEach((c) => {
                if (c.codeClient)
                    clientByCode.set(c.codeClient.trim(), c);
                if (c.nom)
                    clientByNomLower.set(c.nom.toLowerCase().trim(), c);
            });
            const paymentsToCreate = [];
            const factureUpdates = new Map();
            for (let index = 0; index < data.length; index++) {
                const row = data[index];
                if (this.isRowEmpty(row, mapping) ||
                    (index === 0 && this.isHeaderRow(row, mapping, index))) {
                    results.skipped++;
                    continue;
                }
                const ficheNumeroRaw = row[mapping.fiche] || row['Fiche'];
                const codeClient = row[mapping.codeClient]
                    ? String(row[mapping.codeClient]).trim()
                    : null;
                const nomClientRaw = row[mapping.nomClient]
                    ? String(row[mapping.nomClient]).trim()
                    : null;
                const numeroFactureRaw = row[mapping.numeroFacture]
                    ? String(row[mapping.numeroFacture]).trim()
                    : null;
                let fiche = null;
                let facture = null;
                let client = null;
                if (ficheNumeroRaw) {
                    const parts = String(ficheNumeroRaw)
                        .split(/[^0-9]/)
                        .filter((p) => p.length > 0);
                    if (parts.length > 0) {
                        const ficheNum = parseInt(parts[0]);
                        if (!isNaN(ficheNum))
                            fiche = ficheByCompteur.get(ficheNum) || null;
                    }
                }
                if (fiche) {
                    facture = factureByFicheId.get(fiche.id) || null;
                }
                if (!facture && numeroFactureRaw) {
                    facture = factureByNumero.get(numeroFactureRaw) || null;
                }
                if (fiche?.clientId) {
                    client = allClients.find((c) => c.id === fiche.clientId) || null;
                }
                if (!client && codeClient) {
                    client = clientByCode.get(codeClient) || null;
                }
                if (!client && nomClientRaw) {
                    const normNom = nomClientRaw.toLowerCase().trim();
                    client = clientByNomLower.get(normNom) || null;
                }
                if (!client) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Client non trouvé (code: ${codeClient}, nom: ${nomClientRaw})`);
                    continue;
                }
                if (!facture) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Facture non trouvée pour client ${client.nom} (Fiche: ${ficheNumeroRaw}, Num: ${numeroFactureRaw})`);
                    continue;
                }
                const montant = Math.abs(parseFloat(row[mapping.montant]) || 0);
                if (montant === 0) {
                    results.skipped++;
                    continue;
                }
                const datePaiement = this.parseDate(row[mapping.datePaiement]) || new Date();
                const modeSource = row[mapping.modePaiement]
                    ? String(row[mapping.modePaiement]).trim().toUpperCase()
                    : 'ESPECES';
                const reference = row[mapping.reference]
                    ? String(row[mapping.reference]).substring(0, 100)
                    : null;
                const notes = row[mapping.notes]
                    ? String(row[mapping.notes]).substring(0, 500)
                    : null;
                paymentsToCreate.push({
                    factureId: facture.id,
                    montant,
                    date: datePaiement,
                    mode: modeSource,
                    reference,
                    notes,
                    statut: 'ENCAISSE',
                });
                if (!factureUpdates.has(facture.id)) {
                    factureUpdates.set(facture.id, {
                        totalPaid: 0,
                        totalTTC: Number(facture.totalTTC || 0),
                        type: facture.type,
                    });
                }
                factureUpdates.get(facture.id).totalPaid += montant;
                results.success++;
            }
            console.log(`[ImportLog] Phase 3: Bulk inserting ${paymentsToCreate.length} payments...`);
            const t1 = Date.now();
            const BATCH_SIZE = 500;
            for (let i = 0; i < paymentsToCreate.length; i += BATCH_SIZE) {
                const batch = paymentsToCreate.slice(i, i + BATCH_SIZE);
                await this.prisma.paiement.createMany({
                    data: batch,
                    skipDuplicates: true,
                });
                console.log(`[ImportLog] Inserted batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(paymentsToCreate.length / BATCH_SIZE)}`);
            }
            console.log(`[ImportLog] Bulk insert done in ${Date.now() - t1}ms`);
            console.log(`[ImportLog] Phase 4: Updating ${factureUpdates.size} invoice balances...`);
            const t2 = Date.now();
            const updatePromises = [];
            for (const [factureId, info] of factureUpdates) {
                const resteAPayer = Math.max(0, info.totalTTC - info.totalPaid);
                const statut = resteAPayer <= 0 ? 'PAYEE' : 'VALIDEE';
                const newType = info.type === 'DEVIS' ? 'BON_COMMANDE' : info.type;
                updatePromises.push(this.prisma.facture.update({
                    where: { id: factureId },
                    data: {
                        resteAPayer,
                        statut,
                        ...(info.type === 'DEVIS' ? { type: newType } : {}),
                    },
                }));
                if (updatePromises.length >= 100) {
                    await Promise.all(updatePromises.splice(0, 100));
                }
            }
            if (updatePromises.length > 0)
                await Promise.all(updatePromises);
            console.log(`[ImportLog] Balance updates done in ${Date.now() - t2}ms`);
            console.log(`[ImportLog] TOTAL IMPORT TIME: ${Date.now() - t0}ms`);
        }
        catch (globalError) {
            console.error('CRITICAL IMPORT ERROR (PaiementsClients):', globalError);
            results.failed = data.length;
            results.errors.push(`Erreur Critique: ${globalError.message}`);
        }
        return results;
    }
    async importDepenses(data, mapping, centreId) {
        const results = {
            success: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            errors: [],
        };
        for (let index = 0; index < data.length; index++) {
            const row = data[index];
            try {
                if (this.isRowEmpty(row, mapping) ||
                    this.isHeaderRow(row, mapping, index)) {
                    results.skipped++;
                    continue;
                }
                const montant = this.parseAmount(row[mapping.montant]);
                const description = row[mapping.description]
                    ? String(row[mapping.description]).trim()
                    : '';
                const dateRaw = row[mapping.date];
                const hasDate = !!dateRaw && String(dateRaw).trim() !== '';
                const hasSupplier = !!row[mapping.fournisseur];
                if (!montant && !description && !hasDate && !hasSupplier) {
                    results.skipped++;
                    continue;
                }
                const date = this.parseDate(row[mapping.date]) || new Date();
                const categorie = row[mapping.categorie]
                    ? String(row[mapping.categorie]).trim()
                    : 'AUTRE_DEPENSE';
                const modePaiement = row[mapping.modePaiement]
                    ? String(row[mapping.modePaiement]).trim()
                    : 'ESPECES';
                const statut = row[mapping.statut]
                    ? String(row[mapping.statut]).trim()
                    : 'PAYEE';
                const fournisseurNom = row[mapping.fournisseur]
                    ? String(row[mapping.fournisseur]).trim()
                    : 'PERSONNEL';
                if (montant <= 0) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Invalid amount`);
                    continue;
                }
                if (!centreId) {
                    results.skipped++;
                    results.errors.push(`Row ${index + 1}: Missing centre ID`);
                    continue;
                }
                let fournisseurId = null;
                if (fournisseurNom) {
                    const fournisseur = await this.prisma.fournisseur.findFirst({
                        where: { nom: fournisseurNom },
                    });
                    if (fournisseur) {
                        fournisseurId = fournisseur.id;
                    }
                }
                const finalDescription = fournisseurNom
                    ? `${description || ''} (Fournisseur: ${fournisseurNom})`
                    : description;
                const depenseData = {
                    date,
                    montant,
                    categorie,
                    description: finalDescription,
                    modePaiement,
                    statut,
                    centreId,
                    factureFournisseurId: null,
                    echeanceId: null,
                };
                await this.prisma.depense.create({ data: depenseData });
                results.success++;
            }
            catch (error) {
                results.failed++;
                results.errors.push(`Row ${index + 1}: ${error.message} `);
            }
        }
        return results;
    }
    async findOrCreateFournisseur(nameInput, index) {
        const log = (msg) => {
            try {
                require('fs').appendFileSync('import_skips_factures.log', `[SUPPLIER_MATCH] Row ${index + 1}: ${msg} \n`);
            }
            catch (e) { }
            console.log(`[SupplierMatch] ${msg} `);
        };
        if (!nameInput || nameInput.trim() === '') {
            const fallbackName = 'FOURNISSEUR INCONNU';
            let fallback = await this.prisma.fournisseur.findFirst({
                where: { nom: fallbackName },
            });
            if (!fallback) {
                fallback = await this.prisma.fournisseur.create({
                    data: { nom: fallbackName },
                });
            }
            log(`Using global fallback supplier for empty name`);
            return fallback;
        }
        const manualMapping = {
            'L-0H': 'L-OH',
            'L-N': "L'N OPTIC",
            'O-N-A': 'O-N-A',
            'MAROC TELECO INTERNET': 'MAROC TELECOM',
            'ETUI BAKRIM': 'ETUI BAKRIM',
            '0-N-A': 'O-N-A',
        };
        if (manualMapping[nameInput.toUpperCase()]) {
            const mappedName = manualMapping[nameInput.toUpperCase()];
            const mappedSupplier = await this.prisma.fournisseur.findFirst({
                where: { nom: mappedName },
            });
            if (mappedSupplier) {
                log(`Manual mapping found: "${nameInput}" -> "${mappedName}"`);
                return mappedSupplier;
            }
        }
        const normalize = (n) => {
            if (!n)
                return '';
            return n
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/0/g, 'O')
                .replace(/[^a-zA-Z0-9]/g, '')
                .toUpperCase();
        };
        const searchName = normalize(nameInput);
        if (!searchName) {
            const fallbackName = 'FOURNISSEUR INCONNU';
            let fallback = await this.prisma.fournisseur.findFirst({
                where: { nom: fallbackName },
            });
            if (!fallback) {
                fallback = await this.prisma.fournisseur.create({
                    data: { nom: fallbackName },
                });
            }
            log(`Using global fallback supplier for non - normalizable name: "${nameInput}"`);
            return fallback;
        }
        let fournisseur = await this.prisma.fournisseur.findFirst({
            where: { nom: { equals: nameInput.trim(), mode: 'insensitive' } },
        });
        if (fournisseur) {
            log(`Exact match found: "${fournisseur.nom}"`);
            return fournisseur;
        }
        const allSuppliers = await this.prisma.fournisseur.findMany({
            select: { id: true, nom: true },
        });
        const levenshtein = require('fast-levenshtein');
        const matchedS = allSuppliers.find((s) => {
            const dbName = normalize(s.nom);
            if (dbName === searchName)
                return true;
            if (searchName.length > 5 && dbName.length > 5) {
                if (searchName.includes(dbName) || dbName.includes(searchName))
                    return true;
            }
            const searchWords = nameInput
                .toUpperCase()
                .split(/[^A-Z]/)
                .filter((w) => w.length > 3);
            const dbWords = s.nom
                .toUpperCase()
                .split(/[^A-Z]/)
                .filter((w) => w.length > 3);
            if (searchWords.length > 0 && dbWords.length > 0) {
                const commonWords = searchWords.filter((w) => dbWords.includes(w));
                if (commonWords.length >= Math.min(2, searchWords.length, dbWords.length))
                    return true;
            }
            const len = Math.max(searchName.length, dbName.length);
            if (len > 2) {
                const distance = levenshtein.get(searchName, dbName);
                const tolerance = len <= 4 ? 1 : Math.floor(len / 3);
                if (distance <= tolerance)
                    return true;
            }
            return false;
        });
        if (matchedS) {
            fournisseur = await this.prisma.fournisseur.findUnique({
                where: { id: matchedS.id },
            });
            if (fournisseur) {
                log(`Smart match found: "${fournisseur.nom}" for input "${nameInput}"`);
                return fournisseur;
            }
        }
        const cleanName = nameInput.trim();
        log(`Creating NEW Supplier: "${cleanName}"`);
        return await this.prisma.fournisseur.create({ data: { nom: cleanName } });
    }
    async getDefaultCentreId() {
        const centre = await this.prisma.centre.findFirst({
            orderBy: { createdAt: 'asc' },
        });
        return centre?.id || 'DEFAULT_CENTRE';
    }
    async clearData() {
        this.logToFile('Starting database wipe (TRUNCATE CASCADE) for clean re-import...');
        try {
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Paiement" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "EcheancePaiement" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Depense" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Facture" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "FactureFournisseur" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "MouvementStock" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Fiche" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Client" CASCADE;`);
            await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "Fournisseur" CASCADE;`);
            this.logToFile('Database wipe successful (TRUNCATE CASCADE)');
            return { message: 'Data cleared successfully via TRUNCATE' };
        }
        catch (error) {
            this.logToFile(`Error wiping database: ${error.message}`);
            throw new common_1.BadRequestException('Failed to clear data: ' + error.message);
        }
    }
};
exports.ImportsService = ImportsService;
exports.ImportsService = ImportsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        loyalty_service_1.LoyaltyService])
], ImportsService);
//# sourceMappingURL=imports.service.js.map