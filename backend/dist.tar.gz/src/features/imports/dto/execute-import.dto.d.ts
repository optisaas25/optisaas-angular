export declare class ExecuteImportDto {
    type?: any;
    data?: any[];
    mapping?: any;
    warehouseId?: any;
    centreId?: any;
    isBL?: any;
}
