"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const imports_service_1 = require("./imports.service");
const multer = __importStar(require("multer"));
const execute_import_dto_1 = require("./dto/execute-import.dto");
let ImportsController = class ImportsController {
    importsService;
    constructor(importsService) {
        this.importsService = importsService;
    }
    async uploadFile(file) {
        const fs = require('fs');
        const log = (msg) => fs.appendFileSync('import_debug.log', new Date().toISOString() + ' ' + msg + '\n');
        log('Upload request received');
        if (!file) {
            log('No file in request');
            throw new common_1.BadRequestException('No file uploaded');
        }
        log(`File received: ${file.originalname}, Size: ${file.size}, Mimetype: ${file.mimetype}`);
        try {
            const result = await this.importsService.parseFile(file.buffer);
            log('File parsed successfully');
            log('Result structure: ' +
                JSON.stringify({
                    hasHeaders: !!result.headers,
                    headersCount: result.headers?.length || 0,
                    hasData: !!result.data,
                    dataCount: result.data?.length || 0,
                    hasPreview: !!result.preview,
                    previewCount: result.preview?.length || 0,
                    resultKeys: Object.keys(result),
                }));
            log('First 3 headers: ' + JSON.stringify(result.headers?.slice(0, 3)));
            return result;
        }
        catch (error) {
            log('Error parsing file: ' + JSON.stringify(error));
            throw error;
        }
    }
    async executeImport(body) {
        console.log('📥 EXECUTE IMPORT REQUEST RECEIVED');
        console.log('Type:', body.type);
        console.log('Data Rows:', body.data?.length);
        console.log('Mapping Keys:', body.mapping ? Object.keys(body.mapping) : 'NONE');
        const fs = require('fs');
        const log = (msg) => {
            const timestamp = new Date().toISOString();
            console.log(`[ImportLog] ${msg}`);
            try {
                fs.appendFileSync('import_execute.log', `${timestamp} ${msg}\n`);
                fs.appendFileSync('import_debug.log', `${timestamp} ${msg}\n`);
            }
            catch (e) {
                console.error('Failed to write to log file:', e.message);
            }
        };
        log(`Execute import request START: Type=${body.type}, DataRows=${body.data?.length}`);
        if (!body.data || !Array.isArray(body.data)) {
            log('Error: Invalid or missing data array');
            throw new common_1.BadRequestException('Invalid or missing data array');
        }
        const data = body.data;
        const mapping = body.mapping || {};
        try {
            if (body.type === 'clients') {
                log('Executing importClients...');
                const res = await this.importsService.importClients(data, mapping, body.centreId);
                log('Client import completed successfully');
                return res;
            }
            else if (body.type === 'products') {
                log('Executing importProducts...');
                if (!body.warehouseId) {
                    log('Error: Warehouse ID missing');
                    throw new common_1.BadRequestException('Warehouse ID is required for product import');
                }
                const res = await this.importsService.importProducts(data, mapping, body.warehouseId);
                log('Product import completed successfully');
                return res;
            }
            else if (body.type &&
                typeof body.type === 'string' &&
                body.type.startsWith('fiches')) {
                log(`Executing importFiches (${body.type})...`);
                const res = await this.importsService.importFiches(data, mapping, body.centreId, body.type);
                log(`Fiches import completed: ${JSON.stringify({
                    success: res.success,
                    skipped: res.skipped,
                    failed: res.failed,
                    errorCount: res.errors?.length,
                })}`);
                return res;
            }
            else if (body.type === 'fournisseurs') {
                log('Executing importFournisseurs...');
                const res = await this.importsService.importFournisseurs(data, mapping);
                log('Fournisseurs import completed successfully');
                return res;
            }
            else if (body.type === 'factures_fournisseurs') {
                log('Executing importFacturesFournisseurs...');
                const res = await this.importsService.importFacturesFournisseurs(data, mapping, body.centreId, body.isBL);
                log('Factures fournisseurs import completed successfully');
                return res;
            }
            else if (body.type === 'paiements_fournisseurs') {
                log('Executing importPaiementsFournisseurs...');
                const res = await this.importsService.importPaiementsFournisseurs(data, mapping);
                log('Paiements fournisseurs import completed successfully');
                return res;
            }
            else if (body.type === 'factures_ventes') {
                log('Executing importFacturesVentes...');
                const res = await this.importsService.importFacturesVentes(data, mapping, body.centreId);
                log('Factures ventes import completed successfully');
                return res;
            }
            else if (body.type === 'paiements_clients') {
                log('Executing importPaiementsClients...');
                const res = await this.importsService.importPaiementsClients(data, mapping);
                log('Paiements clients import completed successfully');
                return res;
            }
            else if (body.type === 'depenses') {
                log('Executing importDepenses...');
                const res = await this.importsService.importDepenses(data, mapping, body.centreId);
                log('Depenses import completed successfully');
                return res;
            }
            log(`Error: Invalid import type detected: "${body.type}" (Type: ${typeof body.type})`);
            throw new common_1.BadRequestException('Invalid import type');
        }
        catch (error) {
            log('Error executing import: ' + error.message);
            console.error('Import Execution Error:', error);
            throw error;
        }
    }
    async clearData() {
        console.log('📥 CLEAR DATA REQUEST RECEIVED');
        return await this.importsService.clearData();
    }
};
exports.ImportsController = ImportsController;
__decorate([
    (0, common_1.Post)('upload'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: multer.memoryStorage(),
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ImportsController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)('execute'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [execute_import_dto_1.ExecuteImportDto]),
    __metadata("design:returntype", Promise)
], ImportsController.prototype, "executeImport", null);
__decorate([
    (0, common_1.Post)('clear-data'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ImportsController.prototype, "clearData", null);
exports.ImportsController = ImportsController = __decorate([
    (0, common_1.Controller)('imports'),
    __metadata("design:paramtypes", [imports_service_1.ImportsService])
], ImportsController);
//# sourceMappingURL=imports.controller.js.map