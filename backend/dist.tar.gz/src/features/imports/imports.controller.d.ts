import { ImportsService } from './imports.service';
import { ExecuteImportDto } from './dto/execute-import.dto';
export declare class ImportsController {
    private readonly importsService;
    constructor(importsService: ImportsService);
    uploadFile(file: any): Promise<{
        headers: string[];
        data: any;
        preview: any;
    }>;
    executeImport(body: ExecuteImportDto): Promise<{
        success: number;
        updated: number;
        skipped: number;
        failed: number;
        errors: string[];
    }>;
    clearData(): Promise<{
        message: string;
    }>;
}
