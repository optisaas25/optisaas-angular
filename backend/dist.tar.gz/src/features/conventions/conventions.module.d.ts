export declare class ConventionsModule {
}
