import { CreateConventionDto } from './create-convention.dto';
declare const UpdateConventionDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateConventionDto>>;
export declare class UpdateConventionDto extends UpdateConventionDto_base {
}
export {};
