"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateConventionDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_convention_dto_1 = require("./create-convention.dto");
class UpdateConventionDto extends (0, mapped_types_1.PartialType)(create_convention_dto_1.CreateConventionDto) {
}
exports.UpdateConventionDto = UpdateConventionDto;
//# sourceMappingURL=update-convention.dto.js.map