export declare enum RemiseType {
    PERCENTAGE = "PERCENTAGE",
    FLAT_AMOUNT = "FLAT_AMOUNT"
}
export declare class CreateConventionDto {
    nom: string;
    description?: string;
    contact?: string;
    email?: string;
    telephone?: string;
    adresse?: string;
    remiseType: string;
    remiseValeur: number;
    montantForfaitaire?: number;
    remiseForfaitaire?: boolean;
    montantForfaitaireMonture?: number;
    montantForfaitaireVerre?: number;
    notes?: string;
}
