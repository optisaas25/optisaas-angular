"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConventionsController = void 0;
const common_1 = require("@nestjs/common");
const conventions_service_1 = require("./conventions.service");
const create_convention_dto_1 = require("./dto/create-convention.dto");
const update_convention_dto_1 = require("./dto/update-convention.dto");
let ConventionsController = class ConventionsController {
    conventionsService;
    constructor(conventionsService) {
        this.conventionsService = conventionsService;
    }
    create(createConventionDto) {
        return this.conventionsService.create(createConventionDto);
    }
    findAll() {
        return this.conventionsService.findAll();
    }
    findOne(id) {
        return this.conventionsService.findOne(id);
    }
    update(id, updateConventionDto) {
        return this.conventionsService.update(id, updateConventionDto);
    }
    remove(id) {
        return this.conventionsService.remove(id);
    }
};
exports.ConventionsController = ConventionsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_convention_dto_1.CreateConventionDto]),
    __metadata("design:returntype", void 0)
], ConventionsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ConventionsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ConventionsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_convention_dto_1.UpdateConventionDto]),
    __metadata("design:returntype", void 0)
], ConventionsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ConventionsController.prototype, "remove", null);
exports.ConventionsController = ConventionsController = __decorate([
    (0, common_1.Controller)('conventions'),
    __metadata("design:paramtypes", [conventions_service_1.ConventionsService])
], ConventionsController);
//# sourceMappingURL=conventions.controller.js.map