"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConventionsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let ConventionsService = class ConventionsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createConventionDto) {
        return await this.prisma.convention.create({
            data: createConventionDto,
        });
    }
    async findAll() {
        return await this.prisma.convention.findMany({
            include: {
                _count: {
                    select: { clients: true },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }
    async findOne(id) {
        const convention = await this.prisma.convention.findUnique({
            where: { id },
            include: {
                clients: true,
            },
        });
        if (!convention) {
            throw new common_1.NotFoundException(`Convention with ID ${id} not found`);
        }
        return convention;
    }
    async update(id, updateConventionDto) {
        return await this.prisma.convention.update({
            where: { id },
            data: updateConventionDto,
        });
    }
    async remove(id) {
        return await this.prisma.convention.delete({
            where: { id },
        });
    }
};
exports.ConventionsService = ConventionsService;
exports.ConventionsService = ConventionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ConventionsService);
//# sourceMappingURL=conventions.service.js.map