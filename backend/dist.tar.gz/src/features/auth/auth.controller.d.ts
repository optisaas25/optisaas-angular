import { AuthService } from './auth.service';
import { ConfigService } from '@nestjs/config';
export declare class AuthController {
    private authService;
    private configService;
    constructor(authService: AuthService, configService: ConfigService);
    login(body: any): Promise<{
        user: {
            id: any;
            first_name: any;
            last_name: any;
            email: any;
            mobile: any;
            address: string;
            is_callcenter: boolean;
            remember_token: string;
            menu_favoris: string;
            centers: any;
            employee: any;
        };
        token: string;
        refresh_token: string;
    }>;
    getMe(authHeader: string): Promise<{
        id: any;
        first_name: any;
        last_name: any;
        email: any;
        mobile: any;
        address: string;
        is_callcenter: boolean;
        remember_token: string;
        menu_favoris: string;
        centers: any;
        employee: any;
    }>;
    refresh(body: any): Promise<{
        token: string;
        refresh_token: string;
    }>;
}
