"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const bcrypt = __importStar(require("bcryptjs"));
const jwt = __importStar(require("jsonwebtoken"));
const config_1 = require("@nestjs/config");
let AuthService = class AuthService {
    prisma;
    configService;
    jwtSecret;
    refreshSecret;
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
        this.jwtSecret =
            this.configService.get('JWT_SECRET') || 'your-very-secret-key';
        this.refreshSecret =
            this.configService.get('REFRESH_SECRET') ||
                'your-very-refresh-secret-key';
    }
    async login(email, pass) {
        const user = await this.prisma.user.findUnique({
            where: { email },
            include: { centreRoles: true, employee: true },
        });
        if (!user) {
            throw new common_1.UnauthorizedException('Identifiants invalides');
        }
        const isMatch = await bcrypt.compare(pass, user.password);
        if (!isMatch) {
            throw new common_1.UnauthorizedException('Identifiants invalides');
        }
        const tokens = this.generateTokens(user);
        return {
            ...tokens,
            user: this.mapToCurrentUser(user),
        };
    }
    generateTokens(user) {
        const payload = { sub: user.id, email: user.email };
        const token = jwt.sign(payload, this.jwtSecret, { expiresIn: '1d' });
        const refresh_token = jwt.sign(payload, this.refreshSecret, {
            expiresIn: '7d',
        });
        return { token, refresh_token };
    }
    async getCurrentUser(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            include: { centreRoles: true, employee: true },
        });
        if (!user) {
            throw new common_1.NotFoundException('Utilisateur non trouvé');
        }
        return this.mapToCurrentUser(user);
    }
    mapToCurrentUser(user) {
        return {
            id: user.id,
            first_name: user.prenom,
            last_name: user.nom,
            email: user.email,
            mobile: user.telephone || '',
            address: '',
            is_callcenter: false,
            remember_token: '',
            menu_favoris: '',
            centers: user.centreRoles.map((cr) => ({
                id: cr.centreId,
                name: cr.centreName,
                role: cr.role,
                active: true,
                migrated: false,
                entrepotIds: cr.entrepotIds,
                entrepotNames: cr.entrepotNames,
            })),
            employee: user.employee,
        };
    }
    async refreshToken(refreshToken) {
        try {
            const payload = jwt.verify(refreshToken, this.refreshSecret);
            const user = await this.prisma.user.findUnique({
                where: { id: payload.sub },
            });
            if (!user)
                throw new common_1.UnauthorizedException();
            return this.generateTokens(user);
        }
        catch (e) {
            throw new common_1.UnauthorizedException('Token de rafraîchissement invalide');
        }
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], AuthService);
//# sourceMappingURL=auth.service.js.map