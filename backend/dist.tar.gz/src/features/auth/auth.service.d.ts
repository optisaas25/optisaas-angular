import { PrismaService } from '../../prisma/prisma.service';
import { ConfigService } from '@nestjs/config';
export declare class AuthService {
    private prisma;
    private configService;
    private readonly jwtSecret;
    private readonly refreshSecret;
    constructor(prisma: PrismaService, configService: ConfigService);
    login(email: string, pass: string): Promise<{
        user: {
            id: any;
            first_name: any;
            last_name: any;
            email: any;
            mobile: any;
            address: string;
            is_callcenter: boolean;
            remember_token: string;
            menu_favoris: string;
            centers: any;
            employee: any;
        };
        token: string;
        refresh_token: string;
    }>;
    private generateTokens;
    getCurrentUser(userId: string): Promise<{
        id: any;
        first_name: any;
        last_name: any;
        email: any;
        mobile: any;
        address: string;
        is_callcenter: boolean;
        remember_token: string;
        menu_favoris: string;
        centers: any;
        employee: any;
    }>;
    private mapToCurrentUser;
    refreshToken(refreshToken: string): Promise<{
        token: string;
        refresh_token: string;
    }>;
}
