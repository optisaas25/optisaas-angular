export declare class CreateExpenseDto {
    date: string;
    montant: number;
    categorie: string;
    description?: string;
    modePaiement: string;
    statut: string;
    justificatifUrl?: string;
    reference?: string;
    dateEcheance?: string;
    centreId: string;
    factureFournisseurId?: string;
    creePar?: string;
    banque?: string;
    fournisseurId?: string;
    echeanceId?: string;
    employeeId?: string;
    bonLivraisonId?: string;
}
