export declare class ExpensesModule {
}
