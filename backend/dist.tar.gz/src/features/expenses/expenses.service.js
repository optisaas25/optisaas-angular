"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpensesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const date_utils_1 = require("../../shared/utils/date-utils");
let ExpensesService = class ExpensesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createExpenseDto) {
        const { reference, dateEcheance, fournisseurId, banque, ...data } = createExpenseDto;
        return this.prisma.$transaction(async (tx) => {
            let finalEcheanceId = createExpenseDto.echeanceId;
            if (!finalEcheanceId &&
                (data.modePaiement === 'CHEQUE' || data.modePaiement === 'LCN') &&
                dateEcheance) {
                const echeance = await tx.echeancePaiement.create({
                    data: {
                        type: data.modePaiement,
                        reference: reference,
                        dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(dateEcheance),
                        montant: data.montant,
                        statut: 'EN_ATTENTE',
                        banque: banque,
                    },
                });
                finalEcheanceId = echeance.id;
            }
            const factureFournisseurId = createExpenseDto
                .factureFournisseurId;
            const bonLivraisonId = createExpenseDto.bonLivraisonId;
            if (!finalEcheanceId &&
                factureFournisseurId &&
                data.statut === 'VALIDEE') {
                const pending = await tx.echeancePaiement.findFirst({
                    where: {
                        factureFournisseurId: factureFournisseurId,
                        statut: 'EN_ATTENTE',
                    },
                });
                if (pending) {
                    finalEcheanceId = pending.id;
                }
                else {
                    const newEch = await tx.echeancePaiement.create({
                        data: {
                            type: data.modePaiement,
                            reference: reference || 'Paiement',
                            dateEcheance: new Date(),
                            montant: data.montant,
                            statut: 'ENCAISSE',
                            banque: banque,
                            factureFournisseurId: factureFournisseurId,
                            dateEncaissement: new Date(),
                        },
                    });
                    finalEcheanceId = newEch.id;
                }
            }
            if (!finalEcheanceId && bonLivraisonId && data.statut === 'VALIDEE') {
                const pending = await tx.echeancePaiement.findFirst({
                    where: {
                        bonLivraisonId: bonLivraisonId,
                        statut: 'EN_ATTENTE',
                    },
                });
                if (pending) {
                    finalEcheanceId = pending.id;
                }
                else {
                    const newEch = await tx.echeancePaiement.create({
                        data: {
                            type: data.modePaiement,
                            reference: reference || 'Paiement BL',
                            dateEcheance: new Date(),
                            montant: data.montant,
                            statut: 'ENCAISSE',
                            banque: banque,
                            bonLivraisonId: bonLivraisonId,
                            dateEncaissement: new Date(),
                        },
                    });
                    finalEcheanceId = newEch.id;
                }
            }
            if (finalEcheanceId &&
                data.statut === 'VALIDEE' &&
                data.modePaiement !== 'CHEQUE' &&
                data.modePaiement !== 'LCN') {
                await tx.echeancePaiement.update({
                    where: { id: finalEcheanceId },
                    data: {
                        statut: 'ENCAISSE',
                        dateEncaissement: new Date(),
                        montant: data.montant,
                    },
                });
            }
            if (factureFournisseurId) {
                const facture = await tx.factureFournisseur.findUnique({
                    where: { id: factureFournisseurId },
                    include: { echeances: true },
                });
                if (facture) {
                    const activeEcheances = facture.echeances.filter((e) => e.statut !== 'ANNULE');
                    const totalPaidRaw = activeEcheances
                        .filter((e) => e.statut === 'ENCAISSE')
                        .reduce((sum, e) => sum + e.montant, 0);
                    const totalPaid = Math.round(totalPaidRaw * 100) / 100;
                    const roundedTotalTTC = Math.round(facture.montantTTC * 100) / 100;
                    let newStatus = 'EN_ATTENTE';
                    if (totalPaid >= roundedTotalTTC && roundedTotalTTC > 0) {
                        newStatus = 'PAYEE';
                    }
                    else if (totalPaid > 0) {
                        newStatus = 'PARTIELLE';
                    }
                    else {
                        const hasScheduled = activeEcheances.some((e) => e.type !== 'ESPECES' && e.statut === 'EN_ATTENTE');
                        newStatus = hasScheduled ? 'PARTIELLE' : 'EN_ATTENTE';
                    }
                    await tx.factureFournisseur.update({
                        where: { id: factureFournisseurId },
                        data: { statut: newStatus },
                    });
                }
            }
            if (bonLivraisonId) {
                const bl = await tx.bonLivraison.findUnique({
                    where: { id: bonLivraisonId },
                    include: { echeances: true },
                });
                if (bl) {
                    const activeEcheances = bl.echeances.filter((e) => e.statut !== 'ANNULE');
                    const totalPaidRaw = activeEcheances
                        .filter((e) => e.statut === 'ENCAISSE')
                        .reduce((sum, e) => sum + e.montant, 0);
                    const totalPaid = Math.round(totalPaidRaw * 100) / 100;
                    const roundedTotalTTC = Math.round(bl.montantTTC * 100) / 100;
                    let newStatus = 'EN_ATTENTE';
                    if (totalPaid >= roundedTotalTTC && roundedTotalTTC > 0) {
                        newStatus = 'PAYEE';
                    }
                    else if (totalPaid > 0) {
                        newStatus = 'PARTIELLE';
                    }
                    else {
                        const hasScheduled = activeEcheances.some((e) => e.type !== 'ESPECES' && e.statut === 'EN_ATTENTE');
                        newStatus = hasScheduled ? 'PARTIELLE' : 'EN_ATTENTE';
                    }
                    await tx.bonLivraison.update({
                        where: { id: bonLivraisonId },
                        data: { statut: newStatus },
                    });
                }
            }
            const expense = await tx.depense.create({
                data: {
                    ...data,
                    reference,
                    dateEcheance: (0, date_utils_1.normalizeToUTCNoon)(dateEcheance),
                    date: (0, date_utils_1.normalizeToUTCNoon)(data.date),
                    echeanceId: finalEcheanceId,
                    fournisseurId: fournisseurId || null,
                    factureFournisseurId: finalEcheanceId
                        ? null
                        : factureFournisseurId || null,
                    bonLivraisonId: finalEcheanceId ? null : bonLivraisonId || null,
                },
            });
            let targetCaisseTypes = [];
            if (data.modePaiement === 'ESPECES' || data.modePaiement === 'ESPECE') {
                targetCaisseTypes = ['DEPENSES', 'MIXTE', 'PRINCIPALE', 'SECONDAIRE'];
            }
            else if (data.modePaiement === 'VIREMENT' ||
                data.modePaiement === 'CHEQUE' ||
                data.modePaiement === 'CHÈQUE' ||
                data.modePaiement === 'LCN') {
                targetCaisseTypes = ['MIXTE', 'PRINCIPALE'];
            }
            if (targetCaisseTypes.length > 0) {
                const openJournees = await tx.journeeCaisse.findMany({
                    where: {
                        caisse: {
                            centreId: data.centreId,
                            type: { in: targetCaisseTypes },
                            statut: 'ACTIVE',
                        },
                        statut: 'OUVERTE',
                    },
                    include: { caisse: true },
                    orderBy: { createdAt: 'desc' },
                });
                const openSession = openJournees.find(j => j.caisse.type === 'DEPENSES') ||
                    openJournees.find(j => j.caisse.type === 'MIXTE') ||
                    openJournees[0];
                if (openSession) {
                    console.log(`[ExpensesService] Linked to caisse session ${openSession.id} (${openSession.caisse.nom})`);
                    let sufficientFunds = true;
                    if (data.modePaiement === 'ESPECES') {
                        const availableCash = (openSession.fondInitial || 0) +
                            (openSession.totalInterne || 0) +
                            (openSession.totalVentesEspeces || 0) -
                            (openSession.totalDepenses || 0);
                        console.log(`[ExpensesService] Checking funds for ${data.categorie}: Required=${data.montant}, Available=${availableCash} (Fond=${openSession.fondInitial}, Interne=${openSession.totalInterne}, Ventes=${openSession.totalVentesEspeces}, Depenses=${openSession.totalDepenses})`);
                        if (availableCash < data.montant)
                            sufficientFunds = false;
                    }
                    if (!sufficientFunds) {
                        await tx.demandeAlimentation.create({
                            data: {
                                montant: data.montant,
                                depenseId: expense.id,
                                journeeCaisseId: openSession.id,
                                statut: 'EN_ATTENTE',
                            },
                        });
                        await tx.depense.update({
                            where: { id: expense.id },
                            data: { statut: 'EN_ATTENTE_ALIMENTATION' },
                        });
                    }
                    else {
                        await tx.operationCaisse.create({
                            data: {
                                type: 'DECAISSEMENT',
                                typeOperation: 'INTERNE',
                                montant: data.montant,
                                moyenPaiement: data.modePaiement,
                                motif: `Dépense: ${data.categorie}`,
                                reference: expense.id,
                                utilisateur: data.creePar || 'Système',
                                journeeCaisseId: openSession.id,
                            },
                        });
                        if (data.modePaiement === 'ESPECES' || data.modePaiement === 'ESPECE') {
                            await tx.journeeCaisse.update({
                                where: { id: openSession.id },
                                data: {
                                    totalDepenses: { increment: data.montant },
                                },
                            });
                        }
                    }
                }
                else if (data.modePaiement === 'ESPECES' || data.modePaiement === 'ESPECE') {
                    throw new common_1.BadRequestException('Aucune caisse ouverte appropriée (DEPENSES/MIXTE) trouvée pour ce centre.');
                }
            }
            return expense;
        });
    }
    async findAll(centreId, startDate, endDate, page, limit) {
        const whereClause = {};
        if (centreId) {
            whereClause.centreId = centreId;
        }
        if (startDate && endDate) {
            whereClause.date = {
                gte: new Date(startDate),
                lte: new Date(endDate),
            };
        }
        const combinedWhere = {
            ...whereClause,
            factureFournisseurId: null,
            OR: [{ echeanceId: null }, { echeance: { factureFournisseurId: null } }],
        };
        const skip = page && limit ? (Number(page) - 1) * Number(limit) : undefined;
        const take = limit ? Number(limit) : 10;
        const [data, total] = await Promise.all([
            this.prisma.depense.findMany({
                where: combinedWhere,
                include: {
                    centre: { select: { nom: true } },
                    factureFournisseur: {
                        select: {
                            numeroFacture: true,
                            fournisseur: { select: { nom: true } },
                        },
                    },
                },
                orderBy: { date: 'desc' },
                skip,
                take,
            }),
            this.prisma.depense.count({ where: combinedWhere }),
        ]);
        return { data, total };
    }
    async findOne(id) {
        return this.prisma.depense.findUnique({
            where: { id },
            include: {
                factureFournisseur: true,
                centre: true,
            },
        });
    }
    async update(id, updateExpenseDto) {
        const allowedFields = [
            'date',
            'montant',
            'categorie',
            'description',
            'modePaiement',
            'statut',
            'justificatifUrl',
            'dateEcheance',
            'reference',
            'fournisseurId',
            'creeParId',
            'valideParId',
            'employeeId',
            'echeanceId',
            'factureFournisseurId',
        ];
        const data = {};
        for (const field of allowedFields) {
            if (updateExpenseDto[field] !== undefined) {
                if ((field === 'date' || field === 'dateEcheance') &&
                    updateExpenseDto[field]) {
                    data[field] = (0, date_utils_1.normalizeToUTCNoon)(updateExpenseDto[field]);
                }
                else if (field === 'montant' && updateExpenseDto[field] !== null) {
                    data[field] = Number(updateExpenseDto[field]);
                }
                else {
                    data[field] = updateExpenseDto[field];
                }
            }
        }
        console.log('📝 [ExpensesService.update] Id:', id, 'Payload:', JSON.stringify(data, null, 2));
        try {
            return await this.prisma.depense.update({
                where: { id },
                data,
            });
        }
        catch (error) {
            console.error('❌ [ExpensesService.update] Error:', error);
            throw error;
        }
    }
    async remove(id) {
        return this.prisma.depense.delete({
            where: { id },
        });
    }
};
exports.ExpensesService = ExpensesService;
exports.ExpensesService = ExpensesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ExpensesService);
//# sourceMappingURL=expenses.service.js.map