export declare class FichesModule {
}
