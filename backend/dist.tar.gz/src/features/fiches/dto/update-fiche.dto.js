"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateFicheDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_fiche_dto_1 = require("./create-fiche.dto");
class UpdateFicheDto extends (0, mapped_types_1.PartialType)(create_fiche_dto_1.CreateFicheDto) {
}
exports.UpdateFicheDto = UpdateFicheDto;
//# sourceMappingURL=update-fiche.dto.js.map