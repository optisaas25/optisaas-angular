export declare class CreateFicheDto {
    statut: string;
    type: string;
    dateLivraisonEstimee?: string;
    montantTotal?: number;
    montantPaye?: number;
    clientId: string;
    content?: any;
    montage?: any;
    verres?: any;
    monture?: any;
    ordonnance?: any;
    lentilles?: any;
    adaptation?: any;
    suggestions?: any;
    equipements?: any;
    [key: string]: any;
}
