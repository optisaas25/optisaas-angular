import { CreateFicheDto } from './create-fiche.dto';
declare const UpdateFicheDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateFicheDto>>;
export declare class UpdateFicheDto extends UpdateFicheDto_base {
}
export {};
