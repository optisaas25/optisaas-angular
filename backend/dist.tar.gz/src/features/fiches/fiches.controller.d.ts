import { FichesService } from './fiches.service';
import { CreateFicheDto } from './dto/create-fiche.dto';
import { UpdateFicheDto } from './dto/update-fiche.dto';
export declare class FichesController {
    private readonly fichesService;
    constructor(fichesService: FichesService);
    create(createFicheDto: CreateFicheDto): Promise<any>;
    findAll(clientId?: string, startDate?: string, all?: string): never[] | Promise<any[]>;
    findOne(id: string): Promise<any>;
    emailOrder(id: string): Promise<{
        success: boolean;
    }>;
    update(id: string, updateFicheDto: UpdateFicheDto): Promise<any>;
    remove(id: string): Promise<{
        id: string;
        numero: number;
        type: string;
        statut: string;
        clientId: string;
        dateCreation: Date;
        dateLivraisonEstimee: Date | null;
        montantTotal: number;
        montantPaye: number;
        content: import("@prisma/client/runtime/library").JsonValue;
    }>;
}
