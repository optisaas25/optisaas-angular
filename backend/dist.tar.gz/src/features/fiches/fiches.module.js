"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FichesModule = void 0;
const common_1 = require("@nestjs/common");
const fiches_service_1 = require("./fiches.service");
const fiches_controller_1 = require("./fiches.controller");
const factures_module_1 = require("../factures/factures.module");
const loyalty_module_1 = require("../loyalty/loyalty.module");
const notifications_module_1 = require("../notifications/notifications.module");
let FichesModule = class FichesModule {
};
exports.FichesModule = FichesModule;
exports.FichesModule = FichesModule = __decorate([
    (0, common_1.Module)({
        imports: [factures_module_1.FacturesModule, loyalty_module_1.LoyaltyModule, notifications_module_1.NotificationsModule],
        controllers: [fiches_controller_1.FichesController],
        providers: [fiches_service_1.FichesService],
    })
], FichesModule);
//# sourceMappingURL=fiches.module.js.map