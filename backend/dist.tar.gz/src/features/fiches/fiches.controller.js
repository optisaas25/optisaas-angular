"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FichesController = void 0;
const common_1 = require("@nestjs/common");
const fiches_service_1 = require("./fiches.service");
const create_fiche_dto_1 = require("./dto/create-fiche.dto");
const update_fiche_dto_1 = require("./dto/update-fiche.dto");
let FichesController = class FichesController {
    fichesService;
    constructor(fichesService) {
        this.fichesService = fichesService;
    }
    create(createFicheDto) {
        console.log('📥 Received fiche data:', JSON.stringify(createFicheDto, null, 2));
        return this.fichesService.create(createFicheDto);
    }
    findAll(clientId, startDate, all) {
        if (clientId) {
            return this.fichesService.findAllByClient(clientId, startDate);
        }
        if (all === 'true') {
            return this.fichesService.findAll(startDate);
        }
        return [];
    }
    findOne(id) {
        return this.fichesService.findOne(id);
    }
    async emailOrder(id) {
        console.log(`🔔 [FichesController] Received request to send email for Fiche ID: ${id}`);
        return this.fichesService.sendOrderEmail(id);
    }
    update(id, updateFicheDto) {
        return this.fichesService.update(id, updateFicheDto);
    }
    remove(id) {
        return this.fichesService.remove(id);
    }
};
exports.FichesController = FichesController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_fiche_dto_1.CreateFicheDto]),
    __metadata("design:returntype", void 0)
], FichesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('all')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], FichesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FichesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(':id/email-order'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FichesController.prototype, "emailOrder", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_fiche_dto_1.UpdateFicheDto]),
    __metadata("design:returntype", void 0)
], FichesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FichesController.prototype, "remove", null);
exports.FichesController = FichesController = __decorate([
    (0, common_1.Controller)('fiches'),
    __metadata("design:paramtypes", [fiches_service_1.FichesService])
], FichesController);
//# sourceMappingURL=fiches.controller.js.map