import { PrismaService } from '../../prisma/prisma.service';
import { Prisma } from '@prisma/client';
import { FacturesService } from '../factures/factures.service';
import { LoyaltyService } from '../loyalty/loyalty.service';
import { MailerService } from '../notifications/mailer.service';
import { PdfService } from '../notifications/pdf.service';
export declare class FichesService {
    private prisma;
    private facturesService;
    private loyaltyService;
    private mailerService;
    private pdfService;
    constructor(prisma: PrismaService, facturesService: FacturesService, loyaltyService: LoyaltyService, mailerService: MailerService, pdfService: PdfService);
    sendOrderEmail(id: string): Promise<{
        success: boolean;
    }>;
    create(data: Prisma.FicheCreateInput): Promise<any>;
    private validateRequiredFields;
    findAll(startDate?: string): Promise<any[]>;
    findAllByClient(clientId: string, startDate?: string): Promise<any[]>;
    findOne(id: string): Promise<any>;
    update(id: string, updateFicheDto: any): Promise<any>;
    remove(id: string): Promise<{
        id: string;
        numero: number;
        type: string;
        statut: string;
        clientId: string;
        dateCreation: Date;
        dateLivraisonEstimee: Date | null;
        montantTotal: number;
        montantPaye: number;
        content: Prisma.JsonValue;
    }>;
    private unpackContent;
}
