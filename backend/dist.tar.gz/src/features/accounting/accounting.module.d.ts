export declare class AccountingModule {
}
