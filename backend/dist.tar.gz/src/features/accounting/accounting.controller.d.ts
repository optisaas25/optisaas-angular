import { AccountingService } from './accounting.service';
import { ExportSageDto } from './dto/export-sage.dto';
import { Response } from 'express';
export declare class AccountingController {
    private accountingService;
    constructor(accountingService: AccountingService);
    exportSage(dto: ExportSageDto, res: Response): Promise<Response<any, Record<string, any>>>;
    exportPdf(dto: ExportSageDto, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    exportBalance(dto: ExportSageDto, res: Response): Promise<Response<any, Record<string, any>>>;
    exportBilan(dto: ExportSageDto, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
