export declare class ExportSageDto {
    startDate: string;
    endDate: string;
    centreId?: string;
}
