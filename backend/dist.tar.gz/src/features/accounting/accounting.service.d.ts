import { PrismaService } from '../../prisma/prisma.service';
import { ExportSageDto } from './dto/export-sage.dto';
export declare class AccountingService {
    private prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    private readonly CONFIG;
    private formatDateDDMMYY;
    private formatDateDisplay;
    generateSageExport(dto: ExportSageDto): Promise<string>;
    generateBalance(dto: ExportSageDto): Promise<{
        actif: {
            immobilisations: number;
            stock: number;
            creances: number;
            tresorerie: number;
            total: number;
        };
        passif: {
            capitaux: number;
            dettes: number;
            resultat: number;
            total: number;
        };
        exploitation: {
            chiffreAffaires: number;
            achats: number;
            resultat: number;
        };
        tva: {
            collectee: number;
            deductible: number;
            aPayer: number;
        };
    }>;
    generateJournalPdf(dto: ExportSageDto): Promise<any>;
    generateBilanComptable(dto: ExportSageDto): Promise<any>;
    generateTrialBalanceCsv(dto: ExportSageDto): Promise<string>;
    private generateJournalPdfLandscape;
}
