"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountingController = void 0;
const common_1 = require("@nestjs/common");
const accounting_service_1 = require("./accounting.service");
const export_sage_dto_1 = require("./dto/export-sage.dto");
let AccountingController = class AccountingController {
    accountingService;
    constructor(accountingService) {
        this.accountingService = accountingService;
    }
    async exportSage(dto, res) {
        try {
            const csv = await this.accountingService.generateSageExport(dto);
            const filename = `Sage_Export_${dto.startDate}_${dto.endDate}.csv`;
            res.set({
                'Content-Type': 'text/csv',
                'Content-Disposition': `attachment; filename="${filename}"`,
            });
            return res.send(csv);
        }
        catch (error) {
            console.error('Error in exportSage:', error);
            return res.status(500).json({
                message: "Erreur lors de la génération de l'export Sage",
                error: error.message,
            });
        }
    }
    async exportPdf(dto, res) {
        try {
            const doc = await this.accountingService.generateJournalPdf(dto);
            const filename = `Journal_Comptable_${dto.startDate}_${dto.endDate}.pdf`;
            res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${filename}"`,
            });
            doc.pipe(res);
        }
        catch (error) {
            console.error('Error in exportPdf:', error);
            return res.status(500).json({
                message: 'Erreur lors de la génération du PDF',
                error: error.message,
            });
        }
    }
    async exportBalance(dto, res) {
        try {
            const csv = await this.accountingService.generateTrialBalanceCsv(dto);
            const filename = `Balance_Comptable_${dto.startDate}_${dto.endDate}.csv`;
            res.set({
                'Content-Type': 'text/csv; charset=utf-8',
                'Content-Disposition': `attachment; filename="${filename}"`,
            });
            return res.send(csv);
        }
        catch (error) {
            console.error('Error in exportBalance:', error);
            return res.status(500).json({
                message: 'Erreur lors de la génération de la Balance',
                error: error.message,
            });
        }
    }
    async exportBilan(dto, res) {
        try {
            const doc = await this.accountingService.generateBilanComptable(dto);
            const filename = `Bilan_Comptable_${dto.startDate}_${dto.endDate}.pdf`;
            res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${filename}"`,
            });
            doc.pipe(res);
        }
        catch (error) {
            console.error('Error in exportBilan:', error);
            return res.status(500).json({
                message: 'Erreur lors de la génération du Bilan',
                error: error.message,
            });
        }
    }
};
exports.AccountingController = AccountingController;
__decorate([
    (0, common_1.Get)('export/sage'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [export_sage_dto_1.ExportSageDto, Object]),
    __metadata("design:returntype", Promise)
], AccountingController.prototype, "exportSage", null);
__decorate([
    (0, common_1.Get)('export/pdf'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [export_sage_dto_1.ExportSageDto, Object]),
    __metadata("design:returntype", Promise)
], AccountingController.prototype, "exportPdf", null);
__decorate([
    (0, common_1.Get)('export/balance'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [export_sage_dto_1.ExportSageDto, Object]),
    __metadata("design:returntype", Promise)
], AccountingController.prototype, "exportBalance", null);
__decorate([
    (0, common_1.Get)('export/bilan'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [export_sage_dto_1.ExportSageDto, Object]),
    __metadata("design:returntype", Promise)
], AccountingController.prototype, "exportBilan", null);
exports.AccountingController = AccountingController = __decorate([
    (0, common_1.Controller)('accounting'),
    __metadata("design:paramtypes", [accounting_service_1.AccountingService])
], AccountingController);
//# sourceMappingURL=accounting.controller.js.map