export declare class StatsModule {
}
