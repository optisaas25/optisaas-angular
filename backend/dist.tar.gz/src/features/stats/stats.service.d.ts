import { PrismaService } from '../../prisma/prisma.service';
export interface RevenueDataPoint {
    period: string;
    revenue: number;
    count: number;
}
export interface ProductDistribution {
    type: string;
    count: number;
    value: number;
}
export interface ConversionMetrics {
    totalDevis: number;
    validatedFactures: number;
    paidFactures: number;
    conversionToFacture: number;
    conversionToPaid: number;
}
export interface WarehouseStock {
    warehouseName: string;
    totalQuantity: number;
    totalValue: number;
    productCount: number;
    breakdown: {
        type: string;
        quantity: number;
        value: number;
    }[];
}
export interface TopClient {
    clientId: string;
    clientName: string;
    totalRevenue: number;
    invoiceCount: number;
}
export interface PaymentMethodStat {
    method: string;
    count: number;
    totalAmount: number;
}
export declare class StatsService {
    private prisma;
    private readonly INVENTORY_PURCHASE_TYPES;
    private readonly OPERATIONAL_PURCHASE_TYPES;
    private readonly ACTIVE_STATUSES;
    constructor(prisma: PrismaService);
    getRevenueEvolution(period: 'daily' | 'monthly' | 'yearly', startDate?: string, endDate?: string, centreId?: string): Promise<RevenueDataPoint[]>;
    getProductDistribution(startDate?: string, endDate?: string, centreId?: string): Promise<ProductDistribution[]>;
    getConversionRate(startDate?: string, endDate?: string, centreId?: string): Promise<ConversionMetrics>;
    getStockByWarehouse(startDate?: string, endDate?: string, centreId?: string): Promise<WarehouseStock[]>;
    getTopClients(limit: number, startDate?: string, endDate?: string, centreId?: string): Promise<TopClient[]>;
    getPaymentMethods(startDate?: string, endDate?: string, centreId?: string): Promise<PaymentMethodStat[]>;
    getSummary(startDate?: string, endDate?: string, centreId?: string): Promise<{
        totalProducts: number;
        totalClients: number;
        totalRevenue: number;
        totalExpenses: number;
        activeWarehouses: number;
        conversionRate: number;
        fichesStats: {
            total: number;
            monture: number;
            lentilles: number;
            produit: number;
        };
        productsStats: any;
    }>;
    getRealProfit(startDate?: string, endDate?: string, centreId?: string): Promise<{
        revenue: number;
        cogs: number;
        expenses: number;
        grossProfit: number;
        netProfit: number;
        expensesBreakdown: {
            category: string;
            amount: number;
            percentage: number;
        }[];
        cogsBreakdown: {
            category: string;
            amount: number;
            percentage: number;
        }[];
        analysis: {
            grossMarginRate: number;
            marginRate: number;
        };
    }>;
    getProfitEvolution(period?: 'daily' | 'monthly', startDate?: string, endDate?: string, centreId?: string): Promise<{
        month: string;
        revenue: number;
        expenses: number;
        cogs: number;
        netProfit: number;
    }[]>;
}
