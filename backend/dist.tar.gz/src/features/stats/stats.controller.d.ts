import { StatsService } from './stats.service';
import { PrismaService } from '../../prisma/prisma.service';
export declare class StatsController {
    private readonly statsService;
    private readonly prisma;
    constructor(statsService: StatsService, prisma: PrismaService);
    diagData(): Promise<{
        payments: {
            count: number;
            sum: number | null;
        };
        invoices: {
            count: number;
            sum: number | null;
        };
        timestamp: string;
    }>;
    getRevenueEvolution(period?: 'daily' | 'monthly' | 'yearly', startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").RevenueDataPoint[]>;
    getProductDistribution(startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").ProductDistribution[]>;
    getConversionRate(startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").ConversionMetrics>;
    getStockByWarehouse(startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").WarehouseStock[]>;
    getTopClients(limit?: number, startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").TopClient[]>;
    getPaymentMethods(startDate?: string, endDate?: string, centreId?: string): Promise<import("./stats.service").PaymentMethodStat[]>;
    getSummary(startDate?: string, endDate?: string, centreId?: string): Promise<{
        totalProducts: number;
        totalClients: number;
        totalRevenue: number;
        totalExpenses: number;
        activeWarehouses: number;
        conversionRate: number;
        fichesStats: {
            total: number;
            monture: number;
            lentilles: number;
            produit: number;
        };
        productsStats: any;
    }>;
    getRealProfit(startDate?: string, endDate?: string, centreId?: string): Promise<{
        revenue: number;
        cogs: number;
        expenses: number;
        grossProfit: number;
        netProfit: number;
        expensesBreakdown: {
            category: string;
            amount: number;
            percentage: number;
        }[];
        cogsBreakdown: {
            category: string;
            amount: number;
            percentage: number;
        }[];
        analysis: {
            grossMarginRate: number;
            marginRate: number;
        };
    }>;
    getProfitEvolution(period?: 'daily' | 'monthly', startDate?: string, endDate?: string, centreId?: string): Promise<{
        month: string;
        revenue: number;
        expenses: number;
        cogs: number;
        netProfit: number;
    }[]>;
}
