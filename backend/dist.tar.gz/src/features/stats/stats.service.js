"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const client_1 = require("@prisma/client");
let StatsService = class StatsService {
    prisma;
    INVENTORY_PURCHASE_TYPES = [
        'ACHAT VERRES OPTIQUES',
        'ACHAT MONTURES OPTIQUES',
        'ACHAT LENTILLES DE CONTACT',
        'ACHAT ACCESSOIRES OPTIQUES',
        'ACHAT_STOCK',
    ];
    OPERATIONAL_PURCHASE_TYPES = [
        'ELECTRICITE',
        'INTERNET',
        'ASSURANCE',
        'FRAIS BANCAIRES',
        'AUTRES CHARGES',
        'REGLEMENT CONSOMMATION EAU',
        'REGLEMENT SALAIRS OPTIQUES',
        'LOYER',
    ];
    ACTIVE_STATUSES = [
        'VALIDE',
        'VALIDEE',
        'VALIDÉ',
        'VALIDÉE',
        'PAYEE',
        'PAYÉ',
        'PAYÉE',
        'SOLDEE',
        'SOLDÉ',
        'SOLDÉE',
        'ENCAISSE',
        'ENCAISSÉ',
        'ENCAISSÉE',
        'PARTIEL',
        'BROUILLON',
        'ANNULEE',
    ];
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getRevenueEvolution(period, startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        let start = isValidDate(startDate) ? new Date(startDate) : undefined;
        let end = isValidDate(endDate) ? new Date(endDate) : undefined;
        if (!start || !end) {
            const range = await this.prisma.facture.aggregate({
                where: {
                    centreId: centreId || undefined,
                    statut: { notIn: ['ARCHIVE'] },
                    type: { in: ['FACTURE', 'BON_COMMANDE', 'AVOIR', 'DEVIS'] },
                },
                _min: { dateEmission: true },
                _max: { dateEmission: true },
            });
            if (!start)
                start = range._min.dateEmission || new Date(2024, 0, 1);
            if (!end)
                end = range._max.dateEmission || new Date();
        }
        const factures = await this.prisma.facture.findMany({
            where: {
                dateEmission: { gte: start, lte: end },
                centreId: centreId || undefined,
                statut: { notIn: ['ARCHIVE'] },
                type: { in: ['FACTURE', 'BON_COMMANDE', 'BON_COMM', 'AVOIR', 'DEVIS'] },
            },
            select: {
                dateEmission: true,
                totalTTC: true,
                type: true,
            },
        });
        const grouped = new Map();
        const formatKey = (date) => {
            switch (period) {
                case 'daily':
                    return date.toISOString().split('T')[0];
                case 'yearly':
                    return date.getFullYear().toString();
                case 'monthly':
                default:
                    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            }
        };
        const current = new Date(start);
        while (current <= end) {
            grouped.set(formatKey(current), { revenue: 0, count: 0 });
            if (period === 'daily')
                current.setDate(current.getDate() + 1);
            else if (period === 'monthly')
                current.setMonth(current.getMonth() + 1);
            else
                current.setFullYear(current.getFullYear() + 1);
        }
        factures.forEach((f) => {
            const date = new Date(f.dateEmission);
            const key = formatKey(date);
            const existing = grouped.get(key) || { revenue: 0, count: 0 };
            const amount = f.totalTTC || 0;
            const adjustedRevenue = f.type === 'AVOIR'
                ? existing.revenue - amount
                : existing.revenue + amount;
            grouped.set(key, {
                revenue: adjustedRevenue,
                count: existing.count + (f.type === 'AVOIR' ? 0 : 1),
            });
        });
        return Array.from(grouped.entries())
            .map(([period, data]) => ({ period, ...data }))
            .sort((a, b) => a.period.localeCompare(b.period));
    }
    async getProductDistribution(startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        const start = isValidDate(startDate) ? new Date(startDate) : new Date(0);
        const end = isValidDate(endDate)
            ? new Date(endDate)
            : new Date(3000, 0, 1);
        const factures = await this.prisma.facture.findMany({
            where: {
                dateEmission: { gte: start, lte: end },
                centreId: centreId || undefined,
                statut: { notIn: ['ARCHIVE'] },
                type: { in: ['FACTURE', 'BON_COMMANDE', 'DEVIS'] },
            },
            select: {
                lignes: true,
                fiche: { select: { type: true } }
            },
        });
        const distribution = new Map();
        factures.forEach((f) => {
            const lines = f.lignes || [];
            if (lines.length > 0) {
                lines.forEach((l) => {
                    const qty = l.qte ?? l.quantite ?? 0;
                    const price = l.prixUnitaireHT ?? l.prixUnitaireTTC ?? 0;
                    const lineTotal = l.totalHT ?? l.totalTTC ?? (qty * price);
                    let type = l.typeArticle;
                    if (!type && l.description) {
                        const desc = String(l.description).toLowerCase();
                        if (desc.includes('verre') || desc.includes('verres'))
                            type = 'VERRE';
                        else if (desc.includes('monture'))
                            type = 'MONTURE';
                        else if (desc.includes('lentille'))
                            type = 'LENTILLES';
                        else if (desc.includes('produit') || desc.includes('accessoire'))
                            type = 'ACCESSOIRE';
                    }
                    if (!type && f.fiche?.type) {
                        const ficheType = f.fiche.type.toLowerCase();
                        if (ficheType === 'monture')
                            type = 'MONTURE';
                        else if (ficheType === 'lentilles')
                            type = 'LENTILLES';
                    }
                    if (!type)
                        type = 'NON_DÉFINI';
                    const existing = distribution.get(type) || { count: 0, value: 0 };
                    distribution.set(type, {
                        count: existing.count + qty,
                        value: existing.value + lineTotal,
                    });
                });
            }
            else if (f.fiche && f.fiche.type) {
                const ficheType = f.fiche.type.toLowerCase();
                let type = 'NON_DÉFINI';
                if (ficheType === 'monture')
                    type = 'MONTURE';
                else if (ficheType === 'lentilles')
                    type = 'LENTILLES';
                const existing = distribution.get(type) || { count: 0, value: 0 };
                distribution.set(type, {
                    count: existing.count + 1,
                    value: existing.value,
                });
            }
        });
        return Array.from(distribution.entries())
            .map(([type, data]) => ({ type, ...data }))
            .sort((a, b) => b.value - a.value);
    }
    async getConversionRate(startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        const start = isValidDate(startDate) ? new Date(startDate) : new Date(0);
        const end = isValidDate(endDate)
            ? new Date(endDate)
            : new Date(3000, 0, 1);
        const whereClause = {
            dateEmission: { gte: start, lte: end },
            ...(centreId ? { centreId } : {}),
            statut: { notIn: ['ARCHIVE'] },
        };
        const totalDevis = await this.prisma.facture.count({
            where: {
                ...whereClause,
                type: { in: ['FACTURE', 'BON_COMMANDE', 'DEVIS'] },
            },
        });
        const validatedFactures = await this.prisma.facture.count({
            where: {
                ...whereClause,
                type: { in: ['FACTURE', 'BON_COMMANDE', 'DEVIS'] },
                paiements: { some: {} },
            },
        });
        const paidFactures = await this.prisma.facture.count({
            where: {
                ...whereClause,
                OR: [
                    { type: 'DEVIS' },
                    { type: 'BON_COMMANDE' },
                    { type: 'BON_COMM' },
                    { type: 'FACTURE' },
                    { numero: { startsWith: 'FAC' } },
                ],
                statut: { in: ['PAYEE', 'SOLDEE', 'ENCAISSE'] },
            },
        });
        return {
            totalDevis,
            validatedFactures,
            paidFactures,
            conversionToFacture: totalDevis > 0 ? (validatedFactures / totalDevis) * 100 : 0,
            conversionToPaid: totalDevis > 0 ? (paidFactures / totalDevis) * 100 : 0,
        };
    }
    async getStockByWarehouse(startDate, endDate, centreId) {
        const warehouses = await this.prisma.entrepot.findMany({
            where: centreId ? { centreId } : {},
            include: {
                produits: {
                    select: {
                        typeArticle: true,
                        quantiteActuelle: true,
                        prixAchatHT: true,
                        prixVenteHT: true,
                    },
                },
            },
        });
        return warehouses
            .map((w) => {
            const breakdownMap = new Map();
            w.produits.forEach((p) => {
                const type = p.typeArticle || 'NON_DÉFINI';
                const existing = breakdownMap.get(type) || { quantity: 0, value: 0 };
                breakdownMap.set(type, {
                    quantity: existing.quantity + (p.quantiteActuelle || 0),
                    value: existing.value + (p.quantiteActuelle || 0) * (p.prixAchatHT || 0),
                });
            });
            const breakdown = Array.from(breakdownMap.entries()).map(([type, data]) => ({
                type,
                quantity: data.quantity,
                value: data.value,
            }));
            const totalQuantity = w.produits.reduce((sum, p) => sum + (p.quantiteActuelle || 0), 0);
            const totalValue = w.produits.reduce((sum, p) => sum + (p.quantiteActuelle || 0) * (p.prixAchatHT || 0), 0);
            return {
                warehouseName: w.nom,
                totalQuantity,
                totalValue,
                productCount: w.produits.length,
                breakdown,
            };
        })
            .sort((a, b) => b.totalValue - a.totalValue);
    }
    async getTopClients(limit, startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        const start = isValidDate(startDate) ? new Date(startDate) : new Date(0);
        const end = isValidDate(endDate)
            ? new Date(endDate)
            : new Date(3000, 0, 1);
        const factures = await this.prisma.facture.findMany({
            where: {
                dateEmission: { gte: start, lte: end },
                centreId: centreId || undefined,
                statut: { notIn: ['ARCHIVE'] },
                type: { in: ['FACTURE', 'BON_COMMANDE', 'BON_COMM', 'AVOIR', 'DEVIS'] },
            },
            select: {
                clientId: true,
                totalTTC: true,
                client: {
                    select: {
                        nom: true,
                        prenom: true,
                        raisonSociale: true,
                    },
                },
            },
        });
        const clientMap = new Map();
        factures.forEach((f) => {
            const name = f.client.raisonSociale ||
                `${f.client.prenom || ''} ${f.client.nom || ''}`.trim();
            const existing = clientMap.get(f.clientId) || {
                name,
                revenue: 0,
                count: 0,
            };
            clientMap.set(f.clientId, {
                name: existing.name,
                revenue: existing.revenue + (f.totalTTC || 0),
                count: existing.count + 1,
            });
        });
        return Array.from(clientMap.entries())
            .map(([clientId, data]) => ({
            clientId,
            clientName: data.name,
            totalRevenue: data.revenue,
            invoiceCount: data.count,
        }))
            .sort((a, b) => b.totalRevenue - a.totalRevenue)
            .slice(0, limit);
    }
    async getPaymentMethods(startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        const start = isValidDate(startDate) ? new Date(startDate) : new Date(0);
        const end = isValidDate(endDate)
            ? new Date(endDate)
            : new Date(3000, 0, 1);
        const payments = await this.prisma.paiement.findMany({
            where: {
                date: { gte: start, lte: end },
                ...(centreId ? { facture: { centreId } } : {}),
            },
            select: {
                mode: true,
                montant: true,
            },
        });
        const methodMap = new Map();
        payments.forEach((p) => {
            const method = p.mode || 'NON_SPÉCIFIÉ';
            const existing = methodMap.get(method) || { count: 0, total: 0 };
            methodMap.set(method, {
                count: existing.count + 1,
                total: existing.total + (p.montant || 0),
            });
        });
        return Array.from(methodMap.entries())
            .map(([method, data]) => ({
            method,
            count: data.count,
            totalAmount: data.total,
        }))
            .sort((a, b) => b.totalAmount - a.totalAmount);
    }
    async getSummary(startDate, endDate, centreId) {
        const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
        const start = isValidDate(startDate) ? new Date(startDate) : undefined;
        const end = isValidDate(endDate) ? new Date(endDate) : undefined;
        const profitData = await this.getRealProfit(startDate, endDate, centreId);
        const [totalProducts, totalClients, activeWarehouses, fichesBreakdown, productsBreakdown,] = await Promise.all([
            this.prisma.product.count({
                where: centreId
                    ? {
                        entrepot: { centreId },
                    }
                    : {},
            }),
            this.prisma.client.count({
                where: centreId ? { centreId } : {},
            }),
            this.prisma.entrepot.count({ where: centreId ? { centreId } : {} }),
            this.prisma.fiche.groupBy({
                by: ['type'],
                where: {
                    client: centreId ? { centreId } : {},
                },
                _count: { _all: true },
            }),
            this.prisma.product.groupBy({
                by: ['typeArticle'],
                where: centreId
                    ? {
                        entrepot: { centreId },
                    }
                    : {},
                _count: { _all: true },
            }),
            this.prisma.client.groupBy({
                by: ['titre'],
                where: centreId ? { centreId } : {},
                _count: { _all: true },
            }),
        ]);
        const conversionMetrics = await this.getConversionRate(startDate, endDate, centreId);
        const fichesStats = {
            total: 0,
            monture: 0,
            lentilles: 0,
            produit: 0,
        };
        fichesBreakdown.forEach((group) => {
            const count = group._count._all;
            fichesStats.total += count;
            const type = group.type.toLowerCase();
            if (type === 'monture')
                fichesStats.monture += count;
            else if (type === 'lentilles')
                fichesStats.lentilles += count;
            else if (type === 'produit')
                fichesStats.produit += count;
        });
        const productsStats = {};
        productsBreakdown.forEach((group) => {
            const type = group.typeArticle || 'NON_DÉFINI';
            productsStats[type] = group._count?._all || 0;
        });
        return {
            totalProducts,
            totalClients,
            totalRevenue: profitData.revenue,
            totalExpenses: profitData.cogs + profitData.expenses,
            activeWarehouses,
            conversionRate: conversionMetrics.conversionToFacture,
            fichesStats,
            productsStats,
        };
    }
    async getRealProfit(startDate, endDate, centreId) {
        try {
            const tenantId = centreId &&
                centreId.trim() &&
                centreId !== 'undefined' &&
                centreId !== 'null' &&
                centreId !== ''
                ? centreId
                : undefined;
            let start;
            if (startDate &&
                startDate !== 'undefined' &&
                startDate !== 'null' &&
                startDate !== '') {
                start = new Date(startDate);
            }
            else {
                start = new Date(1970, 0, 1);
            }
            const end = endDate &&
                endDate !== 'undefined' &&
                endDate !== 'null' &&
                endDate !== ''
                ? new Date(endDate)
                : new Date(3000, 0, 1);
            console.log(`[STATS-PROFIT] Start: ${start.toISOString()}, End: ${end.toISOString()}, Tenant: ${tenantId}`);
            const revenueDocs = await this.prisma.facture.findMany({
                where: {
                    dateEmission: { gte: start, lte: end },
                    statut: { notIn: ['ARCHIVE'] },
                    type: { in: ['FACTURE', 'BON_COMMANDE', 'DEVIS', 'AVOIR'] },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                select: {
                    id: true,
                    totalHT: true,
                    totalTTC: true,
                    type: true,
                    lignes: true,
                    ficheId: true,
                },
            });
            let revenue = 0;
            revenueDocs.forEach((d) => {
                const val = d.totalTTC || d.totalHT || 0;
                if (d.type === 'AVOIR')
                    revenue -= val;
                else
                    revenue += val;
            });
            const cogsQuery = client_1.Prisma.sql `
                SELECT SUM(m."quantite" * COALESCE(m."prixAchatUnitaire", 0)) as total_cost
                FROM "MouvementStock" m
                JOIN "Facture" f ON m."factureId" = f."id"
                WHERE f."dateEmission" >= ${start}
                AND f."dateEmission" <= ${end}
                AND ( (f."numero" LIKE 'FAC%' OR f."type" IN ('FACTURE', 'BON_COMMANDE', 'DEVIS')) AND f."statut" != 'ARCHIVE' )
                ${tenantId ? client_1.Prisma.sql `AND f."centreId" = ${tenantId}` : client_1.Prisma.sql ``}
            `;
            const cogsResult = await this.prisma.$queryRaw(cogsQuery);
            let rawCogs = Math.abs(Number(cogsResult[0]?.total_cost || 0));
            const ficheIds = revenueDocs
                .map((d) => d.ficheId)
                .filter((id) => !!id && typeof id === 'string');
            if (ficheIds.length > 0) {
                const linkedBls = await this.prisma.factureFournisseur.aggregate({
                    where: {
                        ficheId: { in: ficheIds },
                    },
                    _sum: { montantTTC: true },
                });
                rawCogs += linkedBls?._sum?.montantTTC || 0;
            }
            if (rawCogs === 0) {
                const inventoryPurchaseTypes = [
                    'ACHAT VERRES OPTIQUES',
                    'ACHAT MONTURES OPTIQUES',
                    'ACHAT LENTILLES DE CONTACT',
                    'ACHAT ACCESSOIRES OPTIQUES',
                    'ACHAT_STOCK',
                ];
                const globalCogsAgg = await this.prisma.factureFournisseur.aggregate({
                    where: {
                        dateEmission: { gte: start, lte: end },
                        type: { in: inventoryPurchaseTypes },
                        ...(tenantId ? { centreId: tenantId } : {}),
                    },
                    _sum: { montantTTC: true },
                });
                rawCogs = globalCogsAgg._sum.montantTTC || 0;
            }
            const expensesAgg = await this.prisma.depense.aggregate({
                where: {
                    date: { gte: start, lte: end },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                _sum: { montant: true },
            });
            const operationalPurchaseTypes = [
                'REGLEMENT CONSOMMATION EAU',
                'REGLEMENT SALAIRS OPTIQUES',
                'LOYER',
                'ELECTRICITE',
                'INTERNET',
                'ASSURANCE',
                'FRAIS BANCAIRES',
                'AUTRES CHARGES',
            ];
            const purchaseExpensesAgg = await this.prisma.factureFournisseur.aggregate({
                where: {
                    dateEmission: { gte: start, lte: end },
                    OR: [
                        { type: { in: operationalPurchaseTypes } },
                        {
                            type: {
                                notIn: [
                                    'ACHAT VERRES OPTIQUES',
                                    'ACHAT MONTURES OPTIQUES',
                                    'ACHAT LENTILLES DE CONTACT',
                                    'ACHAT ACCESSOIRES OPTIQUES',
                                    'ACHAT_STOCK',
                                ],
                            },
                        },
                    ],
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                _sum: { montantTTC: true },
            });
            const totalExpenses = (expensesAgg._sum.montant || 0) +
                (purchaseExpensesAgg._sum.montantTTC || 0);
            const expenseBreakdown = await this.prisma.depense.groupBy({
                by: ['categorie'],
                where: {
                    date: { gte: start, lte: end },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                _sum: { montant: true },
            });
            const purchaseBreakdown = await this.prisma.factureFournisseur.groupBy({
                by: ['type'],
                where: {
                    dateEmission: { gte: start, lte: end },
                    OR: [
                        { type: { in: this.OPERATIONAL_PURCHASE_TYPES } },
                        {
                            type: {
                                notIn: this.INVENTORY_PURCHASE_TYPES,
                            },
                        },
                    ],
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                _sum: { montantTTC: true },
            });
            const inventoryPurchases = await this.prisma.factureFournisseur.findMany({
                where: {
                    dateEmission: { gte: start, lte: end },
                    type: { in: this.INVENTORY_PURCHASE_TYPES },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                select: { type: true, montantTTC: true },
            });
            const cogsMap = new Map();
            inventoryPurchases.forEach((p) => {
                const type = p.type || 'AUTRES STOCKS';
                cogsMap.set(type, (cogsMap.get(type) || 0) + (p.montantTTC || 0));
            });
            const formattedCogsBreakdown = Array.from(cogsMap.entries())
                .map(([category, amount]) => ({
                category,
                amount,
                percentage: rawCogs > 0 ? (amount / rawCogs) * 100 : 0,
            }))
                .sort((a, b) => b.amount - a.amount);
            const combinedBreakdownMap = new Map();
            expenseBreakdown.forEach((e) => combinedBreakdownMap.set(e.categorie || 'AUTRES', (combinedBreakdownMap.get(e.categorie || 'AUTRES') || 0) +
                (e._sum.montant || 0)));
            purchaseBreakdown.forEach((p) => combinedBreakdownMap.set(p.type || 'AUTRES PURCHASES', (combinedBreakdownMap.get(p.type || 'AUTRES PURCHASES') || 0) +
                (p._sum.montantTTC || 0)));
            const formattedBreakdown = Array.from(combinedBreakdownMap.entries())
                .map(([category, amount]) => ({
                category,
                amount,
                percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
            }))
                .sort((a, b) => b.amount - a.amount);
            const netProfit = revenue - rawCogs - totalExpenses;
            return {
                revenue,
                cogs: rawCogs,
                expenses: totalExpenses,
                grossProfit: revenue - rawCogs,
                netProfit,
                expensesBreakdown: formattedBreakdown,
                cogsBreakdown: formattedCogsBreakdown,
                analysis: {
                    grossMarginRate: revenue ? ((revenue - rawCogs) / revenue) * 100 : 0,
                    marginRate: revenue ? (netProfit / revenue) * 100 : 0,
                },
            };
        }
        catch (error) {
            console.error('[Stats-Profit] Critical Error in getRealProfit:', error);
            throw error;
        }
    }
    async getProfitEvolution(period = 'monthly', startDate, endDate, centreId) {
        console.log(`[StatsService] getProfitEvolution called with: period=${period}, start=${startDate}, end=${endDate}`);
        try {
            const tenantId = centreId &&
                centreId.trim() &&
                centreId !== 'undefined' &&
                centreId !== 'null' &&
                centreId !== ''
                ? centreId
                : undefined;
            const isValidDate = (d) => !!(d && d !== 'undefined' && d !== 'null' && d !== '');
            let start = isValidDate(startDate) ? new Date(startDate) : undefined;
            let end = isValidDate(endDate) ? new Date(endDate) : undefined;
            if (!start || !end) {
                const range = await this.prisma.facture.aggregate({
                    where: {
                        centreId: tenantId || undefined,
                        statut: { notIn: ['ARCHIVE'] },
                        type: { in: ['FACTURE', 'BON_COMMANDE', 'AVOIR', 'DEVIS'] },
                    },
                    _min: { dateEmission: true },
                    _max: { dateEmission: true },
                });
                if (!start) {
                    start = range._min.dateEmission || new Date(new Date().getFullYear(), 0, 1);
                    start.setHours(0, 0, 0, 0);
                }
                if (!end) {
                    end = range._max.dateEmission || new Date();
                    end.setHours(23, 59, 59, 999);
                }
            }
            console.log(`[StatsService] Final range for evolution: ${start.toISOString()} to ${end.toISOString()}`);
            const monthsMap = new Map();
            const formatKey = (date) => {
                if (period === 'daily') {
                    return date.toISOString().split('T')[0];
                }
                return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            };
            const current = new Date(start);
            while (current <= end) {
                monthsMap.set(formatKey(current), { revenue: 0, cogs: 0, expenses: 0 });
                if (period === 'daily') {
                    current.setDate(current.getDate() + 1);
                }
                else {
                    current.setMonth(current.getMonth() + 1);
                }
            }
            const factures = await this.prisma.facture.findMany({
                where: {
                    dateEmission: { gte: start, lte: end },
                    statut: { notIn: ['ARCHIVE'] },
                    type: { in: ['FACTURE', 'BON_COMMANDE', 'DEVIS', 'AVOIR'] },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
                select: { dateEmission: true, totalHT: true, totalTTC: true, type: true },
            });
            factures.forEach((f) => {
                const key = formatKey(f.dateEmission);
                if (!monthsMap.has(key))
                    return;
                const val = f.totalTTC || f.totalHT || 0;
                const entry = monthsMap.get(key);
                if (f.type === 'AVOIR')
                    entry.revenue -= val;
                else
                    entry.revenue += val;
            });
            const depenses = await this.prisma.depense.findMany({
                where: {
                    date: { gte: start, lte: end },
                    statut: { in: ['VALIDEE', 'VALIDÉ', 'PAYEE', 'PAYE'] },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
            });
            depenses.forEach((d) => {
                const key = formatKey(d.date);
                if (!monthsMap.has(key))
                    return;
                monthsMap.get(key).expenses += d.montant || 0;
            });
            const ff = await this.prisma.factureFournisseur.findMany({
                where: {
                    dateEmission: { gte: start, lte: end },
                    ...(tenantId ? { centreId: tenantId } : {}),
                },
            });
            ff.forEach((f) => {
                const key = formatKey(f.dateEmission);
                if (!monthsMap.has(key))
                    return;
                const entry = monthsMap.get(key);
                const isInventory = this.INVENTORY_PURCHASE_TYPES.includes(f.type || '');
                if (isInventory) {
                    entry.cogs += f.montantTTC || 0;
                }
                else {
                    entry.expenses += f.montantTTC || 0;
                }
            });
            const sortedResult = Array.from(monthsMap.entries())
                .map(([label, vals]) => ({
                month: label,
                revenue: vals.revenue,
                expenses: vals.cogs + vals.expenses,
                cogs: vals.cogs,
                netProfit: vals.revenue - (vals.cogs + vals.expenses),
            }))
                .sort((a, b) => a.month.localeCompare(b.month));
            console.log(`[StatsService] getProfitEvolution returning ${sortedResult.length} data points`);
            return sortedResult;
        }
        catch (error) {
            console.error('[Stats-Profit] Evolution Error:', error);
            throw error;
        }
    }
};
exports.StatsService = StatsService;
exports.StatsService = StatsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StatsService);
//# sourceMappingURL=stats.service.js.map