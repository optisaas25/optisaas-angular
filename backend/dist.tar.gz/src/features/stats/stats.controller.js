"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatsController = void 0;
const common_1 = require("@nestjs/common");
const stats_service_1 = require("./stats.service");
const prisma_service_1 = require("../../prisma/prisma.service");
let StatsController = class StatsController {
    statsService;
    prisma;
    constructor(statsService, prisma) {
        this.statsService = statsService;
        this.prisma = prisma;
    }
    async diagData() {
        const [pCount, pSum, fCount, fSum] = await Promise.all([
            this.prisma.paiement.count(),
            this.prisma.paiement.aggregate({ _sum: { montant: true } }),
            this.prisma.facture.count(),
            this.prisma.facture.aggregate({ _sum: { totalHT: true } }),
        ]);
        return {
            payments: { count: pCount, sum: pSum._sum.montant },
            invoices: { count: fCount, sum: fSum._sum.totalHT },
            timestamp: new Date().toISOString(),
        };
    }
    getRevenueEvolution(period = 'monthly', startDate, endDate, centreId) {
        return this.statsService.getRevenueEvolution(period, startDate, endDate, centreId);
    }
    getProductDistribution(startDate, endDate, centreId) {
        return this.statsService.getProductDistribution(startDate, endDate, centreId);
    }
    getConversionRate(startDate, endDate, centreId) {
        return this.statsService.getConversionRate(startDate, endDate, centreId);
    }
    getStockByWarehouse(startDate, endDate, centreId) {
        return this.statsService.getStockByWarehouse(startDate, endDate, centreId);
    }
    getTopClients(limit = 10, startDate, endDate, centreId) {
        return this.statsService.getTopClients(+limit, startDate, endDate, centreId);
    }
    getPaymentMethods(startDate, endDate, centreId) {
        return this.statsService.getPaymentMethods(startDate, endDate, centreId);
    }
    getSummary(startDate, endDate, centreId) {
        return this.statsService.getSummary(startDate, endDate, centreId);
    }
    getRealProfit(startDate, endDate, centreId) {
        return this.statsService.getRealProfit(startDate, endDate, centreId);
    }
    getProfitEvolution(period = 'monthly', startDate, endDate, centreId) {
        console.log(`[StatsController] Incoming getProfitEvolution: period=${period}, centreId=${centreId}, range=${startDate} to ${endDate}`);
        return this.statsService.getProfitEvolution(period, startDate, endDate, centreId);
    }
};
exports.StatsController = StatsController;
__decorate([
    (0, common_1.Get)('diag-data'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatsController.prototype, "diagData", null);
__decorate([
    (0, common_1.Get)('revenue-evolution'),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getRevenueEvolution", null);
__decorate([
    (0, common_1.Get)('product-distribution'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getProductDistribution", null);
__decorate([
    (0, common_1.Get)('conversion-rate'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getConversionRate", null);
__decorate([
    (0, common_1.Get)('stock-by-warehouse'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getStockByWarehouse", null);
__decorate([
    (0, common_1.Get)('top-clients'),
    __param(0, (0, common_1.Query)('limit')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getTopClients", null);
__decorate([
    (0, common_1.Get)('payment-methods'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getPaymentMethods", null);
__decorate([
    (0, common_1.Get)('summary'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getSummary", null);
__decorate([
    (0, common_1.Get)('profit'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getRealProfit", null);
__decorate([
    (0, common_1.Get)('profit-evolution'),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], StatsController.prototype, "getProfitEvolution", null);
exports.StatsController = StatsController = __decorate([
    (0, common_1.Controller)('stats'),
    __metadata("design:paramtypes", [stats_service_1.StatsService,
        prisma_service_1.PrismaService])
], StatsController);
//# sourceMappingURL=stats.controller.js.map