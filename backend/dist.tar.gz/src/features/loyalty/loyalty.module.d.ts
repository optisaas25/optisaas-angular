export declare class LoyaltyModule {
}
