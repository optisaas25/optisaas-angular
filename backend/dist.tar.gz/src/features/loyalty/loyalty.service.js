"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoyaltyService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let LoyaltyService = class LoyaltyService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getPointsHistory(clientId) {
        return this.prisma.pointsHistory.findMany({
            where: { clientId },
            orderBy: { date: 'desc' },
            include: { facture: true },
        });
    }
    async getPointsBalance(clientId) {
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { pointsFidelite: true },
        });
        return client?.pointsFidelite || 0;
    }
    async getConfig() {
        let config = await this.prisma.loyaltyConfig.findFirst();
        if (!config) {
            config = await this.prisma.loyaltyConfig.create({
                data: {
                    pointsPerDH: 0.1,
                    referrerBonus: 50,
                    refereeBonus: 20,
                    folderCreationBonus: 30,
                    rewardThreshold: 500,
                    pointsToMADRatio: 0.1,
                },
            });
        }
        return config;
    }
    async updateConfig(data) {
        const config = await this.getConfig();
        return this.prisma.loyaltyConfig.update({
            where: { id: config.id },
            data: {
                pointsPerDH: data.pointsPerDH !== undefined
                    ? parseFloat(data.pointsPerDH)
                    : config.pointsPerDH,
                referrerBonus: data.referrerBonus !== undefined
                    ? parseInt(data.referrerBonus)
                    : config.referrerBonus,
                refereeBonus: data.refereeBonus !== undefined
                    ? parseInt(data.refereeBonus)
                    : config.refereeBonus,
                folderCreationBonus: data.folderCreationBonus !== undefined
                    ? parseInt(data.folderCreationBonus)
                    : config.folderCreationBonus,
                rewardThreshold: data.rewardThreshold !== undefined
                    ? parseInt(data.rewardThreshold)
                    : config.rewardThreshold,
                pointsToMADRatio: data.pointsToMADRatio !== undefined
                    ? parseFloat(data.pointsToMADRatio)
                    : config.pointsToMADRatio,
            },
        });
    }
    async awardPointsForPurchase(factureId, tx) {
        const prisma = tx || this.prisma;
        const existingAward = await prisma.pointsHistory.findFirst({
            where: { factureId, type: 'EARN' },
        });
        if (existingAward)
            return;
        const facture = await prisma.facture.findUnique({
            where: { id: factureId },
            include: { client: true },
        });
        if (!facture || !facture.client)
            return;
        if (facture.client.conventionId) {
            console.log(`ℹ️ Client ${facture.client.id} has a convention. Skipping Fidelio points.`);
            return;
        }
        const config = (await this.getConfig());
        const points = Math.floor(facture.totalTTC * config.pointsPerDH);
        if (points <= 0)
            return;
        const typeLabel = facture.type === 'FACTURE' ? 'facture' : 'bon de commande';
        if (tx) {
            await tx.client.update({
                where: { id: facture.clientId },
                data: { pointsFidelite: { increment: points } },
            });
            await tx.pointsHistory.create({
                data: {
                    clientId: facture.clientId,
                    factureId: facture.id,
                    points: points,
                    type: 'EARN',
                    description: `Achat ${typeLabel} ${facture.numero}`,
                },
            });
            return;
        }
        return this.prisma.$transaction([
            this.prisma.client.update({
                where: { id: facture.clientId },
                data: { pointsFidelite: { increment: points } },
            }),
            this.prisma.pointsHistory.create({
                data: {
                    clientId: facture.clientId,
                    factureId: facture.id,
                    points: points,
                    type: 'EARN',
                    description: `Achat ${typeLabel} ${facture.numero}`,
                },
            }),
        ]);
    }
    async awardReferralBonus(referrerId, refereeId) {
        const existingBonus = await this.prisma.pointsHistory.findFirst({
            where: {
                clientId: referrerId,
                type: 'REFERRAL',
                description: { contains: refereeId },
            },
        });
        if (existingBonus)
            return;
        const config = (await this.getConfig());
        return this.prisma.$transaction([
            this.prisma.client.update({
                where: { id: referrerId },
                data: { pointsFidelite: { increment: config.referrerBonus } },
            }),
            this.prisma.pointsHistory.create({
                data: {
                    clientId: referrerId,
                    points: config.referrerBonus,
                    type: 'REFERRAL',
                    description: `Parrainage client ${refereeId}`,
                },
            }),
            this.prisma.client.update({
                where: { id: refereeId },
                data: { pointsFidelite: { increment: config.refereeBonus } },
            }),
            this.prisma.pointsHistory.create({
                data: {
                    clientId: refereeId,
                    points: config.refereeBonus,
                    type: 'REFERRAL',
                    description: `Bonus filleul`,
                },
            }),
        ]);
    }
    async spendPoints(clientId, points, description, factureId, tx) {
        const pts = Math.floor(points);
        if (pts === 0)
            return;
        console.log(`🎯 [LoyaltyService] spendPoints | client: ${clientId}, points: ${pts}, facture: ${factureId} | description: ${description}`);
        const client = tx || this.prisma;
        const updateClient = client.client.update({
            where: { id: clientId },
            data: { pointsFidelite: { decrement: pts } },
        });
        const createHistory = client.pointsHistory.create({
            data: {
                clientId,
                factureId,
                points: -pts,
                type: 'SPEND',
                description,
            },
        });
        if (tx) {
            await updateClient;
            await createHistory;
            return;
        }
        return this.prisma.$transaction([updateClient, createHistory]);
    }
    async awardPointsForFolderCreation(clientId, ficheId) {
        console.log(`💎 Awarding points for folder: client ${clientId}, fiche ${ficheId}`);
        const existingAward = await this.prisma.pointsHistory.findFirst({
            where: {
                clientId,
                type: 'FOLDER_CREATION',
                description: { contains: ficheId },
            },
        });
        if (existingAward) {
            console.log('ℹ️ Points already awarded for this folder. Skipping.');
            return;
        }
        const client = await this.prisma.client.findUnique({ where: { id: clientId } });
        if (!client)
            return;
        if (client.conventionId) {
            console.log(`ℹ️ Client ${clientId} has a convention. Skipping folder creation points.`);
            return;
        }
        const config = (await this.getConfig());
        console.log('⚙️ Loyalty config found:', config);
        if (!config.folderCreationBonus || config.folderCreationBonus <= 0) {
            console.log('ℹ️ folderCreationBonus is 0 or less. Skipping award.');
            return;
        }
        console.log(`✨ Incrementing points by ${config.folderCreationBonus} for client ${clientId}`);
        return this.prisma.$transaction([
            this.prisma.client.update({
                where: { id: clientId },
                data: { pointsFidelite: { increment: config.folderCreationBonus } },
            }),
            this.prisma.pointsHistory.create({
                data: {
                    clientId: clientId,
                    points: config.folderCreationBonus,
                    type: 'FOLDER_CREATION',
                    description: `Création dossier médical fiche ${ficheId}`,
                },
            }),
        ]);
    }
    async checkRewardEligibility(clientId) {
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { pointsFidelite: true },
        });
        if (!client) {
            throw new Error('Client not found');
        }
        const config = (await this.getConfig());
        const threshold = config.rewardThreshold || 500;
        return {
            eligible: client.pointsFidelite >= threshold,
            currentPoints: client.pointsFidelite,
            threshold: threshold,
            madValue: Math.floor(client.pointsFidelite * (config.pointsToMADRatio || 0.1)),
        };
    }
    async redeemReward(clientId, rewardType, redeemedBy) {
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { pointsFidelite: true },
        });
        if (!client) {
            throw new Error('Client not found');
        }
        const config = (await this.getConfig());
        const threshold = config.rewardThreshold || 500;
        if (client.pointsFidelite < threshold) {
            throw new Error(`Points insuffisants. Minimum requis: ${threshold} points`);
        }
        const pointsUsed = client.pointsFidelite;
        const madValue = Math.floor(pointsUsed * (config.pointsToMADRatio || 0.1));
        const result = await this.prisma.$transaction(async (tx) => {
            const redemption = await tx.rewardRedemption.create({
                data: {
                    clientId,
                    pointsUsed,
                    rewardType,
                    madValue,
                    redeemedBy,
                },
            });
            await tx.pointsHistory.create({
                data: {
                    clientId,
                    points: -pointsUsed,
                    type: 'SPEND',
                    description: `Échange récompense: ${rewardType === 'DISCOUNT' ? 'Remise' : 'Bonus MAD'} (${madValue} MAD)`,
                },
            });
            await tx.client.update({
                where: { id: clientId },
                data: { pointsFidelite: 0 },
            });
            const oldestUnpaidInvoice = await tx.facture.findFirst({
                where: {
                    clientId: clientId,
                    statut: { notIn: ['PAYEE', 'ANNULEE'] },
                    resteAPayer: { gt: 0 },
                },
                orderBy: { dateEmission: 'asc' },
            });
            if (oldestUnpaidInvoice && typeof oldestUnpaidInvoice.resteAPayer === 'number') {
                const montantAReduire = Math.min(redemption.madValue, oldestUnpaidInvoice.resteAPayer);
                const nouveauReste = oldestUnpaidInvoice.resteAPayer - montantAReduire;
                const newStatut = nouveauReste <= 0.05 ? 'PAYEE' : 'PARTIEL';
                const paiement = await tx.paiement.create({
                    data: {
                        factureId: oldestUnpaidInvoice.id,
                        montant: montantAReduire,
                        mode: 'FIDELIO',
                        date: new Date(),
                        reference: 'BONUS_FIDELIO',
                        notes: `Application immédiate prime de fidélité.`,
                    }
                });
                await tx.rewardRedemption.update({
                    where: { id: redemption.id },
                    data: {
                        isUsed: true,
                        paiementId: paiement.id
                    }
                });
                await tx.facture.update({
                    where: { id: oldestUnpaidInvoice.id },
                    data: {
                        resteAPayer: nouveauReste,
                        statut: oldestUnpaidInvoice.statut === 'BROUILLON' ? 'BROUILLON' : newStatut
                    }
                });
                console.log(`✅ [Loyalty] Applied ${montantAReduire} MAD Fidelio reward immediately to invoice ${oldestUnpaidInvoice.numero}`);
            }
            return redemption;
        });
        return result;
    }
    async getRedemptionHistory(clientId) {
        return this.prisma.rewardRedemption.findMany({
            where: { clientId },
            orderBy: { redeemedAt: 'desc' },
        });
    }
};
exports.LoyaltyService = LoyaltyService;
exports.LoyaltyService = LoyaltyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], LoyaltyService);
//# sourceMappingURL=loyalty.service.js.map