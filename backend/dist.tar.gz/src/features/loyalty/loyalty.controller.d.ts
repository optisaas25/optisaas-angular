import { LoyaltyService } from './loyalty.service';
export declare class LoyaltyController {
    private readonly loyaltyService;
    constructor(loyaltyService: LoyaltyService);
    getPointsHistory(clientId: string): Promise<({
        facture: {
            id: string;
            numero: string;
            type: string;
            dateEmission: Date;
            dateEcheance: Date | null;
            statut: string;
            clientId: string;
            ficheId: string | null;
            totalHT: number;
            totalTVA: number;
            totalTTC: number;
            resteAPayer: number;
            lignes: import("@prisma/client/runtime/library").JsonValue;
            proprietes: import("@prisma/client/runtime/library").JsonValue | null;
            parentFactureId: string | null;
            montantLettres: string | null;
            notes: string | null;
            createdAt: Date;
            updatedAt: Date;
            centreId: string | null;
            exportComptable: boolean;
            typeOperation: string;
            vendeurId: string | null;
        } | null;
    } & {
        id: string;
        type: string;
        clientId: string;
        createdAt: Date;
        date: Date;
        factureId: string | null;
        description: string | null;
        points: number;
    })[]>;
    getPointsBalance(clientId: string): Promise<number>;
    spendPoints(body: {
        clientId: string;
        points: number;
        description: string;
    }): Promise<[any, any] | undefined>;
    getConfig(): Promise<{
        id: string;
        updatedAt: Date;
        pointsPerDH: number;
        referrerBonus: number;
        refereeBonus: number;
        folderCreationBonus: number;
        pointsToMADRatio: number;
        rewardThreshold: number;
    }>;
    updateConfig(body: any): Promise<{
        id: string;
        updatedAt: Date;
        pointsPerDH: number;
        referrerBonus: number;
        refereeBonus: number;
        folderCreationBonus: number;
        pointsToMADRatio: number;
        rewardThreshold: number;
    }>;
    checkEligibility(clientId: string): Promise<{
        eligible: boolean;
        currentPoints: number;
        threshold: any;
        madValue: number;
    }>;
    redeemReward(body: {
        clientId: string;
        rewardType: 'DISCOUNT' | 'MAD_BONUS';
        redeemedBy?: string;
    }): Promise<{
        id: string;
        clientId: string;
        userId: string | null;
        paiementId: string | null;
        pointsUsed: number;
        rewardType: string;
        madValue: number;
        redeemedAt: Date;
        redeemedBy: string | null;
        isUsed: boolean;
    }>;
    getRedemptions(clientId: string): Promise<{
        id: string;
        clientId: string;
        userId: string | null;
        paiementId: string | null;
        pointsUsed: number;
        rewardType: string;
        madValue: number;
        redeemedAt: Date;
        redeemedBy: string | null;
        isUsed: boolean;
    }[]>;
}
