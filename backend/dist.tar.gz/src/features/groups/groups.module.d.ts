export declare class GroupsModule {
}
