"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let GroupsService = class GroupsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createGroupeDto) {
        return this.prisma.groupe.create({
            data: createGroupeDto,
            include: {
                centres: true,
            },
        });
    }
    async findAll(type) {
        const where = {};
        if (type)
            where.type = type;
        return this.prisma.groupe.findMany({
            where,
            include: {
                centres: {
                    include: {
                        entrepots: true,
                    },
                },
            },
        });
    }
    async findOne(id) {
        const groupe = await this.prisma.groupe.findUnique({
            where: { id },
            include: {
                centres: {
                    include: {
                        entrepots: true,
                    },
                },
            },
        });
        if (!groupe) {
            throw new common_1.NotFoundException(`Groupe with ID ${id} not found`);
        }
        return groupe;
    }
    async update(id, updateGroupeDto) {
        try {
            return await this.prisma.groupe.update({
                where: { id },
                data: updateGroupeDto,
                include: {
                    centres: true,
                },
            });
        }
        catch {
            throw new common_1.NotFoundException(`Groupe with ID ${id} not found`);
        }
    }
    async remove(id) {
        try {
            await this.prisma.groupe.delete({
                where: { id },
            });
            return { message: `Groupe with ID ${id} deleted successfully` };
        }
        catch {
            throw new common_1.NotFoundException(`Groupe with ID ${id} not found`);
        }
    }
};
exports.GroupsService = GroupsService;
exports.GroupsService = GroupsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], GroupsService);
//# sourceMappingURL=groups.service.js.map