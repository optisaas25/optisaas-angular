import { PrismaService } from '../../prisma/prisma.service';
import { CreateGroupeDto } from './dto/create-groupe.dto';
import { UpdateGroupeDto } from './dto/update-groupe.dto';
export declare class GroupsService {
    private prisma;
    constructor(prisma: PrismaService);
    create(createGroupeDto: CreateGroupeDto): Promise<{
        centres: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        }[];
    } & {
        id: string;
        type: string | null;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
    }>;
    findAll(type?: string): Promise<({
        centres: ({
            entrepots: {
                id: string;
                type: string;
                createdAt: Date;
                updatedAt: Date;
                centreId: string;
                nom: string;
                description: string | null;
                capaciteMax: number | null;
                surface: number | null;
                responsable: string | null;
            }[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        })[];
    } & {
        id: string;
        type: string | null;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
    })[]>;
    findOne(id: string): Promise<{
        centres: ({
            entrepots: {
                id: string;
                type: string;
                createdAt: Date;
                updatedAt: Date;
                centreId: string;
                nom: string;
                description: string | null;
                capaciteMax: number | null;
                surface: number | null;
                responsable: string | null;
            }[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        })[];
    } & {
        id: string;
        type: string | null;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
    }>;
    update(id: string, updateGroupeDto: UpdateGroupeDto): Promise<{
        centres: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        }[];
    } & {
        id: string;
        type: string | null;
        createdAt: Date;
        updatedAt: Date;
        nom: string;
        description: string | null;
        adresse: string | null;
        telephone: string | null;
        email: string | null;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
