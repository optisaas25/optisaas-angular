import { CreateGroupeDto } from './create-groupe.dto';
declare const UpdateGroupeDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateGroupeDto>>;
export declare class UpdateGroupeDto extends UpdateGroupeDto_base {
}
export {};
