export declare class CreateGroupeDto {
    nom: string;
    description?: string;
    adresse?: string;
    telephone?: string;
    email?: string;
    type?: string;
}
