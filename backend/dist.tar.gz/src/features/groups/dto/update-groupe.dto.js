"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateGroupeDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_groupe_dto_1 = require("./create-groupe.dto");
class UpdateGroupeDto extends (0, mapped_types_1.PartialType)(create_groupe_dto_1.CreateGroupeDto) {
}
exports.UpdateGroupeDto = UpdateGroupeDto;
//# sourceMappingURL=update-groupe.dto.js.map