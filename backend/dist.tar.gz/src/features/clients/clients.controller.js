"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsController = void 0;
const common_1 = require("@nestjs/common");
const clients_service_1 = require("./clients.service");
const create_client_dto_1 = require("./dto/create-client.dto");
const update_client_dto_1 = require("./dto/update-client.dto");
let ClientsController = class ClientsController {
    clientsService;
    constructor(clientsService) {
        this.clientsService = clientsService;
    }
    async create(createClientDto, centreId) {
        console.log('📥 CREATE Incoming payload:', JSON.stringify(createClientDto, null, 2));
        if (centreId) {
            createClientDto.centreId = centreId;
        }
        try {
            console.log('🔄 Processed CREATE DTO:', JSON.stringify(createClientDto, null, 2));
            return await this.clientsService.create(createClientDto);
        }
        catch (error) {
            console.error('❌ CREATE CLIENT ERROR:', error);
            throw error;
        }
    }
    findAll(nom, centreId) {
        return this.clientsService.findAll(nom, centreId);
    }
    search(typeClient, statut, nom, prenom, telephone, cin, groupeFamille, fidelioEligible, centreId) {
        return this.clientsService.search({
            typeClient,
            statut,
            nom,
            prenom,
            telephone,
            cin,
            groupeFamille,
            fidelioEligible,
            centreId,
        });
    }
    findOne(id) {
        return this.clientsService.findOne(id);
    }
    async update(id, updateClientDto) {
        console.log('📥 UPDATE Incoming payload:', JSON.stringify(updateClientDto, null, 2));
        try {
            console.log('🔄 Processed UPDATE DTO:', JSON.stringify(updateClientDto, null, 2));
            return await this.clientsService.update(id, updateClientDto);
        }
        catch (error) {
            console.error('❌ UPDATE CLIENT ERROR:', error);
            throw error;
        }
    }
    remove(id) {
        return this.clientsService.remove(id);
    }
};
exports.ClientsController = ClientsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_client_dto_1.CreateClientDto, String]),
    __metadata("design:returntype", Promise)
], ClientsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('nom')),
    __param(1, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('search'),
    __param(0, (0, common_1.Query)('typeClient')),
    __param(1, (0, common_1.Query)('statut')),
    __param(2, (0, common_1.Query)('nom')),
    __param(3, (0, common_1.Query)('prenom')),
    __param(4, (0, common_1.Query)('telephone')),
    __param(5, (0, common_1.Query)('cin')),
    __param(6, (0, common_1.Query)('groupeFamille')),
    __param(7, (0, common_1.Query)('fidelioEligible')),
    __param(8, (0, common_1.Headers)('Tenant')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "search", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_dto_1.UpdateClientDto]),
    __metadata("design:returntype", Promise)
], ClientsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "remove", null);
exports.ClientsController = ClientsController = __decorate([
    (0, common_1.Controller)('clients'),
    __metadata("design:paramtypes", [clients_service_1.ClientsService])
], ClientsController);
//# sourceMappingURL=clients.controller.js.map