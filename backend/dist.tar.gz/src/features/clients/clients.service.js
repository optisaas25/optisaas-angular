"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const loyalty_service_1 = require("../loyalty/loyalty.service");
let ClientsService = class ClientsService {
    prisma;
    loyaltyService;
    constructor(prisma, loyaltyService) {
        this.prisma = prisma;
        this.loyaltyService = loyaltyService;
    }
    async create(createClientDto) {
        const centreId = createClientDto.centreId;
        if (centreId) {
            const centreExists = await this.prisma.centre.findUnique({
                where: { id: centreId },
            });
            if (!centreExists) {
                throw new common_1.BadRequestException(`Centre non trouvé (${centreId}). Votre session est peut-être obsolète. Veuillez vous déconnecter et vous reconnecter pour rafraîchir vos accès.`);
            }
        }
        const client = await this.prisma.client.create({
            data: createClientDto,
        });
        if (client.parrainId) {
            await this.loyaltyService.awardReferralBonus(client.parrainId, client.id);
        }
        return client;
    }
    async findAll(nom, centreId) {
        const whereClause = {};
        if (!centreId)
            return [];
        whereClause.centreId = centreId;
        if (nom) {
            whereClause.OR = [
                { nom: { contains: nom, mode: 'insensitive' } },
                { prenom: { contains: nom, mode: 'insensitive' } },
                { raisonSociale: { contains: nom, mode: 'insensitive' } },
                { numeroPieceIdentite: { contains: nom, mode: 'insensitive' } },
            ];
        }
        return this.prisma.client.findMany({
            where: whereClause,
            orderBy: { dateCreation: 'desc' },
            include: {
                centre: true,
            },
        });
    }
    async search(filters) {
        const whereClause = {};
        if (!filters.centreId)
            return [];
        whereClause.centreId = filters.centreId;
        if (filters.typeClient) {
            whereClause.typeClient = filters.typeClient;
        }
        if (filters.statut) {
            whereClause.statut = filters.statut;
        }
        if (filters.nom) {
            whereClause.OR = [
                { nom: { contains: filters.nom, mode: 'insensitive' } },
                { raisonSociale: { contains: filters.nom, mode: 'insensitive' } },
            ];
        }
        if (filters.prenom) {
            whereClause.prenom = { contains: filters.prenom, mode: 'insensitive' };
        }
        if (filters.telephone) {
            whereClause.telephone = { contains: filters.telephone };
        }
        if (filters.cin) {
            whereClause.numeroPieceIdentite = {
                contains: filters.cin,
                mode: 'insensitive',
            };
        }
        if (filters.fidelioEligible === 'true') {
            const config = await this.loyaltyService.getConfig();
            const threshold = config?.rewardThreshold || 500;
            whereClause.pointsFidelite = { gte: threshold };
        }
        if (filters.groupeFamille) {
            whereClause.groupe = {
                nom: { contains: filters.groupeFamille, mode: 'insensitive' },
            };
        }
        return this.prisma.client.findMany({
            where: whereClause,
            orderBy: { dateCreation: 'desc' },
            include: {
                centre: true,
                groupe: true,
                conventionData: true,
            },
        });
    }
    async findOne(id) {
        return this.prisma.client.findUnique({
            where: { id },
            include: {
                fiches: {
                    orderBy: { dateCreation: 'desc' }
                },
                bonsLivraison: {
                    orderBy: { dateEmission: 'desc' }
                },
                facturesFournisseurs: {
                    orderBy: { dateEmission: 'desc' }
                },
                parrain: true,
                filleuls: true,
                groupe: true,
                conventionData: true,
                pointsHistory: {
                    include: { facture: true },
                    orderBy: { date: 'desc' },
                },
            },
        });
    }
    async update(id, updateClientDto) {
        return this.prisma.client.update({
            where: { id },
            data: updateClientDto,
        });
    }
    async remove(id) {
        const clientValidInvoices = await this.prisma.facture.findMany({
            where: {
                clientId: id,
                statut: { in: ['VALIDE', 'PAYEE', 'PARTIEL'] },
            },
            orderBy: { numero: 'desc' },
        });
        if (clientValidInvoices.length > 0) {
            const globalLastValidInvoices = await this.prisma.facture.findMany({
                where: {
                    statut: { in: ['VALIDE', 'PAYEE', 'PARTIEL'] },
                },
                orderBy: { numero: 'desc' },
                take: clientValidInvoices.length,
            });
            const clientIds = clientValidInvoices.map((f) => f.id).sort();
            const globalIds = globalLastValidInvoices.map((f) => f.id).sort();
            const isSafeToDelete = clientIds.length === globalIds.length &&
                clientIds.every((val, index) => val === globalIds[index]);
            if (!isSafeToDelete) {
                const globalLast = globalLastValidInvoices[0];
                throw new Error(`Supression impossible: La continuité fiscale n'est pas respectée. Une facture plus récente existe (${globalLast?.numero}). Action strictement interdite.`);
            }
        }
        const openFichesCount = await this.prisma.fiche.count({
            where: {
                clientId: id,
                statut: 'EN_COURS',
            },
        });
        if (openFichesCount > 0) {
            throw new Error("Supression impossible: Ce client a des fiches en cours. Veuillez les annuler d'abord.");
        }
        return this.prisma.$transaction(async (tx) => {
            const invoices = await tx.facture.findMany({ where: { clientId: id } });
            const invoiceIds = invoices.map((i) => i.id);
            if (invoiceIds.length > 0) {
                await tx.paiement.deleteMany({
                    where: { factureId: { in: invoiceIds } },
                });
            }
            await tx.facture.deleteMany({ where: { clientId: id } });
            await tx.fiche.deleteMany({ where: { clientId: id } });
            return tx.client.delete({ where: { id } });
        });
    }
};
exports.ClientsService = ClientsService;
exports.ClientsService = ClientsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        loyalty_service_1.LoyaltyService])
], ClientsService);
//# sourceMappingURL=clients.service.js.map