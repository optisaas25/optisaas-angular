export declare enum ClientType {
    PARTICULIER = "particulier",
    PROFESSIONNEL = "professionnel",
    ANONYME = "anonyme"
}
export declare class CreateClientDto {
    typeClient: ClientType;
    titre?: string;
    nom: string;
    prenom?: string;
    typePieceIdentite?: string;
    numeroPieceIdentite?: string;
    cinParent?: string;
    dateNaissance?: Date;
    telephone?: string;
    email?: string;
    ville?: string;
    adresse?: string;
    codePostal?: string;
    statut?: string;
    couvertureSociale?: any;
    dossierMedical?: any;
    groupeFamille?: any;
    raisonSociale?: string;
    identifiantFiscal?: string;
    ice?: string;
    registreCommerce?: string;
    patente?: string;
    tvaAssujetti?: boolean;
    numeroAutorisation?: string;
    siteWeb?: string;
    convention?: any;
    conventionId?: string;
    contacts?: any;
    parrainId?: string;
    centreId?: string;
}
