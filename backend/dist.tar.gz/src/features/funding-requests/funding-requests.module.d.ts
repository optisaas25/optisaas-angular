export declare class FundingRequestsModule {
}
