import { FundingRequestsService } from './funding-requests.service';
export declare class FundingRequestsController {
    private readonly fundingRequestsService;
    constructor(fundingRequestsService: FundingRequestsService);
    findAll(centreId?: string): Promise<any>;
    countPending(centreId?: string): Promise<number>;
    approve(id: string, validatorId: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        montant: number;
        remarque: string | null;
        journeeCaisseId: string;
        validatedAt: Date | null;
        validatedBy: string | null;
        depenseId: string | null;
        paiementId: string | null;
    }>;
    reject(id: string, validatorId: string, remarque?: string): Promise<any>;
}
