"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FundingRequestsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let FundingRequestsService = class FundingRequestsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findAll(centreId) {
        return this.prisma.demandeAlimentation.findMany({
            where: {
                ...(centreId ? { journeeCaisse: { centreId } } : {}),
            },
            include: {
                depense: {
                    include: { centre: true },
                },
                paiement: {
                    include: {
                        facture: {
                            include: { centre: true },
                        },
                    },
                },
                journeeCaisse: {
                    include: { caisse: true },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }
    async countPending(centreId) {
        return this.prisma.demandeAlimentation.count({
            where: {
                statut: 'EN_ATTENTE',
                ...(centreId ? { journeeCaisse: { centreId } } : {}),
            },
        });
    }
    async approve(id, validatorId) {
        return this.prisma.$transaction(async (tx) => {
            const request = await tx.demandeAlimentation.findUnique({
                where: { id },
                include: {
                    depense: true,
                    paiement: {
                        include: { facture: true },
                    },
                    journeeCaisse: {
                        include: { caisse: true },
                    },
                },
            });
            if (!request) {
                throw new common_1.NotFoundException("Demande d'alimentation introuvable");
            }
            if (request.statut !== 'EN_ATTENTE') {
                throw new common_1.BadRequestException('Cette demande a déjà été traitée');
            }
            const candidateCaisses = await tx.caisse.findMany({
                where: {
                    centreId: request.journeeCaisse.centreId,
                    type: { in: ['PRINCIPALE', 'MIXTE'] },
                    statut: 'ACTIVE',
                },
            });
            const mainCaisse = candidateCaisses.find(c => c.type === 'MIXTE') || candidateCaisses[0];
            if (!mainCaisse) {
                throw new common_1.BadRequestException('Aucune caisse principale active trouvée pour ce centre');
            }
            const mainSession = await tx.journeeCaisse.findFirst({
                where: {
                    caisseId: mainCaisse.id,
                    statut: 'OUVERTE',
                },
            });
            if (!mainSession) {
                throw new common_1.BadRequestException('La caisse principale doit être ouverte pour approuver une alimentation');
            }
            const amount = request.montant;
            const utilisateur = validatorId || 'Système';
            const motifMain = request.depenseId
                ? `ALIMENTATION_CAISSE_DEPENSES: ${request.depense.categorie}`
                : `ALIMENTATION_REGULARISATION_AVOIR: FAC ${request.paiement.facture.numero}`;
            await tx.operationCaisse.create({
                data: {
                    type: 'DECAISSEMENT',
                    typeOperation: 'INTERNE',
                    montant: amount,
                    moyenPaiement: 'ESPECES',
                    motif: motifMain,
                    utilisateur,
                    journeeCaisseId: mainSession.id,
                },
            });
            await tx.operationCaisse.create({
                data: {
                    type: 'ENCAISSEMENT',
                    typeOperation: 'INTERNE',
                    montant: amount,
                    moyenPaiement: 'ESPECES',
                    motif: 'ALIMENTATION_DEPUIS_CAISSE_PRINCIPALE',
                    utilisateur,
                    journeeCaisseId: request.journeeCaisseId,
                },
            });
            await tx.journeeCaisse.update({
                where: { id: mainSession.id },
                data: {
                    totalDepenses: { increment: amount },
                    totalTransfertsDepenses: { increment: amount },
                },
            });
            await tx.journeeCaisse.update({
                where: { id: request.journeeCaisseId },
                data: {
                    totalInterne: { increment: amount },
                },
            });
            const motifPetty = request.depenseId
                ? `Dépense (Alimentée): ${request.depense.categorie}`
                : `Régularisation Avoir`;
            const opDepense = await tx.operationCaisse.create({
                data: {
                    type: 'DECAISSEMENT',
                    typeOperation: 'COMPTABLE',
                    montant: amount,
                    moyenPaiement: 'ESPECES',
                    motif: motifPetty,
                    reference: request.depenseId || request.paiement.facture.numero,
                    utilisateur: request.depense?.creePar ||
                        request.paiement?.createPar ||
                        utilisateur,
                    journeeCaisseId: request.journeeCaisseId,
                    factureId: request.paiement?.factureId ||
                        request.depense?.factureFournisseurId,
                },
            });
            await tx.journeeCaisse.update({
                where: { id: request.journeeCaisseId },
                data: {
                    totalDepenses: { increment: amount },
                },
            });
            if (request.depenseId) {
                await tx.depense.update({
                    where: { id: request.depenseId },
                    data: { statut: 'PAYE' },
                });
            }
            else if (request.paiementId) {
                await tx.paiement.update({
                    where: { id: request.paiementId },
                    data: {
                        statut: 'DECAISSEMENT',
                        operationCaisseId: opDepense.id,
                    },
                });
            }
            return await tx.demandeAlimentation.update({
                where: { id },
                data: {
                    statut: 'VALIDEE',
                    validatedAt: new Date(),
                    validatedBy: validatorId,
                },
            });
        });
    }
    async reject(id, validatorId, remarque) {
        return this.prisma.$transaction(async (tx) => {
            const request = await tx.demandeAlimentation.findUnique({
                where: { id },
            });
            if (!request) {
                throw new common_1.NotFoundException("Demande d'alimentation introuvable");
            }
            if (request.statut !== 'EN_ATTENTE') {
                throw new common_1.BadRequestException('Cette demande a déjà été traitée');
            }
            if (request.depenseId) {
                await tx.depense.update({
                    where: { id: request.depenseId },
                    data: { statut: 'REJETTE_ALIMENTATION' },
                });
            }
            else if (request.paiementId) {
                await tx.paiement.update({
                    where: { id: request.paiementId },
                    data: { statut: 'REJETTE_ALIMENTATION' },
                });
            }
            return await tx.demandeAlimentation.update({
                where: { id },
                data: {
                    statut: 'REJETEE',
                    validatedAt: new Date(),
                    validatedBy: validatorId,
                    remarque,
                },
            });
        });
    }
};
exports.FundingRequestsService = FundingRequestsService;
exports.FundingRequestsService = FundingRequestsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], FundingRequestsService);
//# sourceMappingURL=funding-requests.service.js.map