import { PrismaService } from '../../prisma/prisma.service';
export declare class FundingRequestsService {
    private prisma;
    constructor(prisma: PrismaService);
    findAll(centreId?: string): Promise<any>;
    countPending(centreId?: string): Promise<number>;
    approve(id: string, validatorId: string): Promise<{
        id: string;
        statut: string;
        createdAt: Date;
        montant: number;
        remarque: string | null;
        journeeCaisseId: string;
        validatedAt: Date | null;
        validatedBy: string | null;
        depenseId: string | null;
        paiementId: string | null;
    }>;
    reject(id: string, validatorId: string, remarque?: string): Promise<any>;
}
