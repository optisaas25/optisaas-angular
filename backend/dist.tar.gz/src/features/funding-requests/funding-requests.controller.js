"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FundingRequestsController = void 0;
const common_1 = require("@nestjs/common");
const funding_requests_service_1 = require("./funding-requests.service");
let FundingRequestsController = class FundingRequestsController {
    fundingRequestsService;
    constructor(fundingRequestsService) {
        this.fundingRequestsService = fundingRequestsService;
    }
    findAll(centreId) {
        return this.fundingRequestsService.findAll(centreId);
    }
    countPending(centreId) {
        return this.fundingRequestsService.countPending(centreId);
    }
    approve(id, validatorId) {
        return this.fundingRequestsService.approve(id, validatorId);
    }
    reject(id, validatorId, remarque) {
        return this.fundingRequestsService.reject(id, validatorId, remarque);
    }
};
exports.FundingRequestsController = FundingRequestsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FundingRequestsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('count-pending'),
    __param(0, (0, common_1.Query)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FundingRequestsController.prototype, "countPending", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('validatorId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], FundingRequestsController.prototype, "approve", null);
__decorate([
    (0, common_1.Post)(':id/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('validatorId')),
    __param(2, (0, common_1.Body)('remarque')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], FundingRequestsController.prototype, "reject", null);
exports.FundingRequestsController = FundingRequestsController = __decorate([
    (0, common_1.Controller)('funding-requests'),
    __metadata("design:paramtypes", [funding_requests_service_1.FundingRequestsService])
], FundingRequestsController);
//# sourceMappingURL=funding-requests.controller.js.map