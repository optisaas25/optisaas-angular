import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
export declare class MailerService {
    private prisma;
    private configService;
    private readonly logger;
    constructor(prisma: PrismaService, configService: ConfigService);
    sendMailWithAttachment(options: {
        to: string;
        cc?: string;
        replyTo?: string;
        fromName?: string;
        subject: string;
        text: string;
        attachments: Array<{
            filename: string;
            content: Buffer;
        }>;
    }): Promise<import("nodemailer/lib/smtp-transport").SentMessageInfo>;
}
