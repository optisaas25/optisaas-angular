"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MailerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailerService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const nodemailer = __importStar(require("nodemailer"));
let MailerService = MailerService_1 = class MailerService {
    prisma;
    configService;
    logger = new common_1.Logger(MailerService_1.name);
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
    }
    async sendMailWithAttachment(options) {
        const config = await this.prisma.marketingConfig.findFirst();
        let host = config?.smtpHost || this.configService.get('SMTP_HOST');
        let user = config?.smtpUser || this.configService.get('SMTP_USER');
        let pass = config?.smtpPass || this.configService.get('SMTP_PASS');
        let port = Number(config?.smtpPort) || this.configService.get('SMTP_PORT', 587);
        let secure = port === 465;
        if (!host || !user || !pass) {
            this.logger.warn('[Mailer] SMTP credentials missing. Using Ethereal Email for testing purposes.');
            const testAccount = await nodemailer.createTestAccount();
            host = testAccount.smtp.host;
            port = testAccount.smtp.port;
            secure = testAccount.smtp.secure;
            user = testAccount.user;
            pass = testAccount.pass;
        }
        const transporter = nodemailer.createTransport({
            host,
            port,
            secure,
            auth: { user, pass },
            tls: { rejectUnauthorized: false },
        });
        const fromEmail = (config?.smtpFrom && config.smtpFrom.includes('@'))
            ? config.smtpFrom
            : (this.configService.get('SMTP_FROM') || user);
        const displayName = options.fromName || (config?.smtpFrom && !config.smtpFrom.includes('@') ? config.smtpFrom : undefined);
        const finalFrom = displayName ? `"${displayName}" <${fromEmail}>` : fromEmail;
        const info = await transporter.sendMail({
            from: finalFrom,
            to: options.to,
            cc: options.cc,
            replyTo: options.replyTo,
            subject: options.subject,
            text: options.text,
            html: `<div style="font-family: sans-serif; padding: 20px; line-height: 1.6;">
              ${(options.text || '').replace(/\n/g, '<br>')}
             </div>`,
            attachments: options.attachments,
        });
        this.logger.log(`[Mailer] Email sent to ${options.to}: ${info.messageId}`);
        return info;
    }
};
exports.MailerService = MailerService;
exports.MailerService = MailerService = MailerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], MailerService);
//# sourceMappingURL=mailer.service.js.map