export declare class PdfService {
    private readonly logger;
    generatePurchaseOrder(data: {
        bcNumber: string;
        date: Date;
        supplierName: string;
        clientName: string;
        designation: string;
        prescription: {
            od: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition?: string;
                ep?: string;
                diametre?: string;
                haut?: string;
                diamUtile?: string;
            };
            og: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition?: string;
                ep?: string;
                diametre?: string;
                haut?: string;
                diamUtile?: string;
            };
        };
        ficheNumber?: string;
        lensDetails?: {
            od: string;
            og: string;
            treatments: string;
            indiceOD?: string;
            indiceOG?: string;
            matiereOD?: string;
            matiereOG?: string;
            typeVerre?: string;
        };
        frameDetails?: {
            reference: string;
            marque: string;
            taille: string;
        };
        technicalNote?: {
            mesure: string;
            safety: number;
            intermediate: string;
            ordered: string;
        };
        branding?: {
            companyName: string;
            logoUrl?: string;
            cachetUrl?: string;
        };
        observations?: string;
    }): Promise<Buffer>;
    generateFicheMontagePdf(data: {
        bcNumber: string;
        date: Date;
        clientName: string;
        magasinName: string;
        prescription: {
            od: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
            };
            og: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
            };
        };
        centrage: {
            od: {
                dp: string;
                ht: string;
                diamUtile: string;
            };
            og: {
                dp: string;
                ht: string;
                diamUtile: string;
            };
        };
        verres: {
            od: string;
            og: string;
            treatments: string;
        };
        diametreConseille: string;
        imageMontureUrl?: string;
        virtualCenteringUrl?: string;
        preconisationsIA?: {
            od: string;
            og: string;
        };
        technicalNote?: {
            mesure: string;
            safety: number;
            intermediate: string;
            ordered: string;
        };
        branding?: {
            companyName: string;
            logoUrl?: string;
            cachetUrl?: string;
        };
        ficheNumber?: string;
        observations?: string;
    }): Promise<Buffer>;
    generateLensPurchaseOrder(data: {
        bcNumber: string;
        date: Date;
        supplierName: string;
        clientName: string;
        prescription: {
            od: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
                rayon: string;
                diametre: string;
            };
            og: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
                rayon: string;
                diametre: string;
            };
        };
        lensDetails: {
            marque: string;
            modele: string;
            type: string;
        };
        branding?: {
            companyName: string;
            logoUrl?: string;
            cachetUrl?: string;
        };
        ficheNumber?: string;
    }): Promise<Buffer>;
    generateLensTechnicalSheet(data: {
        bcNumber: string;
        date: Date;
        clientName: string;
        prescription: {
            od: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
            };
            og: {
                sphere: string;
                cylindre: string;
                axe: string;
                addition: string;
            };
        };
        lentilles: {
            od: {
                marque: string;
                modele: string;
                rayon: string;
                diametre: string;
                mouvement: string;
                centrage: string;
            };
            og: {
                marque: string;
                modele: string;
                rayon: string;
                diametre: string;
                mouvement: string;
                centrage: string;
            };
            type: string;
            usage: string;
        };
        adaptation: {
            od: {
                secretionLacrimale: string;
                but: string;
            };
            og: {
                secretionLacrimale: string;
                but: string;
            };
        };
        keratometrie: {
            od: {
                k1: string;
                k2: string;
                axe: string;
                kMoy: string;
            };
            og: {
                k1: string;
                k2: string;
                axe: string;
                kMoy: string;
            };
        };
        branding?: {
            companyName: string;
            logoUrl?: string;
            cachetUrl?: string;
        };
        ficheNumber?: string;
    }): Promise<Buffer>;
}
