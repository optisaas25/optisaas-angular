"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationCaisseService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const create_operation_caisse_dto_1 = require("./dto/create-operation-caisse.dto");
let OperationCaisseService = class OperationCaisseService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createOperationDto, userRole, userId) {
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id: createOperationDto.journeeCaisseId },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Journée de caisse introuvable');
        }
        if (journee.statut === 'FERMEE') {
            throw new common_1.ForbiddenException("Impossible d'ajouter une opération sur une journée fermée");
        }
        if (createOperationDto.typeOperation === create_operation_caisse_dto_1.TypeOperation.INTERNE &&
            userRole &&
            !['RESPONSABLE', 'DIRECTION', 'ADMIN'].includes(userRole)) {
            throw new common_1.ForbiddenException("Vous n'avez pas l'autorisation de créer des opérations internes");
        }
        if (createOperationDto.type === 'DECAISSEMENT' &&
            !createOperationDto.motif) {
            throw new common_1.BadRequestException('Le motif est obligatoire pour les décaissements');
        }
        let userName = createOperationDto.utilisateur || 'System';
        if (userId) {
            const user = await this.prisma.user.findUnique({
                where: { id: userId },
                select: { nom: true, prenom: true },
            });
            if (user) {
                userName = `${user.prenom} ${user.nom}`;
            }
        }
        return await this.prisma.$transaction(async (tx) => {
            const operation = await tx.operationCaisse.create({
                data: {
                    ...createOperationDto,
                    userId: userId || null,
                    utilisateur: userName,
                },
                include: {
                    user: {
                        select: {
                            nom: true,
                            prenom: true,
                        },
                    },
                    journeeCaisse: {
                        include: {
                            caisse: true,
                            centre: true,
                        },
                    },
                    facture: {
                        select: {
                            numero: true,
                            client: {
                                select: {
                                    nom: true,
                                    prenom: true,
                                },
                            },
                        },
                    },
                },
            });
            if (operation.type === 'ENCAISSEMENT') {
                if (operation.typeOperation === create_operation_caisse_dto_1.TypeOperation.COMPTABLE) {
                    await tx.journeeCaisse.update({
                        where: { id: operation.journeeCaisseId },
                        data: {
                            totalComptable: { increment: operation.montant },
                            totalVentesEspeces: (operation.moyenPaiement === 'ESPECES' || operation.moyenPaiement === 'ESPECE')
                                ? { increment: operation.montant }
                                : undefined,
                            totalVentesCarte: operation.moyenPaiement === 'CARTE'
                                ? { increment: operation.montant }
                                : undefined,
                            totalVentesCheque: operation.moyenPaiement === 'CHEQUE'
                                ? { increment: operation.montant }
                                : undefined,
                        },
                    });
                }
                else if (operation.typeOperation === create_operation_caisse_dto_1.TypeOperation.INTERNE) {
                    await tx.journeeCaisse.update({
                        where: { id: operation.journeeCaisseId },
                        data: {
                            totalInterne: operation.moyenPaiement === 'ESPECES'
                                ? { increment: operation.montant }
                                : undefined,
                        },
                    });
                }
            }
            else if (operation.type === 'DECAISSEMENT') {
                if (operation.typeOperation === create_operation_caisse_dto_1.TypeOperation.COMPTABLE) {
                    await tx.journeeCaisse.update({
                        where: { id: operation.journeeCaisseId },
                        data: {
                            totalComptable: { decrement: operation.montant },
                            totalVentesEspeces: (operation.moyenPaiement === 'ESPECES' || operation.moyenPaiement === 'ESPECE')
                                ? { decrement: operation.montant }
                                : undefined,
                            totalVentesCarte: operation.moyenPaiement === 'CARTE'
                                ? { decrement: operation.montant }
                                : undefined,
                            totalVentesCheque: operation.moyenPaiement === 'CHEQUE'
                                ? { decrement: operation.montant }
                                : undefined,
                        },
                    });
                }
                else {
                    await tx.journeeCaisse.update({
                        where: { id: operation.journeeCaisseId },
                        data: {
                            totalDepenses: (operation.moyenPaiement === 'ESPECES' || operation.moyenPaiement === 'ESPECE')
                                ? { increment: operation.montant }
                                : undefined,
                            totalTransfertsDepenses: operation.motif === 'ALIMENTATION_CAISSE_DEPENSES'
                                ? { increment: operation.montant }
                                : undefined,
                        },
                    });
                }
            }
            return operation;
        });
    }
    async findByJournee(journeeId, startDate, endDate) {
        console.log(`[Caisse-Operation] findByJournee: ID=${journeeId}, start=${startDate}, end=${endDate}`);
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id: journeeId },
            select: { caisseId: true },
        });
        if (!journee)
            throw new common_1.NotFoundException('Journée introuvable');
        let hasFilter = false;
        const dateFilter = {};
        if (startDate && startDate !== 'undefined' && startDate !== 'null') {
            const start = new Date(startDate);
            if (!isNaN(start.getTime())) {
                dateFilter.gte = start;
                hasFilter = true;
            }
        }
        if (endDate && endDate !== 'undefined' && endDate !== 'null') {
            const end = new Date(endDate);
            if (!isNaN(end.getTime())) {
                dateFilter.lte = end;
                hasFilter = true;
            }
        }
        const where = {
            ...(hasFilter
                ? { journeeCaisse: { caisseId: journee.caisseId } }
                : { journeeCaisseId: journeeId }),
            ...(hasFilter ? { createdAt: dateFilter } : {}),
        };
        console.log('[Caisse-Operation] FINAL PRISMA WHERE:', JSON.stringify(where));
        const result = await this.prisma.operationCaisse.findMany({
            where,
            include: {
                user: {
                    select: {
                        nom: true,
                        prenom: true,
                    },
                },
                facture: {
                    select: {
                        numero: true,
                        client: {
                            select: {
                                nom: true,
                                prenom: true,
                            },
                        },
                    },
                },
            },
            orderBy: {
                createdAt: 'desc',
            },
            take: hasFilter ? undefined : 200,
        });
        console.log(`[Caisse-Operation] Result size: ${result.length}`);
        return result;
    }
    async remove(id, userRole) {
        const operation = await this.prisma.operationCaisse.findUnique({
            where: { id },
            include: {
                journeeCaisse: true,
            },
        });
        if (!operation) {
            throw new common_1.NotFoundException('Opération introuvable');
        }
        if (operation.journeeCaisse.statut === 'FERMEE') {
            throw new common_1.ForbiddenException("Impossible de supprimer une opération d'une journée fermée");
        }
        if (userRole && !['RESPONSABLE', 'DIRECTION', 'ADMIN'].includes(userRole)) {
            throw new common_1.ForbiddenException("Vous n'avez pas l'autorisation de supprimer des opérations");
        }
        return await this.prisma.$transaction(async (tx) => {
            const deletedOp = await tx.operationCaisse.delete({
                where: { id },
            });
            if (deletedOp.type === 'ENCAISSEMENT') {
                if (deletedOp.typeOperation === 'COMPTABLE') {
                    await tx.journeeCaisse.update({
                        where: { id: deletedOp.journeeCaisseId },
                        data: {
                            totalComptable: { decrement: deletedOp.montant },
                            totalVentesEspeces: deletedOp.moyenPaiement === 'ESPECES'
                                ? { decrement: deletedOp.montant }
                                : undefined,
                            totalVentesCarte: deletedOp.moyenPaiement === 'CARTE'
                                ? { decrement: deletedOp.montant }
                                : undefined,
                            totalVentesCheque: deletedOp.moyenPaiement === 'CHEQUE'
                                ? { decrement: deletedOp.montant }
                                : undefined,
                        },
                    });
                }
                else if (deletedOp.typeOperation === 'INTERNE') {
                    await tx.journeeCaisse.update({
                        where: { id: deletedOp.journeeCaisseId },
                        data: { totalInterne: { decrement: deletedOp.montant } },
                    });
                }
            }
            else if (deletedOp.type === 'DECAISSEMENT') {
                if (deletedOp.typeOperation === 'COMPTABLE') {
                    await tx.journeeCaisse.update({
                        where: { id: deletedOp.journeeCaisseId },
                        data: {
                            totalComptable: { increment: deletedOp.montant },
                            totalVentesEspeces: deletedOp.moyenPaiement === 'ESPECES'
                                ? { increment: deletedOp.montant }
                                : undefined,
                            totalVentesCarte: deletedOp.moyenPaiement === 'CARTE'
                                ? { increment: deletedOp.montant }
                                : undefined,
                            totalVentesCheque: deletedOp.moyenPaiement === 'CHEQUE'
                                ? { increment: deletedOp.montant }
                                : undefined,
                        },
                    });
                }
                else {
                    await tx.journeeCaisse.update({
                        where: { id: deletedOp.journeeCaisseId },
                        data: {
                            totalDepenses: { decrement: deletedOp.montant },
                            totalTransfertsDepenses: deletedOp.motif === 'ALIMENTATION_CAISSE_DEPENSES'
                                ? { decrement: deletedOp.montant }
                                : undefined,
                        },
                    });
                }
            }
            return deletedOp;
        });
    }
    async getStatsByJournee(journeeId) {
        const operations = await this.findByJournee(journeeId);
        const stats = {
            totalComptable: 0,
            totalInterne: 0,
            totalDepenses: 0,
            countComptable: 0,
            countInterne: 0,
            countDepenses: 0,
            byMoyenPaiement: {},
        };
        operations.forEach((op) => {
            if (op.type === 'ENCAISSEMENT') {
                if (op.typeOperation === 'COMPTABLE') {
                    stats.totalComptable += op.montant;
                    stats.countComptable++;
                }
                else {
                    stats.totalInterne += op.montant;
                    stats.countInterne++;
                }
            }
            else {
                stats.totalDepenses += op.montant;
                stats.countDepenses++;
            }
            if (!stats.byMoyenPaiement[op.moyenPaiement]) {
                stats.byMoyenPaiement[op.moyenPaiement] = 0;
            }
            stats.byMoyenPaiement[op.moyenPaiement] += op.montant;
        });
        return stats;
    }
    async transfer(dto) {
        const { amount, fromJourneeId, toJourneeId, utilisateur, userId } = dto;
        let userName = utilisateur || 'Responsable';
        if (userId) {
            const user = await this.prisma.user.findUnique({
                where: { id: userId },
                select: { nom: true, prenom: true },
            });
            if (user) {
                userName = `${user.prenom} ${user.nom}`;
            }
        }
        return await this.prisma.$transaction(async (tx) => {
            const sourceOp = await tx.operationCaisse.create({
                data: {
                    type: 'DECAISSEMENT',
                    typeOperation: 'INTERNE',
                    montant: amount,
                    moyenPaiement: 'ESPECES',
                    motif: 'ALIMENTATION_CAISSE_DEPENSES',
                    utilisateur: userName,
                    userId: userId || null,
                    journeeCaisseId: fromJourneeId,
                },
            });
            const destOp = await tx.operationCaisse.create({
                data: {
                    type: 'ENCAISSEMENT',
                    typeOperation: 'INTERNE',
                    montant: amount,
                    moyenPaiement: 'ESPECES',
                    motif: 'ALIMENTATION_DEPUIS_CAISSE_PRINCIPALE',
                    utilisateur: userName,
                    userId: userId || null,
                    journeeCaisseId: toJourneeId,
                },
            });
            await tx.journeeCaisse.update({
                where: { id: fromJourneeId },
                data: {
                    totalDepenses: { increment: amount },
                    totalTransfertsDepenses: { increment: amount },
                },
            });
            await tx.journeeCaisse.update({
                where: { id: toJourneeId },
                data: {
                    totalInterne: { increment: amount },
                },
            });
            return { sourceOp, destOp };
        });
    }
};
exports.OperationCaisseService = OperationCaisseService;
exports.OperationCaisseService = OperationCaisseService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], OperationCaisseService);
//# sourceMappingURL=operation-caisse.service.js.map