export declare enum OperationType {
    ENCAISSEMENT = "ENCAISSEMENT",
    DECAISSEMENT = "DECAISSEMENT"
}
export declare enum TypeOperation {
    COMPTABLE = "COMPTABLE",
    INTERNE = "INTERNE"
}
export declare enum MoyenPaiement {
    ESPECES = "ESPECES",
    CARTE = "CARTE",
    VIREMENT = "VIREMENT",
    CHEQUE = "CHEQUE"
}
export declare class CreateOperationCaisseDto {
    type: OperationType;
    typeOperation: TypeOperation;
    montant: number;
    moyenPaiement: MoyenPaiement;
    reference?: string;
    motif?: string;
    pieceJointe?: string;
    utilisateur: string;
    journeeCaisseId: string;
    factureId?: string;
}
