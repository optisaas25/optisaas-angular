"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationCaisseController = void 0;
const common_1 = require("@nestjs/common");
const jwt = __importStar(require("jsonwebtoken"));
const config_1 = require("@nestjs/config");
const operation_caisse_service_1 = require("./operation-caisse.service");
const create_operation_caisse_dto_1 = require("./dto/create-operation-caisse.dto");
let OperationCaisseController = class OperationCaisseController {
    operationCaisseService;
    configService;
    constructor(operationCaisseService, configService) {
        this.operationCaisseService = operationCaisseService;
        this.configService = configService;
    }
    create(createOperationDto, userRole, authHeader) {
        const userId = this.getUserId(authHeader);
        return this.operationCaisseService.create(createOperationDto, userRole, userId);
    }
    findByJournee(journeeId, startDate, endDate) {
        return this.operationCaisseService.findByJournee(journeeId, startDate, endDate);
    }
    getStatsByJournee(journeeId) {
        return this.operationCaisseService.getStatsByJournee(journeeId);
    }
    transfer(transferDto, authHeader) {
        const userId = this.getUserId(authHeader);
        return this.operationCaisseService.transfer({ ...transferDto, userId });
    }
    getUserId(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer '))
            return undefined;
        try {
            const token = authHeader.split(' ')[1];
            const secret = this.configService.get('JWT_SECRET') || 'your-very-secret-key';
            const payload = jwt.verify(token, secret);
            return payload.sub;
        }
        catch (e) {
            return undefined;
        }
    }
    remove(id, userRole) {
        return this.operationCaisseService.remove(id, userRole);
    }
};
exports.OperationCaisseController = OperationCaisseController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Query)('userRole')),
    __param(2, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_operation_caisse_dto_1.CreateOperationCaisseDto, String, String]),
    __metadata("design:returntype", void 0)
], OperationCaisseController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('journee/:journeeId'),
    __param(0, (0, common_1.Param)('journeeId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], OperationCaisseController.prototype, "findByJournee", null);
__decorate([
    (0, common_1.Get)('journee/:journeeId/stats'),
    __param(0, (0, common_1.Param)('journeeId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OperationCaisseController.prototype, "getStatsByJournee", null);
__decorate([
    (0, common_1.Post)('transfer'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], OperationCaisseController.prototype, "transfer", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('userRole')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], OperationCaisseController.prototype, "remove", null);
exports.OperationCaisseController = OperationCaisseController = __decorate([
    (0, common_1.Controller)('operation-caisse'),
    __metadata("design:paramtypes", [operation_caisse_service_1.OperationCaisseService,
        config_1.ConfigService])
], OperationCaisseController);
//# sourceMappingURL=operation-caisse.controller.js.map