export declare class OperationCaisseModule {
}
