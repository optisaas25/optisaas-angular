import { PrismaService } from '../../prisma/prisma.service';
import { CreateOperationCaisseDto } from './dto/create-operation-caisse.dto';
export declare class OperationCaisseService {
    private prisma;
    constructor(prisma: PrismaService);
    create(createOperationDto: CreateOperationCaisseDto, userRole?: string, userId?: string): Promise<{
        facture: {
            numero: string;
            client: {
                nom: string | null;
                prenom: string | null;
            };
        } | null;
        user: {
            nom: string;
            prenom: string;
        } | null;
        journeeCaisse: {
            centre: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                nom: string;
                description: string | null;
                adresse: string | null;
                ville: string | null;
                codePostal: string | null;
                telephone: string | null;
                email: string | null;
                groupeId: string;
            };
            caisse: {
                id: string;
                type: string;
                statut: string;
                createdAt: Date;
                updatedAt: Date;
                centreId: string;
                nom: string;
                description: string | null;
            };
        } & {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            centreId: string;
            dateOuverture: Date;
            dateCloture: Date | null;
            fondInitial: number;
            soldeTheorique: number | null;
            soldeReel: number | null;
            ecart: number | null;
            justificationEcart: string | null;
            caissier: string;
            responsableCloture: string | null;
            totalComptable: number;
            totalInterne: number;
            totalDepenses: number;
            caisseId: string;
            totalTransfertsDepenses: number;
            totalVentesCarte: number;
            totalVentesEspeces: number;
            totalVentesCheque: number;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        typeOperation: string;
        montant: number;
        reference: string | null;
        pieceJointe: string | null;
        factureId: string | null;
        userId: string | null;
        moyenPaiement: string;
        motif: string | null;
        utilisateur: string;
        journeeCaisseId: string;
    }>;
    findByJournee(journeeId: string, startDate?: string, endDate?: string): Promise<({
        facture: {
            numero: string;
            client: {
                nom: string | null;
                prenom: string | null;
            };
        } | null;
        user: {
            nom: string;
            prenom: string;
        } | null;
    } & {
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        typeOperation: string;
        montant: number;
        reference: string | null;
        pieceJointe: string | null;
        factureId: string | null;
        userId: string | null;
        moyenPaiement: string;
        motif: string | null;
        utilisateur: string;
        journeeCaisseId: string;
    })[]>;
    remove(id: string, userRole?: string): Promise<{
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        typeOperation: string;
        montant: number;
        reference: string | null;
        pieceJointe: string | null;
        factureId: string | null;
        userId: string | null;
        moyenPaiement: string;
        motif: string | null;
        utilisateur: string;
        journeeCaisseId: string;
    }>;
    getStatsByJournee(journeeId: string): Promise<{
        totalComptable: number;
        totalInterne: number;
        totalDepenses: number;
        countComptable: number;
        countInterne: number;
        countDepenses: number;
        byMoyenPaiement: Record<string, number>;
    }>;
    transfer(dto: {
        amount: number;
        fromJourneeId: string;
        toJourneeId: string;
        utilisateur: string;
        userId?: string;
    }): Promise<{
        sourceOp: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            typeOperation: string;
            montant: number;
            reference: string | null;
            pieceJointe: string | null;
            factureId: string | null;
            userId: string | null;
            moyenPaiement: string;
            motif: string | null;
            utilisateur: string;
            journeeCaisseId: string;
        };
        destOp: {
            id: string;
            type: string;
            createdAt: Date;
            updatedAt: Date;
            typeOperation: string;
            montant: number;
            reference: string | null;
            pieceJointe: string | null;
            factureId: string | null;
            userId: string | null;
            moyenPaiement: string;
            motif: string | null;
            utilisateur: string;
            journeeCaisseId: string;
        };
    }>;
}
