"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaiementsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const stock_availability_service_1 = require("../factures/stock-availability.service");
const commission_service_1 = require("../personnel/commission.service");
let PaiementsService = class PaiementsService {
    prisma;
    stockAvailabilityService;
    commissionService;
    constructor(prisma, stockAvailabilityService, commissionService) {
        this.prisma = prisma;
        this.stockAvailabilityService = stockAvailabilityService;
        this.commissionService = commissionService;
    }
    async create(createPaiementDto, userId) {
        const { factureId, montant } = createPaiementDto;
        const facture = await this.prisma.facture.findUnique({
            where: { id: factureId },
            include: { paiements: true },
        });
        if (!facture) {
            throw new common_1.NotFoundException('Facture non trouvée');
        }
        if (montant > facture.resteAPayer) {
            throw new common_1.BadRequestException(`Le montant du paiement (${montant}) dépasse le reste à payer (${facture.resteAPayer})`);
        }
        if (facture.type === 'DEVIS') {
            const stockCheck = await this.stockAvailabilityService.checkAvailability(factureId);
            if (stockCheck.hasConflicts) {
                console.error(`❌ [PAIEMENT GUARD] Bloqué car stock insuffisant pour le devis ${facture.numero}`);
                throw new common_1.ConflictException({
                    message: "Impossible d'ajouter un paiement : certains produits sont en rupture de stock. Veuillez résoudre les conflits avant de transformer ce devis en bon de commande.",
                    conflicts: stockCheck.conflicts,
                });
            }
        }
        let finalStatut = createPaiementDto.statut;
        if (montant < 0) {
            finalStatut = 'DECAISSEMENT';
            createPaiementDto.mode = 'ESPECES';
        }
        else if (!finalStatut) {
            finalStatut =
                createPaiementDto.mode === 'ESPECES' ||
                    createPaiementDto.mode === 'CARTE'
                    ? 'ENCAISSE'
                    : 'EN_ATTENTE';
        }
        const paiement = await this.prisma.paiement.create({
            data: {
                ...createPaiementDto,
                statut: finalStatut,
                userId: userId || null,
            },
        });
        const acceptedModes = ['ESPECES', 'ESPECE', 'CARTE', 'CHEQUE', 'CHÈQUE', 'VIREMENT', 'LCN'];
        if (acceptedModes.includes(createPaiementDto.mode)) {
            try {
                await this.prisma.$transaction(async (tx) => {
                    await this.handleCaisseIntegration(tx, paiement, facture, userId);
                });
            }
            catch (caisseError) {
                console.error('❌ [PAIEMENT CAISSE ERROR]', {
                    paiementId: paiement.id,
                    mode: paiement.mode,
                    montant: paiement.montant,
                    error: caisseError.message,
                    stack: caisseError.stack
                });
            }
        }
        const nouveauReste = facture.resteAPayer - montant;
        const nouveauStatut = nouveauReste <= 0
            ? facture.totalTTC > 0
                ? 'PAYEE'
                : 'VALIDE'
            : 'PARTIEL';
        const updateData = {
            resteAPayer: nouveauReste,
            statut: nouveauStatut,
        };
        if (facture.type === 'DEVIS') {
            console.log(`📌 [TRANSITION] Devis ${facture.numero} receiving payment. Upgrading to BON_COMM.`);
            updateData.type = 'BON_COMM';
            updateData.numero = await this.generateNextNumber('BON_COMM');
            if (nouveauReste > 0) {
                updateData.statut = 'PARTIEL';
            }
        }
        const updatedFacture = await this.prisma.facture.update({
            where: { id: factureId },
            data: updateData,
        });
        if (updatedFacture.vendeurId &&
            (updatedFacture.statut === 'VALIDE' ||
                updatedFacture.statut === 'PARTIEL' ||
                updatedFacture.statut === 'PAYEE' ||
                updatedFacture.statut === 'BON_DE_COMMANDE')) {
            try {
                await this.commissionService.calculateForInvoice(updatedFacture.id);
            }
            catch (e) {
                console.error('⚠️ [COMMISSION] Failed to calculate commissions after payment:', e);
            }
        }
        return paiement;
    }
    async generateNextNumber(type) {
        const year = new Date().getFullYear();
        const prefix = 'BC';
        const lastDoc = await this.prisma.facture.findFirst({
            where: {
                numero: {
                    startsWith: `${prefix}-${year}`,
                },
            },
            orderBy: {
                numero: 'desc',
            },
        });
        let sequence = 1;
        if (lastDoc) {
            const parts = lastDoc.numero.split('-');
            if (parts.length === 3) {
                const lastSeq = parseInt(parts[2]);
                if (!isNaN(lastSeq))
                    sequence = lastSeq + 1;
            }
        }
        return `${prefix}-${year}-${sequence.toString().padStart(3, '0')}`;
    }
    async handleCaisseIntegration(tx, paiement, facture, userId) {
        console.log(`[Caisse-Integration] Processing payment ${paiement.id} (${paiement.mode}, ${paiement.montant}DH) for Facture ${facture?.numero}`);
        const existingPaiement = await tx.paiement.findUnique({
            where: { id: paiement.id },
            select: { operationCaisseId: true },
        });
        if (existingPaiement?.operationCaisseId) {
            console.warn(`[Caisse-Integration] ⚠️ DOUBLON DÉTECTÉ — paiement ${paiement.id} est déjà lié à l'opération ${existingPaiement.operationCaisseId}. Annulation.`);
            return;
        }
        let targetCentreId = facture?.centreId;
        if (!targetCentreId && facture?.clientId) {
            console.log(`[Caisse-Integration] Facture ${facture.id} missing centreId. Resolving from client...`);
            const client = await tx.client.findUnique({
                where: { id: facture.clientId },
                select: { centreId: true }
            });
            targetCentreId = client?.centreId;
        }
        if (!targetCentreId) {
            console.warn(`[Caisse-Integration] Skipping: Facture ${facture?.id} has no centreId (Ref: ${facture?.numero})`);
            return;
        }
        const isRefund = paiement.montant < 0;
        let caisseType = 'PRINCIPALE';
        if (isRefund) {
            const expenseJournee = await tx.journeeCaisse.findFirst({
                where: {
                    centreId: targetCentreId,
                    statut: 'OUVERTE',
                    caisse: { type: { in: ['DEPENSES', 'MIXTE'] } },
                },
            });
            if (!expenseJournee) {
                throw new common_1.BadRequestException('Le remboursement nécessite une caisse de dépenses ouverte pour ce centre');
            }
            caisseType = 'DEPENSES';
        }
        const openSessions = await tx.journeeCaisse.findMany({
            where: {
                centreId: targetCentreId,
                statut: 'OUVERTE',
                caisse: {
                    OR: [{ type: caisseType }, { type: 'MIXTE' }],
                },
            },
            include: { caisse: true },
        });
        const openJournee = openSessions.find((j) => j.caisse.type === 'MIXTE') || openSessions[0];
        if (openJournee) {
            const absMontant = Math.abs(paiement.montant);
            if (caisseType === 'DEPENSES' && isRefund) {
                const availableCash = openJournee.fondInitial +
                    openJournee.totalInterne -
                    openJournee.totalDepenses;
                if (availableCash < absMontant) {
                    await tx.demandeAlimentation.create({
                        data: {
                            montant: absMontant,
                            paiementId: paiement.id,
                            journeeCaisseId: openJournee.id,
                            statut: 'EN_ATTENTE',
                        },
                    });
                    await tx.paiement.update({
                        where: { id: paiement.id },
                        data: { statut: 'EN_ATTENTE_ALIMENTATION' },
                    });
                    return;
                }
            }
            const operation = await tx.operationCaisse.create({
                data: {
                    type: isRefund ? 'DECAISSEMENT' : 'ENCAISSEMENT',
                    typeOperation: 'COMPTABLE',
                    montant: absMontant,
                    moyenPaiement: paiement.mode,
                    reference: paiement.reference || `FAC ${facture.numero}`,
                    motif: isRefund
                        ? 'Régularisation Avoir'
                        : `Paiement: FAC ${facture.numero}`,
                    utilisateur: userId ? `User ${userId} ` : 'Système',
                    userId: userId || null,
                    journeeCaisseId: openJournee.id,
                    factureId: facture.id,
                },
            });
            await tx.paiement.update({
                where: { id: paiement.id },
                data: { operationCaisseId: operation.id },
            });
            if (caisseType === 'DEPENSES') {
                await tx.journeeCaisse.update({
                    where: { id: openJournee.id },
                    data: {
                        totalDepenses: { increment: absMontant },
                    },
                });
            }
            else {
                await tx.journeeCaisse.update({
                    where: { id: openJournee.id },
                    data: {
                        totalComptable: { increment: paiement.montant },
                        totalVentesEspeces: (paiement.mode === 'ESPECES' || paiement.mode === 'ESPECE')
                            ? { increment: paiement.montant }
                            : undefined,
                        totalVentesCarte: paiement.mode === 'CARTE'
                            ? { increment: paiement.montant }
                            : undefined,
                        totalVentesCheque: (paiement.mode === 'CHEQUE' || paiement.mode === 'CHÈQUE')
                            ? { increment: paiement.montant }
                            : undefined,
                    },
                });
            }
        }
    }
    async findAll(factureId) {
        if (factureId) {
            return this.prisma.paiement.findMany({
                where: { factureId },
                include: { facture: true },
                orderBy: { date: 'desc' },
            });
        }
        return this.prisma.paiement.findMany({
            include: { facture: true },
            orderBy: { date: 'desc' },
            take: 100,
        });
    }
    async findOne(id) {
        const paiement = await this.prisma.paiement.findUnique({
            where: { id },
            include: { facture: true },
        });
        if (!paiement) {
            throw new common_1.NotFoundException(`Paiement ${id} non trouvé`);
        }
        return paiement;
    }
    async update(id, updatePaiementDto) {
        const paiement = await this.prisma.paiement.findUnique({
            where: { id },
            include: { operationCaisse: true, facture: true },
        });
        if (!paiement) {
            throw new common_1.NotFoundException(`Paiement ${id} non trouvé`);
        }
        if (updatePaiementDto.montant !== undefined &&
            updatePaiementDto.montant !== paiement.montant) {
            const facture = await this.prisma.facture.findUnique({
                where: { id: paiement.factureId },
                include: { paiements: true },
            });
            if (!facture)
                throw new common_1.NotFoundException('Facture non trouvée');
            const totalAutresPaiements = facture.paiements
                .filter((p) => p.id !== id)
                .reduce((sum, p) => sum + p.montant, 0);
            const nouveauTotal = totalAutresPaiements + updatePaiementDto.montant;
            const nouveauReste = facture.totalTTC - nouveauTotal;
            if (nouveauReste < -0.05) {
                throw new common_1.BadRequestException(`Le nouveau montant dépasse le total de la facture (Reste: ${nouveauReste})`);
            }
            await this.prisma.facture.update({
                where: { id: paiement.factureId },
                data: {
                    resteAPayer: Math.max(0, nouveauReste),
                    statut: nouveauReste <= 0.05 ? 'PAYEE' : 'PARTIEL',
                },
            });
        }
        const opId = paiement.operationCaisseId;
        if (opId) {
            await this.prisma.$transaction(async (tx) => {
                const op = await tx.operationCaisse.findUnique({
                    where: { id: opId },
                    include: { journeeCaisse: true },
                });
                if (op && op.journeeCaisse?.statut === 'OUVERTE') {
                    const journeeCaisse = op.journeeCaisse;
                    const newMode = updatePaiementDto.mode || paiement.mode;
                    const newMontant = updatePaiementDto.montant !== undefined
                        ? Math.abs(updatePaiementDto.montant)
                        : op.montant;
                    await tx.journeeCaisse.update({
                        where: { id: op.journeeCaisseId },
                        data: {
                            totalComptable: { decrement: paiement.montant },
                            totalVentesEspeces: op.moyenPaiement === 'ESPECES'
                                ? { decrement: op.montant }
                                : undefined,
                            totalVentesCarte: op.moyenPaiement === 'CARTE'
                                ? { decrement: op.montant }
                                : undefined,
                            totalVentesCheque: op.moyenPaiement === 'CHEQUE'
                                ? { decrement: op.montant }
                                : undefined,
                        },
                    });
                    await tx.operationCaisse.update({
                        where: { id: op.id },
                        data: {
                            montant: newMontant,
                            moyenPaiement: newMode,
                            reference: updatePaiementDto.reference || op.reference,
                        },
                    });
                    await tx.journeeCaisse.update({
                        where: { id: op.journeeCaisseId },
                        data: {
                            totalComptable: {
                                increment: updatePaiementDto.montant !== undefined
                                    ? updatePaiementDto.montant
                                    : paiement.montant,
                            },
                            totalVentesEspeces: ['ESPECES', 'ESPECE'].includes(newMode)
                                ? { increment: newMontant }
                                : undefined,
                            totalVentesCarte: newMode === 'CARTE' ? { increment: newMontant } : undefined,
                            totalVentesCheque: newMode === 'CHEQUE' ? { increment: newMontant } : undefined,
                        },
                    });
                }
            });
        }
        if (updatePaiementDto.statut === 'ENCAISSE' &&
            paiement.statut !== 'ENCAISSE' &&
            !updatePaiementDto.dateEncaissement) {
            updatePaiementDto.dateEncaissement = new Date().toISOString();
        }
        return this.prisma.paiement.update({
            where: { id },
            data: updatePaiementDto,
        });
    }
    async remove(id) {
    }
    async adminRepair() {
        const fs = require('fs');
        const logFile = 'repair-debug.log';
        const log = (msg) => {
            console.log(msg);
            fs.appendFileSync(logFile, msg + '\n');
        };
        fs.writeFileSync(logFile, `--- Repair Start ${new Date().toISOString()} ---\n`);
        const allPayments = await this.prisma.paiement.findMany({
            where: { mode: { in: ['ESPECES', 'CARTE', 'CHEQUE'] } },
            include: {
                operationCaisse: { include: { journeeCaisse: true } },
                facture: {
                    select: {
                        numero: true,
                        type: true,
                        dateEmission: true,
                        totalTTC: true,
                        resteAPayer: true,
                        statut: true,
                        client: {
                            select: {
                                nom: true,
                                prenom: true,
                                raisonSociale: true,
                            },
                        },
                    },
                },
            },
        });
        log(`Found ${allPayments.length} relevant payments.`);
        let fixedCount = 0;
        const details = [];
        const orphans = [];
        for (const p of allPayments) {
            const op = p.operationCaisse;
            if (!op) {
                const clientName = p.facture?.client?.raisonSociale ||
                    `${p.facture?.client?.prenom || ''} ${p.facture?.client?.nom || ''}`.trim();
                const orphanInfo = {
                    id: p.id,
                    montant: p.montant,
                    mode: p.mode,
                    date: p.date,
                    reference: p.reference,
                    statut: p.statut,
                    facture: {
                        numero: p.facture?.numero,
                        type: p.facture?.type,
                        client: clientName,
                        totalTTC: p.facture?.totalTTC,
                        resteAPayer: p.facture?.resteAPayer,
                    },
                };
                orphans.push(orphanInfo);
                log(`⚠️ ORPHAN: Payment ${p.id} (${p.mode} ${p.montant} DH) - Doc: ${p.facture?.numero} - Client: ${clientName}`);
                continue;
            }
            const needsModeFix = p.mode !== op.moyenPaiement;
            const needsAmountFix = Math.abs(p.montant) !== op.montant;
            if (needsModeFix || needsAmountFix) {
                const info = `Mismatch Payment ${p.id} (Ref: ${p.reference}): Paiement(${p.mode} ${p.montant}) vs Op(${op.moyenPaiement} ${op.montant})`;
                log(`✅ FIXING: ${info}`);
                details.push(info);
                await this.prisma.$transaction(async (tx) => {
                    await tx.journeeCaisse.update({
                        where: { id: op.journeeCaisseId },
                        data: {
                            totalVentesEspeces: op.moyenPaiement === 'ESPECES'
                                ? { decrement: op.montant }
                                : undefined,
                            totalVentesCarte: op.moyenPaiement === 'CARTE'
                                ? { decrement: op.montant }
                                : undefined,
                            totalVentesCheque: op.moyenPaiement === 'CHEQUE'
                                ? { decrement: op.montant }
                                : undefined,
                        },
                    });
                    await tx.operationCaisse.update({
                        where: { id: op.id },
                        data: {
                            moyenPaiement: p.mode,
                            montant: Math.abs(p.montant),
                        },
                    });
                    const absMontant = Math.abs(p.montant);
                    await tx.journeeCaisse.update({
                        where: { id: op.journeeCaisseId },
                        data: {
                            totalVentesEspeces: ['ESPECES', 'ESPECE'].includes(p.mode)
                                ? { increment: absMontant }
                                : undefined,
                            totalVentesCarte: p.mode === 'CARTE' ? { increment: absMontant } : undefined,
                            totalVentesCheque: p.mode === 'CHEQUE' ? { increment: absMontant } : undefined,
                        },
                    });
                });
                fixedCount++;
            }
        }
        const result = {
            message: `Repair Finished. Fixed ${fixedCount} mismatches.`,
            orphanCount: orphans.length,
            orphans,
            details,
        };
        log(JSON.stringify(result, null, 2));
        return result;
    }
    async repairOrphanOperations() {
        const orphanPayments = await this.prisma.paiement.findMany({
            where: {
                mode: { in: ['ESPECES', 'CARTE', 'CHEQUE'] },
                operationCaisseId: null,
            },
            include: {
                facture: {
                    include: {
                        client: true,
                        fiche: { include: { client: true } },
                    },
                },
            },
        });
        if (orphanPayments.length === 0) {
            return { message: 'No orphan payments found', fixed: 0 };
        }
        const journee = await this.prisma.journeeCaisse.findFirst({
            where: { statut: 'OUVERTE' },
            orderBy: { dateOuverture: 'desc' },
        });
        if (!journee) {
            throw new common_1.NotFoundException('No open caisse session found');
        }
        const fixed = [];
        for (const payment of orphanPayments) {
            try {
                await this.prisma.$transaction(async (tx) => {
                    let userName = 'Système';
                    let userId = payment.vendeurId;
                    if (userId) {
                        const user = await tx.user.findUnique({ where: { id: userId } });
                        if (user) {
                            userName = `${user.prenom} ${user.nom}`;
                        }
                    }
                    else {
                        const admin = await tx.user.findFirst();
                        if (admin) {
                            userId = admin.id;
                            userName = `${admin.prenom} ${admin.nom}`;
                        }
                    }
                    const operation = await tx.operationCaisse.create({
                        data: {
                            journeeCaisseId: journee.id,
                            type: 'VENTE',
                            moyenPaiement: payment.mode,
                            montant: Math.abs(payment.montant),
                            reference: payment.facture?.numero || '',
                            motif: `Réparation: Paiement ${payment.mode}`,
                            utilisateur: userName,
                            userId: userId,
                        },
                    });
                    await tx.paiement.update({
                        where: { id: payment.id },
                        data: { operationCaisseId: operation.id },
                    });
                    const montant = Math.abs(payment.montant);
                    await tx.journeeCaisse.update({
                        where: { id: journee.id },
                        data: {
                            totalComptable: { increment: montant },
                            totalVentesEspeces: ['ESPECES', 'ESPECE'].includes(payment.mode)
                                ? { increment: montant }
                                : undefined,
                            totalVentesCarte: payment.mode === 'CARTE' ? { increment: montant } : undefined,
                            totalVentesCheque: payment.mode === 'CHEQUE' ? { increment: montant } : undefined,
                        },
                    });
                    fixed.push({
                        paymentId: payment.id,
                        montant: payment.montant,
                        mode: payment.mode,
                        document: payment.facture?.numero,
                    });
                });
            }
            catch (error) {
                console.error(`Failed to repair payment ${payment.id}:`, error);
            }
        }
        return {
            message: `Repaired ${fixed.length} orphan payments`,
            fixed,
        };
    }
    async deleteOrphanPayments() {
        const orphanIds = [
            '7849cabc-083c-4186-9429-a4cec25483d3',
            '7c316cd6-fa66-49db-9973-9622404e989f',
        ];
        const deleted = [];
        for (const paymentId of orphanIds) {
            try {
                const payment = await this.prisma.paiement.findUnique({
                    where: { id: paymentId },
                    include: {
                        operationCaisse: {
                            include: { journeeCaisse: true },
                        },
                        facture: true,
                    },
                });
                if (!payment) {
                    continue;
                }
                await this.prisma.$transaction(async (tx) => {
                    if (payment.operationCaisseId) {
                        const op = payment.operationCaisse;
                        await tx.journeeCaisse.update({
                            where: { id: op.journeeCaisseId },
                            data: {
                                totalComptable: { decrement: op.montant },
                                totalVentesEspeces: ['ESPECES', 'ESPECE'].includes(op.moyenPaiement)
                                    ? { decrement: op.montant }
                                    : undefined,
                                totalVentesCarte: op.moyenPaiement === 'CARTE'
                                    ? { decrement: op.montant }
                                    : undefined,
                                totalVentesCheque: op.moyenPaiement === 'CHEQUE'
                                    ? { decrement: op.montant }
                                    : undefined,
                            },
                        });
                        await tx.operationCaisse.delete({
                            where: { id: payment.operationCaisseId },
                        });
                    }
                    if (payment.facture) {
                        const facture = payment.facture;
                        const nouveauReste = (facture.resteAPayer || 0) + payment.montant;
                        const nouveauStatut = Math.abs(nouveauReste - (facture.totalTTC || 0)) < 0.01
                            ? 'VALIDE'
                            : 'PARTIEL';
                        await tx.facture.update({
                            where: { id: payment.factureId },
                            data: {
                                resteAPayer: nouveauReste,
                                statut: nouveauStatut,
                            },
                        });
                    }
                    await tx.paiement.delete({
                        where: { id: paymentId },
                    });
                    deleted.push({
                        paymentId,
                        montant: payment.montant,
                        mode: payment.mode,
                        document: payment.facture?.numero,
                    });
                });
            }
            catch (error) {
                console.error(`Failed to delete payment ${paymentId}:`, error);
            }
        }
        return {
            message: `Deleted ${deleted.length} orphan payments`,
            deleted,
        };
    }
};
exports.PaiementsService = PaiementsService;
exports.PaiementsService = PaiementsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        stock_availability_service_1.StockAvailabilityService,
        commission_service_1.CommissionService])
], PaiementsService);
//# sourceMappingURL=paiements.service.js.map