export declare class PaiementsModule {
}
