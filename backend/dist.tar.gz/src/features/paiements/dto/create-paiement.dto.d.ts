export declare class CreatePaiementDto {
    factureId: string;
    montant: number;
    date?: string;
    mode: string;
    reference?: string;
    notes?: string;
    dateVersement?: string;
    banque?: string;
    tiersNom?: string;
    tiersCin?: string;
    remarque?: string;
    pieceJointe?: string;
    statut?: string;
    dateEncaissement?: string;
}
