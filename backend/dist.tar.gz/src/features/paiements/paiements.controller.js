"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaiementsController = void 0;
const common_1 = require("@nestjs/common");
const jwt = __importStar(require("jsonwebtoken"));
const config_1 = require("@nestjs/config");
const paiements_service_1 = require("./paiements.service");
const create_paiement_dto_1 = require("./dto/create-paiement.dto");
const update_paiement_dto_1 = require("./dto/update-paiement.dto");
let PaiementsController = class PaiementsController {
    paiementsService;
    configService;
    constructor(paiementsService, configService) {
        this.paiementsService = paiementsService;
        this.configService = configService;
    }
    adminRepair() {
        return this.paiementsService.adminRepair();
    }
    repairOrphans() {
        return this.paiementsService.repairOrphanOperations();
    }
    deleteOrphans() {
        return this.paiementsService.deleteOrphanPayments();
    }
    create(createPaiementDto, authHeader) {
        const userId = this.getUserId(authHeader);
        return this.paiementsService.create(createPaiementDto, userId);
    }
    getUserId(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer '))
            return undefined;
        try {
            const token = authHeader.split(' ')[1];
            const secret = this.configService.get('JWT_SECRET') || 'your-very-secret-key';
            const payload = jwt.verify(token, secret);
            return payload.sub;
        }
        catch (e) {
            return undefined;
        }
    }
    findAll(factureId) {
        return this.paiementsService.findAll(factureId);
    }
    findOne(id) {
        return this.paiementsService.findOne(id);
    }
    update(id, updatePaiementDto) {
        return this.paiementsService.update(id, updatePaiementDto);
    }
    remove(id) {
        return this.paiementsService.remove(id);
    }
};
exports.PaiementsController = PaiementsController;
__decorate([
    (0, common_1.Get)('do-repair'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "adminRepair", null);
__decorate([
    (0, common_1.Get)('repair-orphans'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "repairOrphans", null);
__decorate([
    (0, common_1.Get)('delete-orphans'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "deleteOrphans", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_paiement_dto_1.CreatePaiementDto, String]),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('factureId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_paiement_dto_1.UpdatePaiementDto]),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaiementsController.prototype, "remove", null);
exports.PaiementsController = PaiementsController = __decorate([
    (0, common_1.Controller)('paiements'),
    __metadata("design:paramtypes", [paiements_service_1.PaiementsService,
        config_1.ConfigService])
], PaiementsController);
//# sourceMappingURL=paiements.controller.js.map