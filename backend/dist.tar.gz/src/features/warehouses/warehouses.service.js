"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehousesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let WarehousesService = class WarehousesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createEntrepotDto) {
        return this.prisma.entrepot.create({
            data: createEntrepotDto,
            include: {
                centre: {
                    include: {
                        groupe: true,
                    },
                },
            },
        });
    }
    async findAll(centreId) {
        return this.prisma.entrepot.findMany({
            where: centreId ? { centreId } : undefined,
            include: {
                centre: {
                    include: {
                        groupe: true,
                    },
                },
                _count: {
                    select: {
                        produits: true,
                    },
                },
            },
        });
    }
    async findOne(id) {
        const entrepot = await this.prisma.entrepot.findUnique({
            where: { id },
            include: {
                centre: {
                    include: {
                        groupe: true,
                    },
                },
                produits: {
                    include: {
                        mouvements: {
                            take: 1,
                            orderBy: { createdAt: 'desc' },
                            include: {
                                entrepotSource: true,
                            },
                        },
                    },
                },
                _count: {
                    select: {
                        produits: true,
                    },
                },
            },
        });
        if (!entrepot) {
            throw new common_1.NotFoundException(`Entrepot with ID ${id} not found`);
        }
        const incomingProducts = await this.prisma.product.findMany({
            where: {
                statut: 'RESERVE',
                specificData: {
                    path: ['pendingIncoming', 'targetWarehouseId'],
                    equals: id,
                },
            },
        });
        const allProducts = [...entrepot.produits, ...incomingProducts];
        return {
            ...entrepot,
            produits: allProducts,
        };
    }
    async getStockSummary(id) {
        const entrepot = await this.findOne(id);
        const stockStats = await this.prisma.product.aggregate({
            where: { entrepotId: id },
            _sum: {
                quantiteActuelle: true,
                prixVenteHT: true,
            },
            _count: true,
        });
        return {
            entrepot: {
                id: entrepot.id,
                nom: entrepot.nom,
                type: entrepot.type,
            },
            totalProducts: stockStats._count,
            totalQuantity: stockStats._sum.quantiteActuelle || 0,
            totalValue: stockStats._sum.prixVenteHT || 0,
        };
    }
    async update(id, updateEntrepotDto) {
        try {
            return await this.prisma.entrepot.update({
                where: { id },
                data: updateEntrepotDto,
                include: {
                    centre: {
                        include: {
                            groupe: true,
                        },
                    },
                },
            });
        }
        catch (error) {
            throw new common_1.NotFoundException(`Entrepot with ID ${id} not found`);
        }
    }
    async remove(id) {
        try {
            await this.prisma.entrepot.delete({
                where: { id },
            });
            return { message: `Entrepot with ID ${id} deleted successfully` };
        }
        catch (error) {
            throw new common_1.NotFoundException(`Entrepot with ID ${id} not found`);
        }
    }
};
exports.WarehousesService = WarehousesService;
exports.WarehousesService = WarehousesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WarehousesService);
//# sourceMappingURL=warehouses.service.js.map