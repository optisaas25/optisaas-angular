export declare enum EntrepotType {
    PRINCIPAL = "PRINCIPAL",
    SECONDAIRE = "SECONDAIRE",
    TRANSIT = "TRANSIT"
}
export declare class CreateEntrepotDto {
    nom: string;
    description?: string;
    type: EntrepotType;
    capaciteMax?: number;
    surface?: number;
    responsable?: string;
    centreId: string;
}
