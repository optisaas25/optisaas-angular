export declare class WarehousesModule {
}
