import { WarehousesService } from './warehouses.service';
import { CreateEntrepotDto } from './dto/create-entrepot.dto';
import { UpdateEntrepotDto } from './dto/update-entrepot.dto';
export declare class WarehousesController {
    private readonly warehousesService;
    constructor(warehousesService: WarehousesService);
    create(createEntrepotDto: CreateEntrepotDto): Promise<{
        centre: {
            groupe: {
                id: string;
                type: string | null;
                createdAt: Date;
                updatedAt: Date;
                nom: string;
                description: string | null;
                adresse: string | null;
                telephone: string | null;
                email: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
        capaciteMax: number | null;
        surface: number | null;
        responsable: string | null;
    }>;
    findAll(centreId?: string): Promise<({
        centre: {
            groupe: {
                id: string;
                type: string | null;
                createdAt: Date;
                updatedAt: Date;
                nom: string;
                description: string | null;
                adresse: string | null;
                telephone: string | null;
                email: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
        _count: {
            produits: number;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
        capaciteMax: number | null;
        surface: number | null;
        responsable: string | null;
    })[]>;
    findOne(id: string): Promise<{
        produits: {
            id: string;
            statut: string;
            createdAt: Date;
            updatedAt: Date;
            codeInterne: string;
            codeBarres: string;
            referenceFournisseur: string | null;
            designation: string;
            marque: string | null;
            modele: string | null;
            couleur: string | null;
            typeArticle: string;
            famille: string | null;
            sousFamille: string | null;
            fournisseurPrincipal: string | null;
            quantiteActuelle: number;
            seuilAlerte: number;
            prixAchatHT: number;
            coefficient: number;
            prixVenteHT: number;
            prixVenteTTC: number;
            tauxTVA: number;
            photo: string | null;
            utilisateurCreation: string;
            specificData: import("@prisma/client/runtime/library").JsonValue | null;
            entrepotId: string;
        }[];
        centre: {
            groupe: {
                id: string;
                type: string | null;
                createdAt: Date;
                updatedAt: Date;
                nom: string;
                description: string | null;
                adresse: string | null;
                telephone: string | null;
                email: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
        _count: {
            produits: number;
        };
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
        capaciteMax: number | null;
        surface: number | null;
        responsable: string | null;
    }>;
    getStockSummary(id: string): Promise<{
        entrepot: {
            id: string;
            nom: string;
            type: string;
        };
        totalProducts: number;
        totalQuantity: number;
        totalValue: number;
    }>;
    update(id: string, updateEntrepotDto: UpdateEntrepotDto): Promise<{
        centre: {
            groupe: {
                id: string;
                type: string | null;
                createdAt: Date;
                updatedAt: Date;
                nom: string;
                description: string | null;
                adresse: string | null;
                telephone: string | null;
                email: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            nom: string;
            description: string | null;
            adresse: string | null;
            ville: string | null;
            codePostal: string | null;
            telephone: string | null;
            email: string | null;
            groupeId: string;
        };
    } & {
        id: string;
        type: string;
        createdAt: Date;
        updatedAt: Date;
        centreId: string;
        nom: string;
        description: string | null;
        capaciteMax: number | null;
        surface: number | null;
        responsable: string | null;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
