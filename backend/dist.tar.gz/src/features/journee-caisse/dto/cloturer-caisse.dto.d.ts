export declare class CloturerCaisseDto {
    soldeReel: number;
    nbRecuCarte: number;
    montantTotalCarte: number;
    nbRecuCheque: number;
    montantTotalCheque: number;
    justificationEcart?: string;
    responsableCloture: string;
}
