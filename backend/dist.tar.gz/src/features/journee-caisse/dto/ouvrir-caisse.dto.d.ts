export declare class OuvrirCaisseDto {
    caisseId: string;
    centreId: string;
    fondInitial: number;
    caissier: string;
}
