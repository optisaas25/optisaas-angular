"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JourneeCaisseController = void 0;
const common_1 = require("@nestjs/common");
const journee_caisse_service_1 = require("./journee-caisse.service");
const ouvrir_caisse_dto_1 = require("./dto/ouvrir-caisse.dto");
const cloturer_caisse_dto_1 = require("./dto/cloturer-caisse.dto");
let JourneeCaisseController = class JourneeCaisseController {
    journeeCaisseService;
    constructor(journeeCaisseService) {
        this.journeeCaisseService = journeeCaisseService;
    }
    ouvrir(ouvrirCaisseDto) {
        return this.journeeCaisseService.ouvrir(ouvrirCaisseDto);
    }
    cloturer(id, cloturerCaisseDto) {
        return this.journeeCaisseService.cloturer(id, cloturerCaisseDto);
    }
    findOne(id) {
        return this.journeeCaisseService.findOne(id);
    }
    getActiveByCaisse(caisseId) {
        return this.journeeCaisseService.getActiveByCaisse(caisseId);
    }
    findByCentre(centreId) {
        return this.journeeCaisseService.findByCentre(centreId);
    }
    findHistory(centreId, startDate, endDate) {
        return this.journeeCaisseService.findHistory(centreId, startDate, endDate);
    }
    getResume(id, startDate, endDate) {
        return this.journeeCaisseService.getResume(id, startDate, endDate);
    }
    getLastClosingBalance(caisseId) {
        return this.journeeCaisseService.getLastClosingBalance(caisseId);
    }
};
exports.JourneeCaisseController = JourneeCaisseController;
__decorate([
    (0, common_1.Post)('ouvrir'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ouvrir_caisse_dto_1.OuvrirCaisseDto]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "ouvrir", null);
__decorate([
    (0, common_1.Post)(':id/cloturer'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, cloturer_caisse_dto_1.CloturerCaisseDto]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "cloturer", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('caisse/:caisseId/active'),
    __param(0, (0, common_1.Param)('caisseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "getActiveByCaisse", null);
__decorate([
    (0, common_1.Get)('centre/:centreId'),
    __param(0, (0, common_1.Param)('centreId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "findByCentre", null);
__decorate([
    (0, common_1.Get)('centre/:centreId/history'),
    __param(0, (0, common_1.Param)('centreId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "findHistory", null);
__decorate([
    (0, common_1.Get)(':id/resume'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "getResume", null);
__decorate([
    (0, common_1.Get)('caisse/:caisseId/last-balance'),
    __param(0, (0, common_1.Param)('caisseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], JourneeCaisseController.prototype, "getLastClosingBalance", null);
exports.JourneeCaisseController = JourneeCaisseController = __decorate([
    (0, common_1.Controller)('journee-caisse'),
    __metadata("design:paramtypes", [journee_caisse_service_1.JourneeCaisseService])
], JourneeCaisseController);
//# sourceMappingURL=journee-caisse.controller.js.map