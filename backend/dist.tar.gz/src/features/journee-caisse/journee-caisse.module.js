"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JourneeCaisseModule = void 0;
const common_1 = require("@nestjs/common");
const journee_caisse_service_1 = require("./journee-caisse.service");
const journee_caisse_controller_1 = require("./journee-caisse.controller");
const prisma_module_1 = require("../../prisma/prisma.module");
let JourneeCaisseModule = class JourneeCaisseModule {
};
exports.JourneeCaisseModule = JourneeCaisseModule;
exports.JourneeCaisseModule = JourneeCaisseModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [journee_caisse_controller_1.JourneeCaisseController],
        providers: [journee_caisse_service_1.JourneeCaisseService],
        exports: [journee_caisse_service_1.JourneeCaisseService],
    })
], JourneeCaisseModule);
//# sourceMappingURL=journee-caisse.module.js.map