"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JourneeCaisseService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let JourneeCaisseService = class JourneeCaisseService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async ouvrir(ouvrirCaisseDto) {
        const caisse = await this.prisma.caisse.findUnique({
            where: { id: ouvrirCaisseDto.caisseId },
        });
        if (!caisse) {
            throw new common_1.NotFoundException('Caisse introuvable');
        }
        const existingSession = await this.prisma.journeeCaisse.findFirst({
            where: {
                caisseId: ouvrirCaisseDto.caisseId,
                statut: 'OUVERTE',
            },
        });
        if (existingSession) {
            throw new common_1.ConflictException('Une journée de caisse est déjà ouverte pour cette caisse');
        }
        let caissierName = ouvrirCaisseDto.caissier;
        if (ouvrirCaisseDto.caissier.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
            const user = await this.prisma.user.findUnique({
                where: { id: ouvrirCaisseDto.caissier },
                select: { nom: true, prenom: true },
            });
            if (user) {
                caissierName = `${user.prenom} ${user.nom}`;
            }
        }
        return this.prisma.journeeCaisse.create({
            data: {
                caisseId: ouvrirCaisseDto.caisseId,
                centreId: ouvrirCaisseDto.centreId,
                fondInitial: ouvrirCaisseDto.fondInitial,
                caissier: caissierName,
            },
            include: {
                caisse: true,
                centre: true,
            },
        });
    }
    async cloturer(id, cloturerCaisseDto) {
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id },
            include: {
                operations: true,
            },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Journée de caisse introuvable');
        }
        if (journee.statut === 'FERMEE') {
            throw new common_1.ConflictException('Cette journée de caisse est déjà fermée');
        }
        const stats = {
            grossVentesEspeces: 0,
            grossVentesCarte: 0,
            grossVentesCheque: 0,
            nbVentesCarte: 0,
            nbVentesCheque: 0,
            totalInterneIn: 0,
            totalOutflowsEspeces: 0,
        };
        journee.operations.forEach((op) => {
            if (op.type === 'ENCAISSEMENT') {
                if (op.typeOperation === 'COMPTABLE' ||
                    op.typeOperation === 'INTERNE') {
                    if (op.moyenPaiement === 'ESPECES') {
                        if (op.typeOperation === 'COMPTABLE')
                            stats.grossVentesEspeces += op.montant;
                        else
                            stats.totalInterneIn += op.montant;
                    }
                    else if (op.moyenPaiement === 'CARTE') {
                        stats.grossVentesCarte += op.montant;
                        stats.nbVentesCarte++;
                    }
                    else if (op.moyenPaiement === 'CHEQUE') {
                        stats.grossVentesCheque += op.montant;
                        stats.nbVentesCheque++;
                    }
                }
            }
            else if (op.type === 'DECAISSEMENT') {
                if (op.moyenPaiement === 'ESPECES') {
                    stats.totalOutflowsEspeces += op.montant;
                }
            }
        });
        const soldeTheoriqueEspeces = (journee.fondInitial || 0) +
            stats.totalInterneIn +
            stats.grossVentesEspeces -
            stats.totalOutflowsEspeces;
        const soldeTheoriqueCarte = stats.grossVentesCarte;
        const soldeTheoriqueCheque = stats.grossVentesCheque;
        const ecartEspeces = cloturerCaisseDto.soldeReel - soldeTheoriqueEspeces;
        const ecartCarteMontant = cloturerCaisseDto.montantTotalCarte - soldeTheoriqueCarte;
        const ecartChequeMontant = cloturerCaisseDto.montantTotalCheque - soldeTheoriqueCheque;
        const ecartCarteNombre = cloturerCaisseDto.nbRecuCarte - stats.nbVentesCarte;
        const ecartChequeNombre = cloturerCaisseDto.nbRecuCheque - stats.nbVentesCheque;
        const hasAnyDiscrepancy = Math.abs(ecartEspeces) > 0.01 ||
            Math.abs(ecartCarteMontant) > 0.01 ||
            Math.abs(ecartChequeMontant) > 0.01 ||
            ecartCarteNombre !== 0 ||
            ecartChequeNombre !== 0;
        if (hasAnyDiscrepancy && !cloturerCaisseDto.justificationEcart) {
            throw new common_1.BadRequestException('Une justification est requise car un écart a été détecté (montant ou nombre de reçus).');
        }
        let responsableName = cloturerCaisseDto.responsableCloture;
        if (cloturerCaisseDto.responsableCloture.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
            const user = await this.prisma.user.findUnique({
                where: { id: cloturerCaisseDto.responsableCloture },
                select: { nom: true, prenom: true },
            });
            if (user) {
                responsableName = `${user.prenom} ${user.nom}`;
            }
        }
        return this.prisma.journeeCaisse.update({
            where: { id },
            data: {
                statut: 'FERMEE',
                dateCloture: new Date(),
                soldeTheorique: soldeTheoriqueEspeces,
                soldeReel: cloturerCaisseDto.soldeReel,
                ecart: ecartEspeces,
                justificationEcart: cloturerCaisseDto.justificationEcart,
                responsableCloture: responsableName,
            },
            include: {
                caisse: true,
                centre: true,
            },
        });
    }
    async findOne(id) {
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id },
            include: {
                caisse: true,
                centre: true,
            },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Journée de caisse introuvable');
        }
        return journee;
    }
    async findOneWithOperations(id) {
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id },
            include: {
                caisse: true,
                centre: true,
                operations: {
                    orderBy: {
                        createdAt: 'desc',
                    },
                    include: {
                        facture: {
                            select: {
                                numero: true,
                                client: {
                                    select: {
                                        nom: true,
                                        prenom: true,
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Journée de caisse introuvable');
        }
        return journee;
    }
    async getActiveByCaisse(caisseId) {
        const journee = await this.prisma.journeeCaisse.findFirst({
            where: {
                caisseId,
                statut: 'OUVERTE',
            },
            include: {
                caisse: true,
                centre: true,
                operations: {
                    orderBy: {
                        createdAt: 'desc',
                    },
                },
            },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Aucune journée de caisse ouverte pour cette caisse');
        }
        return journee;
    }
    async findByCentre(centreId, limit = 50) {
        return this.prisma.journeeCaisse.findMany({
            where: { centreId },
            include: {
                caisse: true,
            },
            orderBy: {
                dateOuverture: 'desc',
            },
            take: limit,
        });
    }
    async findHistory(centreId, startDate, endDate) {
        console.time('FindHistory');
        const where = {
            centreId,
            statut: 'FERMEE',
        };
        if (startDate || endDate) {
            where.dateCloture = {};
            if (startDate) {
                const start = new Date(startDate);
                start.setHours(0, 0, 0, 0);
                where.dateCloture.gte = start;
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.dateCloture.lte = end;
            }
        }
        const history = await this.prisma.journeeCaisse.findMany({
            where,
            orderBy: {
                dateCloture: 'desc',
            },
            take: startDate || endDate ? undefined : 100,
            include: {
                caisse: true,
            },
        });
        console.timeEnd('FindHistory');
        return history;
    }
    async getResume(id, startDate, endDate) {
        console.log(`[Caisse-Resume] getResume: ID=${id}, start=${startDate}, end=${endDate}`);
        const dateFilter = {};
        let hasFilter = false;
        if (startDate && startDate !== 'undefined' && startDate !== 'null') {
            const start = new Date(startDate);
            if (!isNaN(start.getTime())) {
                dateFilter.gte = start;
                hasFilter = true;
            }
        }
        if (endDate && endDate !== 'undefined' && endDate !== 'null') {
            const end = new Date(endDate);
            if (!isNaN(end.getTime())) {
                dateFilter.lte = end;
                hasFilter = true;
            }
        }
        if (hasFilter) {
            console.log('[Caisse-Resume] APPLYING FILTER:', JSON.stringify(dateFilter));
        }
        const journee = await this.prisma.journeeCaisse.findUnique({
            where: { id },
            include: {
                caisse: true,
                centre: true,
            },
        });
        if (!journee) {
            throw new common_1.NotFoundException('Journée de caisse introuvable');
        }
        console.timeEnd('GetResume-Step1-Metadata');
        console.time('GetResume-Step2-LocalStats');
        const localAggregates = await this.prisma.operationCaisse.groupBy({
            by: ['type', 'typeOperation', 'moyenPaiement'],
            where: {
                ...(Object.keys(dateFilter).length > 0
                    ? { journeeCaisse: { caisseId: journee.caisseId } }
                    : { journeeCaisseId: id }),
                ...(Object.keys(dateFilter).length > 0 ? { createdAt: dateFilter } : {}),
            },
            _sum: { montant: true },
            _count: { id: true },
        });
        const stats = {
            grossVentesEspeces: 0,
            grossVentesCarte: 0,
            grossVentesCheque: 0,
            netVentesEspeces: 0,
            netVentesCarte: 0,
            netVentesCheque: 0,
            nbVentesCarte: 0,
            nbVentesCheque: 0,
            totalInterneIn: 0,
            totalOutflows: 0,
            totalOutflowsCash: 0,
        };
        localAggregates.forEach((agg) => {
            const amount = agg._sum.montant || 0;
            const count = agg._count.id || 0;
            const { type, typeOperation, moyenPaiement } = agg;
            if (type === 'ENCAISSEMENT') {
                if (typeOperation === 'COMPTABLE') {
                    if (moyenPaiement === 'ESPECES' || moyenPaiement === 'ESPECE') {
                        stats.grossVentesEspeces += amount;
                        stats.netVentesEspeces += amount;
                    }
                    else if (moyenPaiement === 'CARTE') {
                        stats.grossVentesCarte += amount;
                        stats.netVentesCarte += amount;
                        stats.nbVentesCarte += count;
                    }
                    else if (moyenPaiement === 'CHEQUE' || moyenPaiement === 'LCN' || moyenPaiement === 'CHÈQUE') {
                        stats.grossVentesCheque += amount;
                        stats.netVentesCheque += amount;
                        stats.nbVentesCheque += count;
                    }
                }
                else if (typeOperation === 'INTERNE' && (moyenPaiement === 'ESPECES' || moyenPaiement === 'ESPECE')) {
                    stats.totalInterneIn += amount;
                }
            }
            else if (type === 'DECAISSEMENT') {
                stats.totalOutflows += amount;
                if (moyenPaiement === 'ESPECES' || moyenPaiement === 'ESPECE') {
                    stats.totalOutflowsCash += amount;
                }
                if (typeOperation === 'COMPTABLE') {
                    if (moyenPaiement === 'ESPECES' || moyenPaiement === 'ESPECE')
                        stats.netVentesEspeces -= amount;
                    else if (moyenPaiement === 'CARTE')
                        stats.netVentesCarte -= amount;
                    else if (moyenPaiement === 'CHEQUE' ||
                        moyenPaiement === 'LCN' ||
                        moyenPaiement === 'CHÈQUE')
                        stats.netVentesCheque -= amount;
                }
            }
        });
        console.timeEnd('GetResume-Step2-LocalStats');
        const isDepenses = journee.caisse.type === 'DEPENSES';
        const isMixte = journee.caisse.type === 'MIXTE';
        let centreVentesEspeces = 0;
        let centreVentesCarte = 0;
        let centreVentesCheque = 0;
        let centreNbVentesCarte = 0;
        let centreNbVentesCheque = 0;
        if (isDepenses || isMixte) {
            console.time('GetResume-Step3-GlobalStats');
            const openJournees = await this.prisma.journeeCaisse.findMany({
                where: {
                    centreId: journee.centreId,
                    ...(Object.keys(dateFilter).length > 0 ? {} : { statut: 'OUVERTE' }),
                },
                select: { id: true },
            });
            const openJourneeIds = openJournees.map((j) => j.id);
            const globalStats = await this.prisma.operationCaisse.groupBy({
                by: ['moyenPaiement'],
                where: {
                    journeeCaisseId: { in: openJourneeIds },
                    typeOperation: 'COMPTABLE',
                    type: 'ENCAISSEMENT',
                    ...(Object.keys(dateFilter).length > 0
                        ? { createdAt: dateFilter }
                        : {}),
                },
                _sum: {
                    montant: true,
                },
                _count: {
                    id: true,
                },
            });
            console.timeEnd('GetResume-Step3-GlobalStats-Agg');
            console.timeEnd('GetResume-Step3-GlobalStats');
            globalStats.forEach((stat) => {
                const amount = stat._sum.montant || 0;
                const count = stat._count.id || 0;
                if (stat.moyenPaiement === 'ESPECES' || stat.moyenPaiement === 'ESPECE') {
                    centreVentesEspeces += amount;
                }
                else if (stat.moyenPaiement === 'CARTE') {
                    centreVentesCarte += amount;
                    centreNbVentesCarte += count;
                }
                else if (stat.moyenPaiement === 'CHEQUE' ||
                    stat.moyenPaiement === 'LCN' ||
                    stat.moyenPaiement === 'CHÈQUE') {
                    centreVentesCheque += amount;
                    centreNbVentesCheque += count;
                }
            });
        }
        return {
            journee: {
                id: journee.id,
                dateOuverture: journee.dateOuverture,
                dateCloture: journee.dateCloture,
                statut: journee.statut,
                caissier: journee.caissier,
                caisse: journee.caisse,
                centre: journee.centre,
            },
            fondInitial: journee.fondInitial || 0,
            totalRecettes: isDepenses
                ? centreVentesEspeces + centreVentesCarte + centreVentesCheque
                : stats.netVentesEspeces + stats.netVentesCarte + stats.netVentesCheque,
            recettesDetails: {
                espaces: isDepenses ? centreVentesEspeces : stats.netVentesEspeces,
                carte: isDepenses ? centreVentesCarte : stats.netVentesCarte,
                cheque: isDepenses ? centreVentesCheque : stats.netVentesCheque,
                enCoffre: isDepenses ? centreVentesCheque : stats.netVentesCheque,
                carteCount: isDepenses ? centreNbVentesCarte : stats.nbVentesCarte,
                chequeCount: isDepenses ? centreNbVentesCheque : stats.nbVentesCheque,
                enCoffreCount: isDepenses ? centreNbVentesCheque : stats.nbVentesCheque,
            },
            totalVentesEspeces: stats.grossVentesEspeces,
            totalVentesCarte: stats.grossVentesCarte,
            totalVentesCheque: stats.grossVentesCheque,
            nbVentesCarte: stats.nbVentesCarte,
            nbVentesCheque: stats.nbVentesCheque,
            totalInterne: stats.totalInterneIn,
            totalDepenses: stats.totalOutflows,
            totalDepensesCash: stats.totalOutflowsCash,
            totalDepensesBank: stats.totalOutflows - stats.totalOutflowsCash,
            soldeTheorique: (journee.fondInitial || 0) +
                stats.totalInterneIn +
                stats.grossVentesEspeces -
                stats.totalOutflowsCash,
            soldeReel: (journee.fondInitial || 0) +
                stats.totalInterneIn +
                stats.grossVentesEspeces -
                stats.totalOutflowsCash,
            ecart: journee.ecart || 0,
        };
    }
    async getLastClosingBalance(caisseId) {
        const lastClosedSession = await this.prisma.journeeCaisse.findFirst({
            where: {
                caisseId,
                statut: 'FERMEE',
            },
            orderBy: {
                dateCloture: 'desc',
            },
            select: {
                soldeReel: true,
            },
        });
        return {
            amount: lastClosedSession?.soldeReel || 0,
        };
    }
};
exports.JourneeCaisseService = JourneeCaisseService;
exports.JourneeCaisseService = JourneeCaisseService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], JourneeCaisseService);
//# sourceMappingURL=journee-caisse.service.js.map