export declare class JourneeCaisseModule {
}
