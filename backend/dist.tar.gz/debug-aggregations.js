"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const bcMetrics = await prisma.facture.aggregate({ _sum: { totalTTC: true }, _count: true, where: { centreId, statut: 'VENTE_EN_INSTANCE' } }); const avoirMetrics = await prisma.facture.aggregate({ _sum: { totalTTC: true }, _count: true, where: { centreId, type: 'AVOIR' } }); console.log('BC Metrics:', bcMetrics); console.log('Avoir Metrics:', avoirMetrics); await prisma.$disconnect(); }
run();
//# sourceMappingURL=debug-aggregations.js.map