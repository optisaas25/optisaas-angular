"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    try {
        const result = await prisma.$queryRaw `
      SELECT table_name, column_name 
      FROM information_schema.columns 
      WHERE table_schema = 'public' AND column_name ILIKE '%factureFournisseurId%'
    `;
        console.log('Filtered columns:', result);
    }
    catch (e) {
        console.error(e);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=introspect-db.js.map