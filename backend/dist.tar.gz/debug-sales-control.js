"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
async function debugSalesControl() {
    const prisma = new client_1.PrismaClient();
    const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36';
    console.log(`--- Debugging Sales Control for Center: ${centreId} ---`);
    const countTotal = await prisma.facture.count({
        where: {
            centreId,
            OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }],
            statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] },
            type: { not: 'AVOIR' }
        }
    });
    console.log('Total Valid Factures (No Date Filter):', countTotal);
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    console.log(`\n--- Date Filter (Current Month): ${start.toISOString()} to ${end.toISOString()} ---`);
    const countMonth = await prisma.facture.count({
        where: {
            centreId,
            OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }],
            statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] },
            type: { not: 'AVOIR' },
            dateEmission: { gte: start, lte: end }
        }
    });
    console.log('Valid Factures for Current Month:', countMonth);
    const aggregate = await prisma.facture.aggregate({
        _sum: { totalTTC: true },
        _count: true,
        where: {
            centreId,
            OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }],
            statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] },
            type: { not: 'AVOIR' }
        }
    });
    console.log('\n--- Aggregate Result (No Date Filter) ---');
    console.log(JSON.stringify(aggregate, null, 2));
    const samples = await prisma.facture.findMany({
        where: {
            centreId,
            OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }],
            statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] },
            type: { not: 'AVOIR' }
        },
        take: 5,
        select: { numero: true, dateEmission: true, totalTTC: true, statut: true, type: true }
    });
    console.log('\n--- Samples ---');
    console.log(samples);
    await prisma.$disconnect();
}
debugSalesControl();
//# sourceMappingURL=debug-sales-control.js.map