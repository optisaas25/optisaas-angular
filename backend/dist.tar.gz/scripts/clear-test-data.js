"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function clearTestData() {
    console.log('🚀 Starting Data Clearance for Retest...');
    try {
        console.log('- Clearing Paiements, Commissions, Points, and Redemptions...');
        await prisma.paiement.deleteMany();
        await prisma.commission.deleteMany();
        await prisma.pointsHistory.deleteMany();
        await prisma.rewardRedemption.deleteMany();
        await prisma.demandeAlimentation.deleteMany();
        console.log('- Clearing OperationCaisses and MouvementsStock...');
        await prisma.operationCaisse.deleteMany();
        await prisma.mouvementStock.deleteMany();
        await prisma.factureFournisseur.updateMany({
            data: { clientId: null, ficheId: null }
        });
        console.log('- Clearing Factures...');
        await prisma.facture.deleteMany();
        console.log('- Clearing Fiches...');
        await prisma.fiche.deleteMany();
        console.log('- Clearing Clients...');
        await prisma.client.deleteMany();
        console.log('✅ All test data (Clients, Fiches, Factures, Paiements) has been cleared.');
    }
    catch (error) {
        console.error('❌ Error during clearance:', error.message);
    }
    finally {
        await prisma.$disconnect();
    }
}
clearTestData();
//# sourceMappingURL=clear-test-data.js.map