"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🚀 Starting Supplier & Invoice cleanup...');
    try {
        const updateMouvements = await prisma.mouvementStock.updateMany({
            where: { factureFournisseurId: { not: null } },
            data: { factureFournisseurId: null }
        });
        console.log(`✅ Nullified FactureFournisseur links in ${updateMouvements.count} MouvementStock records.`);
        const deleteDepenses = await prisma.depense.deleteMany();
        console.log(`✅ Deleted ${deleteDepenses.count} Depense records.`);
        const deleteEcheances = await prisma.echeancePaiement.deleteMany();
        console.log(`✅ Deleted ${deleteEcheances.count} EcheancePaiement records.`);
        const deleteInvoices = await prisma.factureFournisseur.deleteMany();
        console.log(`✅ Deleted ${deleteInvoices.count} FactureFournisseur records.`);
        const deleteSuppliers = await prisma.fournisseur.deleteMany();
        console.log(`✅ Deleted ${deleteSuppliers.count} Fournisseur records.`);
        console.log('✨ Cleanup complete. Database is ready for re-import.');
    }
    catch (error) {
        console.error('❌ Error during cleanup:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-suppliers.js.map