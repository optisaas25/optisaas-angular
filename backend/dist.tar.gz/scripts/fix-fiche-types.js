"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('--- Starting Fiche Type Restoration ---');
    const fichesToFix = await prisma.fiche.findMany({
        where: {
            OR: [
                { type: 'DEVIS' },
                { type: 'LENTILLES' },
                { statut: 'DEVIS_EN_COURS' },
                { statut: 'true' }
            ],
        },
    });
    console.log(`Found ${fichesToFix.length} fiches to investigate.`);
    let count = 0;
    for (const fiche of fichesToFix) {
        console.log(`Normalizing Fiche #${fiche.numero} (ID: ${fiche.id})...`);
        await prisma.fiche.update({
            where: { id: fiche.id },
            data: {
                type: 'lentilles',
                statut: 'en_cours',
            },
        });
        count++;
    }
    console.log(`--- Restoration Complete. ${count} fiches updated. ---`);
}
main()
    .catch((e) => {
    console.error(e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=fix-fiche-types.js.map