"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🚮 Starting database cleanup...');
    const deletedPaiements = await prisma.paiement.deleteMany({});
    console.log(`✅ Deleted ${deletedPaiements.count} paiements.`);
    const deletedFactures = await prisma.facture.deleteMany({});
    console.log(`✅ Deleted ${deletedFactures.count} factures.`);
    const deletedFiches = await prisma.fiche.deleteMany({});
    console.log(`✅ Deleted ${deletedFiches.count} fiches.`);
    console.log('✨ Tables are now empty. You can proceed with the re-import.');
}
main()
    .catch((e) => {
    console.error('❌ Error during cleanup:', e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=empty-factures.js.map