"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
async function main() {
    const prisma = new client_1.PrismaClient();
    const targetFicheId = '3071b0e6-5aed-45a1-b10b-54c2901c7708';
    console.log(`🔍 Checking for Fiche ID: ${targetFicheId}`);
    const fiche = await prisma.fiche.findUnique({
        where: { id: targetFicheId }
    });
    if (fiche) {
        console.log('✅ Found Fiche:', {
            id: fiche.id,
            numero: fiche.numero,
            clientId: fiche.clientId
        });
    }
    else {
        console.log('❌ Fiche NOT FOUND in database.');
        const totalFiches = await prisma.fiche.count();
        console.log(`Total Fiches in DB: ${totalFiches}`);
    }
    await prisma.$disconnect();
}
main();
//# sourceMappingURL=check-fiche.js.map