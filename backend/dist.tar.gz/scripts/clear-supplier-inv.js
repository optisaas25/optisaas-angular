"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🚀 Clearing Supplier Invoices and Payments tables...');
    try {
        const deleteDepenses = await prisma.depense.deleteMany({
            where: {
                factureFournisseurId: { not: null }
            }
        });
        console.log(`✅ Deleted ${deleteDepenses.count} payments attached to supplier invoices.`);
        const deleteOtherDepenses = await prisma.depense.deleteMany();
        console.log(`✅ Deleted ${deleteOtherDepenses.count} remaining expenses (paiements fournisseur).`);
        const deleteFacturesF = await prisma.factureFournisseur.deleteMany();
        console.log(`✅ Deleted ${deleteFacturesF.count} supplier invoices.`);
    }
    catch (error) {
        console.error('❌ Error during cleanup:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-supplier-inv.js.map