"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    try {
        console.log('🗑️  Starting cleanup...');
        console.log('Deleting Factures linked to Fiches (or all factures)...');
        const deletedFactures = await prisma.facture.deleteMany({
            where: {}
        });
        console.log(`✅ Deleted ${deletedFactures.count} Factures.`);
        console.log('Deleting Fiches...');
        const deletedFiches = await prisma.fiche.deleteMany({});
        console.log(`✅ Deleted ${deletedFiches.count} Fiches.`);
    }
    catch (error) {
        console.error('❌ Error clearing data:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-fiches.js.map