"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
require('dotenv').config();
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🧹 Targeted Cleanup: Clearing Purchase Invoices (BL) and Supplier Expenses...');
    try {
        const movements = await prisma.mouvementStock.deleteMany({
            where: { factureFournisseurId: { not: null } }
        });
        console.log(`  ✓ Deleted ${movements.count} MouvementStock records.`);
        const depenses = await prisma.depense.deleteMany({
            where: {
                OR: [
                    { factureFournisseurId: { not: null } },
                    { description: { contains: 'Achat sans facture (Fournisseur:' } }
                ]
            }
        });
        console.log(`  ✓ Deleted ${depenses.count} Depense records (Purchase related).`);
        const invoices = await prisma.factureFournisseur.deleteMany({});
        console.log(`  ✓ Deleted ${invoices.count} FactureFournisseur records (BLs/Invoices).`);
        const echeances = await prisma.echeancePaiement.deleteMany({
            where: {
                AND: [
                    { factureFournisseurId: null },
                    { depense: null }
                ]
            }
        });
        console.log('\n✅ Purchase data cleared successfully!');
        const invoicesCount = await prisma.factureFournisseur.count();
        const depenseCount = await prisma.depense.count();
        const echeanceCount = await prisma.echeancePaiement.count();
        console.log('\n📊 Database state after cleanup:');
        console.log(`   FactureFournisseur: ${invoicesCount}`);
        console.log(`   Depense:            ${depenseCount}`);
        console.log(`   EcheancePaiement:   ${echeanceCount}`);
    }
    catch (error) {
        console.error('❌ Error during cleanup:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-purchases-reimport.js.map