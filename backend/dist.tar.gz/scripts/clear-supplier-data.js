"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient({
    datasources: {
        db: {
            url: "postgresql://postgres:mypassword@localhost:5435/optisaas?schema=public"
        }
    }
});
async function main() {
    console.log('Cleaning up supplier-related data...');
    try {
        const movements = await prisma.mouvementStock.deleteMany({
            where: { factureFournisseurId: { not: null } }
        });
        console.log(`Deleted ${movements.count} MouvementStock records.`);
        const echeances = await prisma.echeancePaiement.deleteMany({});
        console.log(`Deleted ${echeances.count} EcheancePaiement records.`);
        const depensesTotal = await prisma.depense.deleteMany({});
        console.log(`Deleted ${depensesTotal.count} Depense records.`);
        const invoices = await prisma.factureFournisseur.deleteMany({});
        console.log(`Deleted ${invoices.count} FactureFournisseur records.`);
        const suppliers = await prisma.fournisseur.deleteMany({});
        console.log(`Deleted ${suppliers.count} Fournisseur records.`);
        console.log('Cleanup complete.');
    }
    catch (error) {
        console.error('Error during cleanup:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-supplier-data.js.map