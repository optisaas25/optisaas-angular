"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient({
    datasources: { db: { url: 'postgresql://postgres:mypassword@localhost:5435/optisaas?schema=public' } }
});
async function clearAllForTest() {
    console.log('🧹 Début du nettoyage des tables...\n');
    const echeances = await prisma.echeancePaiement.deleteMany({});
    console.log(`✅ EcheancePaiement supprimées : ${echeances.count}`);
    const depenses = await prisma.depense.deleteMany({});
    console.log(`✅ Depenses supprimées : ${depenses.count}`);
    const paiements = await prisma.paiement.deleteMany({});
    console.log(`✅ Paiements clients supprimés : ${paiements.count}`);
    try {
        const lignes = await prisma.ligneFacture.deleteMany({});
        console.log(`✅ LignesFacture supprimées : ${lignes.count}`);
    }
    catch {
        console.log('ℹ️  LigneFacture table non trouvée, ignoré.');
    }
    const factures = await prisma.facture.deleteMany({});
    console.log(`✅ Factures ventes supprimées : ${factures.count}`);
    const facturesFourn = await prisma.factureFournisseur.deleteMany({});
    console.log(`✅ FacturesFournisseur supprimées : ${facturesFourn.count}`);
    const fournisseurs = await prisma.fournisseur.deleteMany({});
    console.log(`✅ Fournisseurs supprimés : ${fournisseurs.count}`);
    const fiches = await prisma.fiche.deleteMany({});
    console.log(`✅ Fiches (dossiers clients) supprimées : ${fiches.count}`);
    console.log('\n✅ Nettoyage terminé ! La base est prête pour un test propre.');
    await prisma.$disconnect();
}
clearAllForTest().catch(async (e) => {
    console.error('❌ Erreur :', e.message);
    await prisma.$disconnect();
    process.exit(1);
});
//# sourceMappingURL=clear-all-for-test.js.map