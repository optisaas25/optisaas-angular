"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
async function diagnoseMerging() {
    const prisma = new client_1.PrismaClient();
    console.log('🔍 Analyse des fusions de factures...');
    try {
        const factures = await prisma.factureFournisseur.findMany({
            where: {
                updatedAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) }
            },
            include: { fournisseur: true }
        });
        console.log(`📊 Nombre de factures analysées : ${factures.length}`);
        const summary = await prisma.factureFournisseur.groupBy({
            by: ['fournisseurId', 'numeroFacture'],
            _count: true,
            having: {
                numeroFacture: { _count: { gt: 1 } }
            }
        });
        console.log(`⚠️  Doublons de numéros trouvés en base : ${summary.length}`);
    }
    catch (error) {
        console.error('❌ Erreur:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
diagnoseMerging();
//# sourceMappingURL=diagnose-merging.js.map