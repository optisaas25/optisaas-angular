"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🚀 Clearing Paiement tables...');
    try {
        const deletePaiements = await prisma.paiement.deleteMany();
        console.log(`✅ Deleted ${deletePaiements.count} client payments.`);
        const updateFactures = await prisma.facture.updateMany({
            data: {
                resteAPayer: { set: 0 },
                statut: 'VALIDEE'
            }
        });
        await prisma.$executeRawUnsafe(`UPDATE "Facture" SET "resteAPayer" = "totalTTC", "statut" = 'VALIDEE'`);
        console.log(`✅ Reset all Facture balances and statuses.`);
        const deleteOps = await prisma.operationCaisse.deleteMany({
            where: { typeOperation: 'COMPTABLE' }
        });
        console.log(`✅ Deleted ${deleteOps.count} accounting operations from Caisse.`);
    }
    catch (error) {
        console.error('❌ Error during cleanup:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-payments.js.map