"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('--- STARTING FINAL CLEANUP ---');
    const invoicesWithDupes = await prisma.$queryRaw `
    SELECT "factureFournisseurId", COUNT(*) as count 
    FROM "EcheancePaiement" 
    WHERE "factureFournisseurId" IS NOT NULL 
    GROUP BY "factureFournisseurId" 
    HAVING COUNT(*) > 1
  `;
    console.log(`Found ${invoicesWithDupes.length} invoices with multiple echeances.`);
    for (const item of invoicesWithDupes) {
        const invoiceId = item.factureFournisseurId;
        const echeances = await prisma.echeancePaiement.findMany({
            where: { factureFournisseurId: invoiceId },
            orderBy: [
                { statut: 'desc' },
                { createdAt: 'asc' }
            ]
        });
        if (echeances.length > 1) {
            const toKeep = echeances[0];
            const toDelete = echeances.slice(1);
            console.log(`Invoice ${invoiceId}: Keeping ${toKeep.id} (${toKeep.statut}), deleting ${toDelete.length} duplicates.`);
            for (const d of toDelete) {
                await prisma.echeancePaiement.delete({ where: { id: d.id } });
            }
        }
    }
    const finalTotal = await prisma.echeancePaiement.count();
    const invoices = await prisma.factureFournisseur.count();
    const expenses = await prisma.depense.count();
    console.log('--- FINAL STATE ---');
    console.log(`Factures: ${invoices}`);
    console.log(`Depenses: ${expenses}`);
    console.log(`Echeances: ${finalTotal}`);
    console.log(`Alignment: ${finalTotal === (invoices + expenses) ? 'PERFECT' : 'STILL MISALIGNED'}`);
}
main();
//# sourceMappingURL=final-cleanup.js.map