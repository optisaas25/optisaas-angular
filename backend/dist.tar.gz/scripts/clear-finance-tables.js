"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('--- Début du nettoyage ciblé ---');
    console.log('Suppression des Depenses...');
    await prisma.depense.deleteMany();
    console.log('Suppression des Mouvements de Stock...');
    await prisma.mouvementStock.deleteMany();
    console.log('Suppression des Demandes Alimentation...');
    await prisma.demandeAlimentation.deleteMany();
    console.log('Suppression des Operations Caisse...');
    await prisma.operationCaisse.deleteMany();
    console.log('Suppression des Echeances de Paiement...');
    await prisma.echeancePaiement.deleteMany();
    console.log('Suppression des Bons de Livraison...');
    try {
        if (prisma.bonLivraison) {
            await prisma.bonLivraison.deleteMany();
        }
    }
    catch (e) {
        console.log('Table BonLivraison non trouvée ou vide.');
    }
    console.log('Suppression des Factures Fournisseurs...');
    await prisma.factureFournisseur.deleteMany();
    console.log('--- Nettoyage terminé avec succès ! ---');
}
main()
    .catch((e) => {
    console.error('Erreur lors du nettoyage :', e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=clear-finance-tables.js.map