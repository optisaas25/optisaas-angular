"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
async function main() {
    const client = new pg_1.Client({
        user: 'postgres',
        host: 'localhost',
        database: 'optisaas',
        password: 'admin',
        port: 5432,
    });
    try {
        await client.connect();
        console.log('Connecté à la base de données PostgreSQL.');
        console.log('Suppression en cours...');
        await client.query(`
      TRUNCATE TABLE 
        "Depense", 
        "FactureFournisseur", 
        "EcheancePaiement", 
        "BonLivraison", 
        "MouvementStock", 
        "OperationCaisse", 
        "DemandeAlimentation" 
      CASCADE;
    `);
        console.log('✅ Toutes les tables financières (Factures, BL, Dépenses, Echeances...) ont été vidées avec succès.');
    }
    catch (err) {
        console.error('Erreur lors de la connexion ou de la suppression :', err);
    }
    finally {
        await client.end();
    }
}
main();
//# sourceMappingURL=force-clear-db.js.map