"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
async function main() {
    const prisma = new client_1.PrismaClient();
    console.log('📊 --- DATABASE AUDIT --- 📊');
    const counts = {
        clients: await prisma.client.count(),
        fiches: await prisma.fiche.count(),
        factures: await prisma.facture.count(),
        products: await prisma.product.count(),
        paiements: await prisma.paiement.count(),
        entrepot: await prisma.entrepot.count(),
    };
    console.log('Counts:', counts);
    const factureBreaks = await prisma.facture.groupBy({
        by: ['type', 'statut'],
        _count: { _all: true },
        _sum: { totalTTC: true }
    });
    console.log('\nFacture Breakdown (Type/Status):');
    factureBreaks.forEach(b => {
        console.log(` - ${b.type} / ${b.statut}: ${b._count._all} records, Sum: ${b._sum.totalTTC}`);
    });
    const dateRange = await prisma.facture.aggregate({
        _min: { dateEmission: true },
        _max: { dateEmission: true }
    });
    console.log('\nFacture Date Emission Range:', dateRange);
    if (counts.products > 0) {
        const prodSample = await prisma.product.findFirst();
        console.log('\nProduct Sample:', prodSample);
    }
    else {
        console.log('\n⚠️ NO PRODUCTS FOUND IN DATABASE');
    }
    const sampleNoLines = await prisma.facture.findMany({
        take: 5,
        orderBy: { dateEmission: 'desc' },
        select: { id: true, numero: true, type: true, lignes: true }
    });
    console.log('\nSample Recent Factures Lignes:', sampleNoLines.map(f => ({
        id: f.id,
        num: f.numero,
        type: f.type,
        lineCount: Array.isArray(f.lignes) ? f.lignes.length : 'NOT ARRAY'
    })));
    await prisma.$disconnect();
}
main();
//# sourceMappingURL=check-counts.js.map