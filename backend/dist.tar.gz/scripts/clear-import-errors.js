"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const dotenv = __importStar(require("dotenv"));
const path = __importStar(require("path"));
async function clearAll() {
    const envs = ['.env', '.env.host'];
    for (const envFile of envs) {
        dotenv.config({ path: path.join(__dirname, '..', envFile), override: true });
        const dbUrl = process.env.DATABASE_URL;
        console.log(`\n🔎 Vérification de l'environnement : ${envFile}`);
        console.log(`🔗 URL : ${dbUrl ? dbUrl.replace(/:[^:@]+@/, ':****@') : 'N/A'}`);
        const prisma = new client_1.PrismaClient();
        try {
            const fCount = await prisma.factureFournisseur.count();
            const dCount = await prisma.depense.count();
            const eCount = await prisma.echeancePaiement.count();
            if (fCount > 0 || dCount > 0 || eCount > 0) {
                console.log(`📊 Trouvé : ${fCount} FF, ${dCount} DEP, ${eCount} ECH.`);
                const d1 = await prisma.depense.deleteMany({});
                const d2 = await prisma.factureFournisseur.deleteMany({});
                const d3 = await prisma.echeancePaiement.deleteMany({});
                console.log(`✅ Nettoyé : ${d1.count} DEP, ${d2.count} FF, ${d3.count} ECH supprimés.`);
            }
            else {
                console.log('✨ Déjà vide.');
            }
        }
        catch (e) {
            console.log(`❌ Erreur sur cet env : ${e.message}`);
        }
        finally {
            await prisma.$disconnect();
        }
    }
}
clearAll();
//# sourceMappingURL=clear-import-errors.js.map