"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const levenshtein = __importStar(require("fast-levenshtein"));
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🔍 Searching for potential duplicate suppliers...');
    const suppliers = await prisma.fournisseur.findMany({
        select: { id: true, nom: true }
    });
    const duplicates = [];
    for (let i = 0; i < suppliers.length; i++) {
        for (let j = i + 1; j < suppliers.length; j++) {
            const name1 = suppliers[i].nom.toLowerCase().trim();
            const name2 = suppliers[j].nom.toLowerCase().trim();
            if (name1 === name2) {
                duplicates.push({ s1: suppliers[i].nom, s2: suppliers[j].nom, distance: 0 });
                continue;
            }
            const distance = levenshtein.get(name1, name2);
            const maxLength = Math.max(name1.length, name2.length);
            if (distance <= 2 || (distance / maxLength) < 0.2) {
                duplicates.push({ s1: suppliers[i].nom, s2: suppliers[j].nom, distance });
            }
        }
    }
    if (duplicates.length === 0) {
        console.log('✅ No obvious duplicates found among ' + suppliers.length + ' suppliers.');
    }
    else {
        console.log('⚠️ Found ' + duplicates.length + ' potential duplicates:');
        duplicates.forEach(d => {
            console.log(` - "${d.s1}" <-> "${d.s2}" (Diff: ${d.distance})`);
        });
        console.log('\n💡 You can use these names to consolidate your Excel file or I can build a merge script.');
    }
    await prisma.$disconnect();
}
main();
//# sourceMappingURL=find-duplicate-suppliers.js.map