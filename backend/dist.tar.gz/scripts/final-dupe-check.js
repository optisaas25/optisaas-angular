"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('--- FINAL PAYMENT DUPLICATE CHECK ---');
    const dupes = await prisma.$queryRaw `
    SELECT montant, "dateEncaissement", "reference", COUNT(*) as count 
    FROM "EcheancePaiement" 
    WHERE "statut" = 'PAYEE' 
    GROUP BY montant, "dateEncaissement", "reference" 
    HAVING COUNT(*) > 1
  `;
    console.log(`Found ${dupes.length} groups of potential duplicate payments (same amt, date, ref).`);
    for (const d of dupes.slice(0, 10)) {
        console.log(`- Amount: ${d.montant}, Date: ${d.dateEncaissement}, Ref: ${d.reference}, Count: ${d.count}`);
    }
    const totPayee = await prisma.echeancePaiement.count({ where: { statut: 'PAYEE' } });
    console.log(`\nTotal unique-ish PAYEE echeances: ${totPayee}`);
    const unpaidInvoices = await prisma.factureFournisseur.count({
        where: { echeances: { none: { statut: 'PAYEE' } } }
    });
    console.log(`Invoices with ZERO payments: ${unpaidInvoices}`);
}
main().finally(() => prisma.$disconnect());
//# sourceMappingURL=final-dupe-check.js.map