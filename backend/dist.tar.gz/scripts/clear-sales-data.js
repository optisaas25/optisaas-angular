"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🚀 Starting to clear Facture and Paiement tables...');
    try {
        const commissions = await prisma.commission.deleteMany({});
        console.log(`✅ Deleted ${commissions.count} commissions.`);
        const paiements = await prisma.paiement.deleteMany({});
        console.log(`✅ Deleted ${paiements.count} paiements.`);
        const mouvements = await prisma.mouvementStock.updateMany({
            where: { factureId: { not: null } },
            data: { factureId: null }
        });
        console.log(`✅ Disconnected ${mouvements.count} stock movements from factures.`);
        const operations = await prisma.operationCaisse.updateMany({
            where: { factureId: { not: null } },
            data: { factureId: null }
        });
        console.log(`✅ Disconnected ${operations.count} cash operations from factures.`);
        const points = await prisma.pointsHistory.updateMany({
            where: { factureId: { not: null } },
            data: { factureId: null }
        });
        console.log(`✅ Disconnected ${points.count} points history records from factures.`);
        const demandes = await prisma.demandeAlimentation.updateMany({
            where: { paiementId: { not: null } },
            data: { paiementId: null }
        });
        console.log(`✅ Disconnected ${demandes.count} replenishment requests from payments.`);
        const supplierInvoices = await prisma.factureFournisseur.updateMany({
            where: { ficheId: { not: null } },
            data: { ficheId: null }
        });
        console.log(`✅ Disconnected ${supplierInvoices.count} supplier invoices from fiches.`);
        const factures = await prisma.facture.deleteMany({});
        console.log(`✅ Deleted ${factures.count} factures.`);
        const fiches = await prisma.fiche.deleteMany({});
        console.log(`✅ Deleted ${fiches.count} fiches.`);
        console.log('✨ All requested data (Facture, Paiement, Fiche) cleared successfully.');
    }
    catch (error) {
        console.error('❌ Error clearing sales data:', error);
    }
    finally {
        await prisma.$disconnect();
    }
}
main();
//# sourceMappingURL=clear-sales-data.js.map