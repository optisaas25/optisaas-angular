"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const start = new Date('2000-01-01T00:00:00.000Z'); const end = new Date('2026-02-20T23:59:59.999Z'); const bcs = await prisma.facture.findMany({ where: { centreId, OR: [{ type: 'BON_COMMANDE' }, { type: 'BON_COMM' }, { numero: { startsWith: 'BC' } }] }, take: 5, select: { numero: true, type: true, statut: true, dateEmission: true } }); console.log('BC Dates:', bcs); await prisma.$disconnect(); }
run();
//# sourceMappingURL=debug-date.js.map