"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const bcs = await prisma.facture.findMany({ where: { centreId, OR: [{ type: 'BON_COMMANDE' }, { type: 'BON_COMM' }, { numero: { startsWith: 'BC' } }] }, take: 10, select: { id: true, numero: true, type: true, statut: true, totalTTC: true } }); console.log('Found BCs:', bcs); await prisma.$disconnect(); }
run();
//# sourceMappingURL=debug-aggregations2.js.map