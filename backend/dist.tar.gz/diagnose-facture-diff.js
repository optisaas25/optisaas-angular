"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function run() { const centreId = '6df7de62-498e-4784-b22f-7bbccc7fea36'; const dashboardFactures = await prisma.facture.findMany({ where: { centreId, OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }], statut: { notIn: ['VENTE_EN_INSTANCE', 'ANNULEE', 'ARCHIVE'] }, type: { not: 'AVOIR' } } }); const crudeFactures = await prisma.facture.findMany({ where: { OR: [{ numero: { startsWith: 'FAC' } }, { type: 'FACTURE' }], statut: { notIn: ['ANNULEE', 'ARCHIVE'] }, type: { not: 'AVOIR' } } }); const dashIds = new Set(dashboardFactures.map(f => f.id)); const missing = crudeFactures.filter(f => !dashIds.has(f.id)); let missingTTC = 0; for (const m of missing) {
    missingTTC += m.totalTTC;
    console.log('Missing from dashboard:', m.numero, m.type, m.statut, m.totalTTC, 'Centre:', m.centreId);
} console.log('Total difference:', missingTTC); await prisma.$disconnect(); }
run();
//# sourceMappingURL=diagnose-facture-diff.js.map