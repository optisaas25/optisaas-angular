"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const prisma = new client_1.PrismaClient();
async function findFiche() {
    try {
        const client = await prisma.client.findFirst({
            where: {
                OR: [
                    { nom: { contains: 'Arsalane', mode: 'insensitive' } },
                    { prenom: { contains: 'Arsalane', mode: 'insensitive' } },
                    { raisonSociale: { contains: 'Arsalane', mode: 'insensitive' } }
                ]
            }
        });
        if (!client) {
            console.log('Client not found');
            return;
        }
        const fiche = await prisma.fiche.findFirst({
            where: { clientId: client.id },
            orderBy: { numero: 'desc' }
        });
        if (!fiche) {
            console.log('Fiche not found for client:', client.id);
            return;
        }
        console.log('Found Fiche Content:');
        console.log(JSON.stringify(fiche.content, null, 2));
    }
    catch (err) {
        console.error(err);
    }
    finally {
        await prisma.$disconnect();
    }
}
findFiche();
//# sourceMappingURL=find-arsalane-fiche.js.map