import"./chunk-HZ6M6AS2.js";var e=[{path:":id",loadComponent:()=>import("./chunk-AQKO6NOR.js").then(o=>o.WarehouseDetailComponent)}];export{e as warehousesRoutes};
